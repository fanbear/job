<?php
// Product
$query = $this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "product");

$featured_sticker = false;

if ($query->rows) {
	
	foreach ($query->rows as $row) {
		if($row['Field'] == 'featured_sticker'){
			$featured_sticker = true;
		}
	}
	
	if(!$featured_sticker){
		$this->db->query("ALTER TABLE `" . DB_PREFIX . "product`  ADD `featured_sticker` INT NOT NULL;");
	}
}
?>