<?php
$_['xd_zvonok_button_name'] 	= 'Обратный звонок';
$_['xd_zvonok_modal_title'] 	= 'Заказ обратного звонка';
$_['xd_zvonok_field1_title'] 	= 'Имя';
$_['xd_zvonok_field2_title'] 	= 'Телефон';
$_['xd_zvonok_field3_title'] 	= 'Сообщение';
$_['xd_zvonok_required_text'] 	= 'обязательное поле';
$_['xd_zvonok_success_field'] 	= '<h3>Спасибо!<br />Мы свяжемся с Вами в самое ближайшее время.</h3>';
$_['xd_zvonok_error_required'] 	= 'Пожалуйста, заполните обязательные поля!';
$_['xd_zvonok_error_sending'] 	= 'Ошибка отправки, попробуйте повторить позднее!';
$_['xd_zvonok_text_agree'] 		= 'Нажимая кнопку "ОТПРАВИТЬ", Вы соглашаетесь с <a href="%s" class="agree"><b>%s</b></a>';
$_['xd_zvonok_submit_button'] 	= 'ОТПРАВИТЬ';