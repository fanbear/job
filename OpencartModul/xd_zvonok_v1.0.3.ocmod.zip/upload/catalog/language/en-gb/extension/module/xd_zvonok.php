<?php
$_['xd_zvonok_button_name'] 	= 'Request a call back';
$_['xd_zvonok_modal_title'] 	= 'Callback order';
$_['xd_zvonok_field1_title'] 	= 'Name';
$_['xd_zvonok_field2_title'] 	= 'Phone';
$_['xd_zvonok_field3_title'] 	= 'Message';
$_['xd_zvonok_required_text'] 	= 'required field';
$_['xd_zvonok_success_field'] 	= '<h2>Thank you!<br />We will contact you as soon as possible.</h2>';
$_['xd_zvonok_error_required'] 	= 'Please, fill required fields!';
$_['xd_zvonok_error_sending'] 	= 'Sending error, try again later!';
$_['xd_zvonok_text_agree'] 		= 'By clicking "SEND" button, you have read and agree to <a href="%s" class="agree"><b>%s</b></a>';
$_['xd_zvonok_submit_button'] 	= 'SEND';