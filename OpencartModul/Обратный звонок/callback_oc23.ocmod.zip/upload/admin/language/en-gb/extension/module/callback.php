<?php
// Heading
$_['heading_title']    = 'Callback Form | <a target="_blank" href="https://opencart2x.ru/">opencart2x.ru</a>';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified module!';
$_['text_edit']        = 'Edit Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify banner module!';