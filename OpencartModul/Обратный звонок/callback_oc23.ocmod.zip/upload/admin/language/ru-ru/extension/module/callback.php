<?php
// Heading
$_['heading_title']  = 'Обратный звонок | <a target="_blank" href="https://opencart2x.ru/">opencart2x.ru</a>';

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Успешно!';
$_['text_edit']        = 'Редактировать';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Внимание! У вас нет прав на управление модулем. Установите права!';