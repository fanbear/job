<?php
// Heading
$_['heading_title'] = 'Leave your contact and we will call you back';
$_['entry_name'] = 'Your name';
$_['entry_phone'] = 'Phone number';
$_['entry_submit'] = 'Call me!';
$_['entry_error'] = 'Error! Please fill in all fields ';
$_['entry_ok'] = 'Thank you. We have received your request.';