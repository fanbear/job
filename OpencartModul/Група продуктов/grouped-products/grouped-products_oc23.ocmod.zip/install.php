<?php 
$sql = array();

$field_data = array();
$field_query = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "product`");
foreach ($field_query->rows as $field) {
	$field_data[] = $field['Field'];
}
if (!in_array('gp_parent_id', $field_data)) {
	$sql[] = "ALTER TABLE `" . DB_PREFIX . "product` ADD `gp_parent_id` INT(11) NOT NULL DEFAULT '0'";
}

$table_query = $this->db->query("SHOW TABLES FROM `" . DB_DATABASE . "` LIKE '" . DB_PREFIX . "gp_bundle'");
if (!$table_query->num_rows) {
	$sql[] = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gp_bundle` (
		`product_id` INT(11) NOT NULL,
		`gp_price_min` VARCHAR(20) NOT NULL,
		`gp_price_max` VARCHAR(20) NOT NULL,
		`gp_template` VARCHAR(16) NOT NULL DEFAULT 'default',
		PRIMARY KEY (`product_id`)
	) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci";
}

$table_query = $this->db->query("SHOW TABLES FROM `" . DB_DATABASE . "` LIKE '" . DB_PREFIX . "gp_bundle_child'");
if (!$table_query->num_rows) {
	$sql[] = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gp_bundle_child` (
		`product_id` INT(11) NOT NULL,
		`child_id` INT(11) NOT NULL,
		`child_sort_order` INT(11) NOT NULL,
		PRIMARY KEY (`product_id`,`child_id`)
	) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci";
}

if ($sql) {
	foreach ($sql as $query) {
		$this->db->query($query);
	}
}