<?php
// Column
$_['column_gp_image']              = 'Фото';
$_['column_gp_name']               = 'Название';
$_['column_gp_price']              = 'Цена';
$_['column_gp_option']             = 'Опции';
$_['column_gp_qty']                = 'К-во';

// Text
$_['text_gp_price_min']            = 'От ';
$_['text_gp_price_max']            = '<br />до ';
$_['text_gp_price_start']          = 'от: ';
$_['text_gp_no_stock']             = 'Товара нет в наличии';
$_['text_gp_total']                = 'Сумма:';

// Child Info Text
$_['text_gp_child_model']          = 'Модель';
$_['text_gp_child_quantity']       = 'Количество';
$_['text_gp_child_stock']          = 'Доступность';
$_['text_gp_child_manufacturer']   = 'Производитель';
$_['text_gp_child_location']       = 'Расположение';
$_['text_gp_child_sku']            = 'SKU';
$_['text_gp_child_upc']            = 'UPC';
$_['text_gp_child_ean']            = 'EAN';
$_['text_gp_child_jan']            = 'JAN';
$_['text_gp_child_isbn']           = 'ISBN';
$_['text_gp_child_mpn']            = 'MPN';
$_['text_gp_child_reward']         = 'Бонусные баллы';
$_['text_gp_child_points']         = 'Баллы';
$_['text_gp_child_weight']         = 'Вес';
$_['text_gp_child_length']         = 'Длинна';
$_['text_gp_child_width']          = 'Ширина';
$_['text_gp_child_height']         = 'Высота';
$_['text_gp_child_rating']         = '';
$_['text_gp_child_reviews']        = 'Отзывы';
$_['text_gp_child_date_available'] = 'Дата поступления';
$_['text_gp_child_date_added']     = 'Дата добавления';
$_['text_gp_child_date_modified']  = 'Дата изменения';

// Error
$_['error_gp_child_quantity']      = 'Выберите хотя бы один товар!';
$_['error_gp_child_options']       = 'Что-то не так! Видимо какая-то из опций обязательная для заполнения.';
$_['error_gp_child_option']        = '%s обязательно.';
