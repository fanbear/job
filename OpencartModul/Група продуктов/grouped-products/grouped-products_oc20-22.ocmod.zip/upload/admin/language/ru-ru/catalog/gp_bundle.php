<?php
// Heading
$_['heading_title']              = 'Комплекты товаров';

// Tab
$_['tab_gp_data']                = 'Комплект';

// Column
$_['column_gp_childs']           = 'Дочерные товары';
$_['column_gp_child_id']         = 'ID';
$_['column_gp_child_name']       = 'Название';
$_['column_gp_child_model']      = 'Модель';
$_['column_gp_child_price']      = 'Цена';
$_['column_gp_child_sort_order'] = 'Порядок';

// Text
$_['text_gp_min']                = 'Мин';
$_['text_gp_max']                = 'Макс';
$_['text_gp_child_has_options']  = '<br />Товар с опциями.';

// Entry
$_['entry_gp_template']          = 'Шаблон';
$_['entry_gp_price_mask']        = 'Маска цены';

// Help
$_['help_gp_price_mask']         = 'Цены (Стартовая, от, до) отображаются на страницах списка товаров (категория, поиск и т. Д.). Фиксированная цена или #ID для автоматической проверки (ID: увеличивает нагрузку).';

// Error
