<?php
// Заголовок здесь:
$_['heading_title'] = 'Аукцион';

// Текст
$_['text_module'] = 'Модули';
$_['text_success'] = 'Успех: Вы изменили модуль Аукциона';
$_['text_content_top'] = 'Вверху страницы';
$_['text_content_bottom'] = 'Внизу страницы';
$_['text_column_left'] = 'Левая колонка';
$_['text_column_right'] = 'Правая колонка';
$_['text_left'] = 'Слева';
$_['text_right'] = 'Справа';
$_['text_count_unique'] = 'Уникальные посетители';
$_['text_count_all'] = 'Всего просмотров';

// Запись
$_['entry_cur_bid'] = 'Текущая ставка';
$_['entry_history'] = 'История Аукциона';
$_['text_view'] = 'показать';
$_['text_bidder'] = 'Имя учасника';
$_['text_bid'] = 'ставка';
$_['entry_name'] = 'Аукцион';
$_['text_win_bid'] = 'Победная ставка';
$_['text_total_bid'] = 'Всего ставок';
$_['entry_prod'] = 'Имя лота';
$_['entry_start_time'] = 'Время начала';
$_['entry_end_time'] = 'Время окончания';
$_['entry_amt'] = 'Сумма ставки';
$_['entry_cus'] = 'Клиент';
$_['entry_dat'] = 'ставка на';
$_['entry_start'] = 'Старт аукциона';
$_['entry_end'] = 'Конец аукциона';
$_['button_insert'] = 'Вставить';
$_['button_save'] = 'Сохранить';
$_['button_cancel'] = 'Отменить';
$_['button_delete'] = 'Удалить';
$_['text_edit'] = 'Редактировать';
$_['entry_winner'] = 'Победитель';
$_['entry_sold'] = 'Продано';

$_['error_permission'] = 'Внимание: Вы не имеете разрешения на изменения модуля. Нужно установить права.';
?>
