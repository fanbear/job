<?php
// Heading
$_['heading_title'] = 'Auction Products';


//Text
$_['text_bidnow'] = 'Bid Now';
$_['text_minbid'] = 'Minimum Bid';
$_['text_maxbid'] = 'Maximum Bid';

