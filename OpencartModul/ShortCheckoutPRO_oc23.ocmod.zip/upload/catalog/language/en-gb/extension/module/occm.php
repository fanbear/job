<?php

$_['Buy one click'] = 'Купить в один клик';
$_['Buy'] = 'Купить';
$_['Comment'] = 'Комментарий';
$_['Confirm buy one click'] = 'Подтвердить заказ';
$_['Email is required!'] = 'Адрес эл. почты обязателен для заполнения!';
$_['Email is wrong!'] = 'Не верный формат адреса эл. почты! Введите адрес в формате ваш_логин@ваш_почтовый_сервер';
$_['Mail'] = 'Адрес эл. почты';
$_['Name is required!'] = 'Имя обязательно для заполнения!';
$_['Name'] = 'Имя';
$_['Order complete - ID: %s'] = 'Заказ оформлен № заказа - %s';
$_['Phone'] = 'Номер телефона';
$_['Email is wrong!'] = 'The wrong e-mail format! Enter e-mail format your_mail_login@your_mail_server';
$_['Telephone is required!'] = 'The wrong phone number is required!';
$_['Telephone is wrong!'] = 'The wrong phone number format! Enter phone format +1 123 4444-5555 or 112344445555';
?>