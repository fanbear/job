<?php

$_['error_permission']    = 'Warning: You do not have permission to modify module!';
$_['heading_title']       = 'One click checkout module';
$_['image_size_help']     = 'The picture of the product in the checkout form in one click';
$_['order_status_help']   = 'This status will receive new orders';
$_['text_edit']           = 'Edit Module';
$_['text_module']         = 'Modules';
$_['text_success']        = 'Success: You have modified module!';
?>