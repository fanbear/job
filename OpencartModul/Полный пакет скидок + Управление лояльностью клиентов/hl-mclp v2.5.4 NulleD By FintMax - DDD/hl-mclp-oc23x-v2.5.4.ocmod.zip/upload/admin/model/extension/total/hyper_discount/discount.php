<?php
class ModelExtensionTotalHyperDiscountDiscount extends Model
{
    public function editAllDiscounts($data)
    {
        if (isset($data["user_discount"])) {
            foreach ($data["user_discount"] as $discount) {
                $status = isset($discount["status"]) ? (int) $discount["status"] : 0;
                $this->db->query("UPDATE `" . DB_PREFIX . "hd_users` SET `status` = '" . $status . "' WHERE `id` = '" . (int) $discount["discount_id"] . "'");
            }
        }
        if (isset($data["accumulative_discount"])) {
            foreach ($data["accumulative_discount"] as $discount) {
                $status = isset($discount["status"]) ? (int) $discount["status"] : 0;
                $this->db->query("UPDATE `" . DB_PREFIX . "hd_accumulative` SET `status` = '" . $status . "' WHERE `id` = '" . (int) $discount["discount_id"] . "'");
            }
        }
        if (isset($data["quantitative_discount"])) {
            foreach ($data["quantitative_discount"] as $discount) {
                $status                = isset($discount["status"]) ? (int) $discount["status"] : 0;
                $this->db->query("UPDATE `" . DB_PREFIX . "hd_quantitative` SET `status` = '" . $status . "'  WHERE `id` = '" . (int) $discount["discount_id"] . "'");
            }
        }
        if (isset($data["kit_discount"])) {
            foreach ($data["kit_discount"] as $discount) {
                $status = isset($discount["status"]) ? (int) $discount["status"] : 0;
                $this->db->query("UPDATE `" . DB_PREFIX . "hd_kit` SET `status` = '" . $status . "'  WHERE `id` = '" . (int) $discount["discount_id"] . "'");
            }
        }
        if (isset($data["products_discount"])) {
            foreach ($data["products_discount"] as $discount) {
                $status = isset($discount["status"]) ? (int) $discount["status"] : 0;
                $this->db->query("UPDATE `" . DB_PREFIX . "hd_product` SET `status` = '" . $status . "'  WHERE `id` = '" . (int) $discount["discount_id"] . "'");
            }
        }
        if (isset($data["discount_variant"])) {
            $discount = $data["discount_variant"];
            if (!isset($discount["status"]))
                $discount["status"] = 0;
            if (!isset($discount["debugmode"]))
                $discount["debugmode"] = 0;
            foreach ($discount as $key => $val)
                $this->db->query("UPDATE `" . DB_PREFIX . "hd_setting` SET `value` = '$val' WHERE `key`='$key'");
        }
    }
    public function reIndexProducts($product_id = 0)
    {
        if (!$product_id)
            $sql = "SELECT product_id, price FROM " . DB_PREFIX . "product";
        else
            $sql = "SELECT product_id, price FROM " . DB_PREFIX . "product WHERE product_id='$product_id'";
        $query = $this->db->query($sql);
        $this->db->query("TRUNCATE TABLE`" . DB_PREFIX . "hd_products` ");
        $this->load->model("catalog/product");
        if ($query->rows) {
            $prod_ids = $query->rows;
            foreach ($prod_ids as $prod_id) {
                $options = json_encode($this->getProductOptions($prod_id["product_id"]));
                $discounts = json_encode($this->model_catalog_product->getProductDiscounts($prod_id["product_id"]));
                $specials    = json_encode($this->model_catalog_product->getProductSpecials($prod_id["product_id"]));
                $this->db->query("INSERT INTO " . DB_PREFIX . "hd_products SET id = '" . (int) $prod_id["product_id"] . "', price = '" . $prod_id["price"] . "', options = '" . $this->db->escape($options) . "', discounts = '" . $this->db->escape($discounts) . "', specials = '" . $this->db->escape($specials) . "'");
            }
        }
    }
    public function getProductOptions($product_id)
    {
        $product_option_value_data = array();
        $product_option_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_option` po LEFT JOIN `" . DB_PREFIX . "option` o ON (po.option_id = o.option_id) LEFT JOIN `" . DB_PREFIX . "option_description` od ON (o.option_id = od.option_id) WHERE po.product_id = '" . (int) $product_id . "' AND od.language_id = '" . (int) $this->config->get("config_language_id") . "'");
        foreach ($product_option_query->rows as $product_option) {
            $product_option_value_data = array();
            $product_option_value_query   = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_option_value pov LEFT JOIN `" . DB_PREFIX . "option_value` ov ON (pov.option_value_id = ov.option_value_id) WHERE pov.product_option_id = '" . (int) $product_option["product_option_id"] . "' ORDER BY ov.sort_order ASC ");
            foreach ($product_option_value_query->rows as $product_option_value) {
                $product_option_value_data[] = array(
                    "product_option_value_id" => $product_option_value["product_option_value_id"],
                    "option_value_id" => $product_option_value["option_value_id"],
                    "quantity" => $product_option_value["quantity"],
                    "subtract" => $product_option_value["subtract"],
                    "price" => $product_option_value["price"],
                    "price_prefix" => $product_option_value["price_prefix"],
                    "points" => $product_option_value["points"],
                    "points_prefix" => $product_option_value["points_prefix"],
                    "weight" => $product_option_value["weight"],
                    "weight_prefix" => $product_option_value["weight_prefix"]
                );
            }
        }
        return $product_option_value_data;
    }
}
?>