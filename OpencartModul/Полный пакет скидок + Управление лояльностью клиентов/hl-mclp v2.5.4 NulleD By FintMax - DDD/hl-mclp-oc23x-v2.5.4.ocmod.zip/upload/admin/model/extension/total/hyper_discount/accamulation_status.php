<?php

class ModelExtensionTotalHyperDiscountAccamulationStatus extends Model
{

    public function getAccamulationStatussList()
    {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hd_accumulation_statuses` ");

        if ($query->rows)
        {
            return $query->rows;
        } else
        {
            return array();
        }
    }

    public function addAccamulationStatus($accamulation_status)
    {
        $this->db->query("INSERT INTO `" . DB_PREFIX . "hd_accumulation_statuses` SET `name` = '" . $this->db->escape(json_encode($accamulation_status['name'])) . "', `description` = '" . $this->db->escape(json_encode($accamulation_status['description'])) . "'");
    }
    
    public function editAccamulationStatus($id,$accamulation_status)
    {
        $this->db->query("UPDATE `" . DB_PREFIX . "hd_accumulation_statuses` SET `name` = '" . $this->db->escape(json_encode($accamulation_status['name'])) . "', `description` = '" . $this->db->escape(json_encode($accamulation_status['description'])) . "' WHERE `id`='$id';");
    }

    

    public function getAccamulationStatus($accamulation_status_id)
    {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hd_accumulation_statuses` WHERE `id` = '" . (int) $accamulation_status_id . "'");

        if ($query->row)
        {
            return $query->row;
        } else
        {
            return array();
        }
    }

    public function deleteAccamulationStatus($accamulation_status_id)
    {

        $this->db->query("DELETE FROM " . DB_PREFIX . "hd_accumulation_statuses WHERE id = '" . (int) $accamulation_status_id . "'");
    }

   

}
