<?php

class ModelExtensionTotalHyperDiscountProductsDiscount extends Model {

    public function getProductsDiscountsList() {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hd_product` ");

        if ($query->rows) {
            return $query->rows;
        } else {
            return array();
        }
    }

    public function addProductsDiscount($products_discount) {
        $this->db->query("INSERT INTO `" . DB_PREFIX . "hd_product` SET `name` = '" . $this->db->escape(json_encode($products_discount['name'])) . "', `description` = '" . $this->db->escape($products_discount['description']) . "'");
    }

    public function cloneProductsEditor($discount_id, $editor_id) {

        $query = $this->db->query("INSERT INTO `" . DB_PREFIX . "hd_product_discount_editor`( `discount_id`, `editor_id`, `discount_count_products`, `start_date`, `end_date`, `products_all`, `products`, `status`, `products_filter_url`, `discount_coef1`, `discount_coef2`, `discount_coef3`, `discount_priority`, `discount_type1`, `discount_type2`, `discount_type3`, `customer_groups`) 
                                                                         SELECT  `discount_id`, `editor_id`, `discount_count_products`, `start_date`, `end_date`, `products_all`, `products`, `status`, `products_filter_url`, `discount_coef1`, `discount_coef2`, `discount_coef3`, `discount_priority`, `discount_type1`, `discount_type2`, `discount_type3`, `customer_groups`
        FROM `" . DB_PREFIX . "hd_product_discount_editor`
        WHERE `editor_id` = '$editor_id' && `discount_id`='$discount_id';");
        $id = $this->db->getLastId();
         $query = $this->db->query("SELECT `editor_id` FROM `" . DB_PREFIX . "hd_product_discount_editor` WHERE `discount_id`='$discount_id' ORDER BY editor_id DESC LIMIT 0, 1");
        $new_editor_id=(int)$query->row['editor_id']+1;
        $this->db->query("UPDATE `" . DB_PREFIX . "hd_product_discount_editor` SET `editor_id` = '$new_editor_id' WHERE `id`='$id'");
    }

    public function editProductsDiscount($products_discount) {


        $products_discounts = $this->db->query("SELECT * FROM " . DB_PREFIX . "hd_product_discount_editor WHERE `discount_id` = '" . (int) $products_discount['discount_id'] . "'");


        if (isset($products_discount['discount_editor'])) {

            $ids = array();
            foreach ($products_discount['discount_editor'] as $editor_key => $editor_val)
                $ids[] = $editor_key;

            if ($ids)
                $this->db->query("DELETE FROM `" . DB_PREFIX . "hd_product_discount_editor` WHERE `discount_id` = '" . (int) $products_discount['discount_id'] . "' AND `editor_id` NOT IN ('" . implode("','", $ids) . "')");


            foreach ($products_discount['discount_editor'] as $editor_key => $editor_val) {
                $products_all = isset($editor_val['products_all']) ? 1 : 0;
              //  var_dump($products_discount['discount_editor']);exit( );
                $start_date = (!empty($editor_val['start_date'])) ? "'" . ($editor_val['start_date']) . "'" : 'null';
                $end_date = (!empty($editor_val['end_date'])) ? "'" . ($editor_val['end_date']) . "'" : 'null';
                $discount_count_products = $editor_val['discount_count_products'];
                $discount_priority = $editor_val['discount_priority'];

                $customer_groups = (isset($editor_val['customer_groups'])) ? json_encode($editor_val['customer_groups']) : json_encode(array());

                $discount_coef1 = $editor_val['discount_coef1'];
                $discount_coef2 = $editor_val['discount_coef2'];
                $discount_coef3 = $editor_val['discount_coef3'];

                $discount_type1 = $editor_val['discount_type1'];
                $discount_type2 = $editor_val['discount_type2'];
                $discount_type3 = $editor_val['discount_type3'];
                $status = (isset($editor_val['status'])) ? 1 : 0;


                $query_users_discount_editor = $this->db->query("SELECT * FROM " . DB_PREFIX . "hd_product_discount_editor WHERE `discount_id` = '" . (int) $products_discount['discount_id'] . "' AND `editor_id` = '" . (int) $editor_key . "'");

                if (!$query_users_discount_editor->rows) {
                    $this->db->query("INSERT INTO `" . DB_PREFIX . "hd_product_discount_editor` SET "
                            . "`discount_id` = '" . (int) $products_discount['discount_id'] . "', "
                            . "`editor_id` = '" . $editor_key . "', "
                            . "`start_date`=$start_date,"
                            . "`end_date`=$end_date,"
                            . "`products_all`='$products_all',"
                            . "`discount_count_products`='$discount_count_products',"
                            . "`discount_priority`='$discount_priority',"
                            . "`discount_coef1`='$discount_coef1',"
                            . "`discount_coef2` = '$discount_coef2', "
                            . "`discount_coef3` = '$discount_coef3', "
                            . "`discount_type1` = '$discount_type1', "
                            . "`discount_type2` = '$discount_type2', "
                            . "`discount_type3` = '$discount_type3', "
                            . "`customer_groups` = '$customer_groups', "
                            . "`status` = '$status'"
                    );
                } else {
                    $this->db->query("UPDATE `" . DB_PREFIX . "hd_product_discount_editor` SET "
                            . "`start_date`=$start_date,"
                            . "`end_date`=$end_date,"
                            . "`products_all`='$products_all',"
                            . "`discount_count_products`='$discount_count_products',"
                            . "`discount_priority`='$discount_priority',"
                            . "`discount_coef1`='$discount_coef1',"
                            . "`discount_coef2` = '$discount_coef2', "
                            . "`discount_coef3` = '$discount_coef3', "
                            . "`discount_type1` = '$discount_type1', "
                            . "`discount_type2` = '$discount_type2', "
                            . "`discount_type3` = '$discount_type3', "
                            . "`customer_groups` = '$customer_groups', "
                            . "`status` = '$status'"
                            . "WHERE `discount_id` = '" . (int) $products_discount['discount_id'] . "' AND `editor_id` = '" . (int) $editor_key . "'");
                }
            }
        }

        $shops_all = isset($products_discount['shops_all']) ? $products_discount['shops_all'] : 0;


        $this->db->query("UPDATE `" . DB_PREFIX . "hd_product` SET `name` = '" . $this->db->escape(json_encode($products_discount['name'])) . "',"
                . " `description` = '" . $this->db->escape($products_discount['description']) . "',"
                . " `shops_all` = '" . $shops_all . "' "
                . "  WHERE `id` = '" . (int) $products_discount['discount_id'] . "'");
    }

    public function getProductsDiscount($products_discount_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hd_product` WHERE `id` = '" . (int) $products_discount_id . "'");

        if ($query->row) {
            return $query->row;
        } else {
            return array();
        }
    }

    public function getProductsDiscountEditors($products_discount_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hd_product_discount_editor` WHERE `discount_id` = '" . (int) $products_discount_id . "'");

        if ($query->rows) {
            return $query->rows;
        } else {
            return array();
        }
    }

    public function deleteProductsDiscount($products_discount_id) {
        $this->db->query("DELETE FROM " . DB_PREFIX . "hd_product_discount_editor WHERE `discount_id`='" . (int) $products_discount_id . "'");
        $this->db->query("DELETE FROM " . DB_PREFIX . "hd_product WHERE id = '" . (int) $products_discount_id . "'");
    }

    public function editClientGroups($discount_id, $groups, $url) {
        $this->db->query("UPDATE `" . DB_PREFIX . "hd_product` SET `customers_filter_url`='$url',`customers` = '" . $this->db->escape(json_encode($groups)) . "',`customers_all`='0' WHERE `id` = '" . (int) $discount_id . "'");
    }

    public function getClientGroups($discount_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hd_product` WHERE `id` = '" . (int) $discount_id . "';");
        //   var_dump($query->row['customers_ids']);
        if ($query->row['customers_ids'] && !empty($query->row['customers_ids'])) {
            return json_decode($query->row['customers_ids'], true);
        } else {
            return array();
        }
    }

    public function editDiscountEditorGroupProducts($discount_id, $groups, $url) {

        $query = $this->db->query("SELECT `discount_id`,`products` FROM `" . DB_PREFIX . "hd_product_discount_editor` WHERE `id` = '" . (int) $discount_id . "' ");

        if ($query->row) {
            $this->db->query("UPDATE `" . DB_PREFIX . "hd_product_discount_editor` SET `products_filter_url`='$url', `products` = '" . $this->db->escape(json_encode($groups)) . "' WHERE `id` = '" . (int) $discount_id . "'");
        } else {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "hd_product_discount_editor` SET `products_filter_url`='$url', `id` = '" . (int) $discount_id . "',`products` = '" . $this->db->escape(json_encode($groups)) . "'");
        }
         return $query->row['discount_id'];
    }
    public function getGroupIdDiscount($discount_id)
    {
        $query = $this->db->query("SELECT `discount_id` FROM `" . DB_PREFIX . "hd_product_discount_editor` WHERE `id` = '" . (int) $discount_id . "' ");
        return $query->row['discount_id'];
    }

    public function getProductFilterUrl($discount_id) {
        $query = $this->db->query("SELECT `products_filter_url` FROM `" . DB_PREFIX . "hd_product_discount_editor` WHERE `id` = '" . (int) $discount_id . "'");

        if (isset($query->row['products_filter_url']))
            return $query->row['products_filter_url'];
        else
            return false;
    }

    public function getClientFilterUrl($discount_id) {
        $query = $this->db->query("SELECT `customers_filter_url` FROM `" . DB_PREFIX . "hd_product` WHERE `id` = '" . (int) $discount_id . "';");

        if (isset($query->row['customers_filter_url']))
            return $query->row['customers_filter_url'];
        else
            return false;
    }

    public function ClearGroupProducts($discount_id) {
        $this->db->query("UPDATE `" . DB_PREFIX . "hd_product_discount_editor` SET `products` = '' WHERE `id` = '" . (int) $discount_id . "'");
    }

    public function getDiscountEditorGroupProducts($discount_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hd_product_discount_editor` WHERE `id` = '" . (int) $discount_id . "'");

        if ($query->row && $query->row['products']) {
            return json_decode($query->row['products'], true);
        } else {
            return array();
        }
    }

    public function editShopsList($discount_id, $groups) {

        $this->db->query("UPDATE `" . DB_PREFIX . "hd_product` SET `shops` = '" . $this->db->escape(json_encode($groups)) . "' WHERE `id` = '" . (int) $discount_id . "'");
    }

    public function getShopsList($discount_id) {
        $query = $this->db->query("SELECT shops FROM `" . DB_PREFIX . "hd_product` WHERE `id` = '" . (int) $discount_id . "'");

        if ($query->row['shops']) {
            return json_decode($query->row['shops'], true);
        } else {
            return array();
        }
    }

    public function getGeoList($discount_id) {
        $query = $this->db->query("SELECT geos FROM `" . DB_PREFIX . "hd_product` WHERE `id` = '" . (int) $discount_id . "'");

        if ($query->row['geos']) {
            return json_decode($query->row['geos'], true);
        } else {
            return array();
        }
    }

    public function editGeoList($discount_id, $groups) {

        $this->db->query("UPDATE `" . DB_PREFIX . "hd_product` SET `geos_all`='0',`geos` = '" . $this->db->escape(json_encode($groups)) . "' WHERE `id` = '" . (int) $discount_id . "'");
    }

}
