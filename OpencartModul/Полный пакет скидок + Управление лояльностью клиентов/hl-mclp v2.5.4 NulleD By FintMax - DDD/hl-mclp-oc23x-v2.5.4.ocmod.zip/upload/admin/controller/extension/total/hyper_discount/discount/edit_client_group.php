<?php

class ControllerExtensionTotalHyperDiscountDiscountEditClientGroup extends Controller {

    private $error = array();
    private $_text_string = array(
        'heading_titles',
        'column_names',
        'description_author',
        'hyper_discount_title',
        'filters_action',
        'filtered_clients',
        'filtered_clients_titles',
        'button_clears',
        'hyper_discount_name',
        'description_author_start',
        'description_author_copyright',
        'thank_you',
        'heading_action_text',
        'description_copyright',
        'text_lists', 'text_enabled',
        'text_disabled',
        'text_yes',
        'text_no',
        'text_default',
        'text_no_results',
        'text_confirm',
        'column_name',
        'column_email',
        'column_customer_group',
        'column_status',
        'column_approved',
        'column_ip',
        'column_date_added',
        'column_action',
        'entry_name',
        'entry_email',
        'entry_customer_group',
        'entry_status',
        'entry_approved',
        'entry_ip',
        'entry_date_added',
        'button_apply',
        'button_save',
        'button_cancel',
        'button_approve',
        'button_add',
        'button_edit',
        'button_delete',
        'button_filter',
        'button_login',
        'button_unlock',
        'help_name',
        'help_name_titles',
        'help_name_title',
        'help_text',
        'help_first_text',
        'help_second_text',
        'help_third_text',
        'help_fourth_text',
        'help_fifth_text',
        'help_end_text',
        'help_ok',
    );

    public function clear() {
        $url = '';

        $data['url_params'] = '';
        if (isset($this->request->get['user_discount_id'])) {
            $data['url_params'] .= '&user_discount_id=' . $this->request->get['user_discount_id'];
        } elseif (isset($this->request->get['accumulative_discount_id'])) {
            $data['url_params'] .= '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'];
        } elseif (isset($this->request->get['quantitative_discount_id'])) {
            $data['url_params'] .= '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'];
        }

        $url .= $data['url_params'];

        $this->session->data['editable_clients'] = array();

        $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . $url, 'SSL'));
    }

    public function deleteUnselected() {
        if (isset($this->request->post['editable_clients']) && !empty($this->request->post['editable_clients'])) {
            $edit_clients = explode(',', $this->request->post['editable_clients']);
            if (isset($this->request->post['selected']) && is_array($this->request->post['selected']))
                $selected = $this->request->post['selected'];
            else
                $selected = array();

            $unselected = array_diff($edit_clients, $selected);

            if (isset($this->session->data['editable_clients']) && $this->session->data['editable_clients'] !== FALSE) {
                $this->session->data['editable_clients'] = array_merge($this->session->data['editable_clients'], $selected);

                if (count($this->session->data['editable_clients']))
                    $this->session->data['editable_clients'] = array_diff($this->session->data['editable_clients'], $unselected);
                else
                    $this->session->data['editable_clients'] = array_diff($edit_clients, $unselected);
            }
        }
    }

    public function index() {

        $this->document->addStyle('view/javascript/bootstrap/css/bootstrap-multiselect.css');
        $this->document->addScript('view/javascript/bootstrap/js/bootstrap-multiselect.js');
        $this->document->addStyle('view/stylesheet/hyper_loyalty.css');

        $this->load->language('customer/customer');
        $this->load->language('extension/total/hyper_discount/discount/edit_client_group');
        $this->load->model('customer/customer');
        $this->load->language('customer/customer_group');

        foreach ($this->_text_string as $text) {
            $data[$text] = $this->language->get($text);
        }
        $this->document->setTitle($this->language->get('heading_titles'));

        $data['url_params'] = '';

        if (isset($this->request->get['user_discount_id'])) {
            $data['save_all_filtered_clients'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group/allFilteredClients', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');
            $data['action_save'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');
            $data['cancel'] = $this->url->link('extension/total/hyper_discount/discount/users/edit_users_discount', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');
            $data['discount_action'] = 'users';
            $data['update_stay'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group/update', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');

            $this->load->model('extension/total/hyper_discount/users_discount');

            $data['selected'] = $this->model_extension_total_hyper_discount_users_discount->getClientGroups($this->request->get['user_discount_id']);

            $data['url_params'] .= '&user_discount_id=' . $this->request->get['user_discount_id'];
        } elseif (isset($this->request->get['accumulative_discount_id'])) {
            $data['save_all_filtered_clients'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group/allFilteredClients', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
            $data['action_save'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
            $data['cancel'] = $this->url->link('extension/total/hyper_discount/discount/accumulative/edit_accumulative_discount', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
            $data['discount_action'] = 'accumulative';
            $data['update_stay'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group/update', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');

            $this->load->model('extension/total/hyper_discount/accumulative_discount');

            $data['selected'] = $this->model_extension_total_hyper_discount_accumulative_discount->getClientGroups($this->request->get['accumulative_discount_id']);

            $data['url_params'] .= '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'];
        } elseif (isset($this->request->get['quantitative_discount_id'])) {
            $data['save_all_filtered_clients'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group/allFilteredClients', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'], 'SSL');
            $data['action_save'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'], 'SSL');
            $data['cancel'] = $this->url->link('extension/total/hyper_discount/discount/quantitative/edit_quantitative_discount', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'], 'SSL');
            $data['discount_action'] = 'quantitative';
            $data['update_stay'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group/update', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'], 'SSL');

            $this->load->model('extension/total/hyper_discount/quantitative_discount');

            $data['selected'] = $this->model_extension_total_hyper_discount_quantitative_discount->getClientGroups($this->request->get['quantitative_discount_id']);

            $data['url_params'] .= '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'];
        } elseif (isset($this->request->get['kit_discount_id'])) {
            $data['save_all_filtered_clients'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group/allFilteredClients', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'], 'SSL');
            $data['action_save'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'], 'SSL');
            $data['cancel'] = $this->url->link('extension/total/hyper_discount/discount/kit/edit_kit_discount', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'], 'SSL');
            $data['discount_action'] = 'kit';
            $data['update_stay'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group/update', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'], 'SSL');

            $this->load->model('extension/total/hyper_discount/kit_discount');

            $data['selected'] = $this->model_extension_total_hyper_discount_kit_discount->getClientGroups($this->request->get['kit_discount_id']);

            $data['url_params'] .= '&kit_discount_id=' . $this->request->get['kit_discount_id'];
        }
// var_dump( $data['selected']);
        if (isset($this->session->data['editable_clients']) && $this->session->data['editable_clients'] !== FALSE)
            $data['selected'] = $this->session->data['editable_clients'];
        else
            $this->session->data['editable_clients'] = $data['selected'];

        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_email'])) {
            $url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_customer_group_id'])) {
            foreach ($this->request->get['filter_customer_group_id'] as $gr)
                $url .= '&filter_customer_group_id[]=' . $gr;
        }

        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }

        if (isset($this->request->get['filter_approved'])) {
            $url .= '&filter_approved=' . $this->request->get['filter_approved'];
        }

        if (isset($this->request->get['filter_ip'])) {
            $url .= '&filter_ip=' . $this->request->get['filter_ip'];
        }

        if (isset($this->request->get['filter_date_added'])) {
            $url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        //permission
        if (isset($this->request->post['discount_action']) && !$this->validateForm()) {
            $this->session->data['error'] = $this->error;
            $this->response->redirect($this->url->link('extension/total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
        }
        //permission
        //SAVE
        else if (isset($this->request->post['discount_action']) && $this->validateForm()) {
            $this->deleteUnselected();

            $form_action = $this->request->post['discount_action'];

            $groups = $this->session->data['editable_clients'];

            $this->session->data['editable_clients'] = FALSE;

            if ($form_action == 'users') {
                $this->load->model('extension/total/hyper_discount/users_discount');

                $this->model_extension_total_hyper_discount_users_discount->editClientGroups($this->request->get['user_discount_id'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/users/edit_users_discount', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL'));
            } elseif ($form_action == 'accumulative') {
                $this->load->model('extension/total/hyper_discount/accumulative_discount');

                $this->model_extension_total_hyper_discount_accumulative_discount->editClientGroups($this->request->get['accumulative_discount_id'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/accumulative/edit_accumulative_discount', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL'));
            } elseif ($form_action == 'quantitative') {
                $this->load->model('extension/total/hyper_discount/quantitative_discount');

                $this->model_extension_total_hyper_discount_quantitative_discount->editClientGroups($this->request->get['quantitative_discount_id'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/quantitative/edit_quantitative_discount', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'], 'SSL'));
            } elseif ($form_action == 'kit') {
                $this->load->model('extension/total/hyper_discount/kit_discount');

                $this->model_extension_total_hyper_discount_kit_discount->editClientGroups($this->request->get['kit_discount_id'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/kit/edit_kit_discount', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'], 'SSL'));
            }
        }

        if (isset($this->request->get['filter_name'])) {
            $filter_name = $this->request->get['filter_name'];
        } else {
            $filter_name = null;
        }

        if (isset($this->request->get['filter_email'])) {
            $filter_email = $this->request->get['filter_email'];
        } else {
            $filter_email = null;
        }

        if (isset($this->request->get['filter_customer_group_id'])) {
            $filter_customer_group_id = $this->request->get['filter_customer_group_id'];
        } else {
            $filter_customer_group_id = array();
        }

        if (isset($this->request->get['filter_status'])) {
            $filter_status = $this->request->get['filter_status'];
        } else {
            $filter_status = null;
        }

        if (isset($this->request->get['filter_approved'])) {
            $filter_approved = $this->request->get['filter_approved'];
        } else {
            $filter_approved = null;
        }

        if (isset($this->request->get['filter_ip'])) {
            $filter_ip = $this->request->get['filter_ip'];
        } else {
            $filter_ip = null;
        }

        if (isset($this->request->get['filter_date_added'])) {
            $filter_date_added = $this->request->get['filter_date_added'];
        } else {
            $filter_date_added = null;
        }

        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'name';
        }

        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'ASC';
        }

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $url .= $data['url_params'];

        $data['customers'] = array();

        if (count($filter_customer_group_id)) {
            if (array_search('*', $filter_customer_group_id) !== FALSE)
                $string_filter_customer_group_id = NULL;
            else
                $string_filter_customer_group_id = implode(',', $filter_customer_group_id);
        } else
            $string_filter_customer_group_id = NULL;

        $limit = $this->config->get('config_limit_admin');

        $filter_data = array(
            'filter_name' => $filter_name,
            'filter_email' => $filter_email,
            'filter_customer_group_id' => $string_filter_customer_group_id,
            'filter_status' => $filter_status,
            'filter_approved' => $filter_approved,
            'filter_date_added' => $filter_date_added,
            'filter_ip' => $filter_ip,
            'sort' => $sort,
            'order' => $order,
            'start' => ($page - 1) * $limit,
            'limit' => $limit
        );

        $this->load->model('extension/total/hyper_discount/customer');

        $customer_total = $this->model_extension_total_hyper_discount_customer->getTotalCustomers($filter_data);

        $results = $this->model_extension_total_hyper_discount_customer->getCustomers($filter_data);

        $data['cust_ids'] = array();
        foreach ($results as $result) {
            if (!$result['approved']) {
                $approve = $this->url->link('customer/customer/approve', 'token=' . $this->session->data['token'] . '&customer_id=' . $result['customer_id'] . $url, 'SSL');
            } else {
                $approve = '';
            }

            $login_info = $this->model_customer_customer->getTotalLoginAttempts($result['email']);

            if ($login_info && $login_info['total'] >= $this->config->get('config_login_attempts')) {
                $unlock = $this->url->link('customer/customer/unlock', 'token=' . $this->session->data['token'] . '&email=' . $result['email'] . $url, 'SSL');
            } else {
                $unlock = '';
            }

            $data['customers'][] = array(
                'customer_id' => $result['customer_id'],
                'name' => $result['name'],
                'email' => $result['email'],
                'customer_group' => $result['customer_group'],
                'status' => ($result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
                'ip' => $result['ip'],
                'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
                'approve' => $approve,
                'unlock' => $unlock,
                'edit' => $this->url->link('customer/customer/edit', 'token=' . $this->session->data['token'] . '&customer_id=' . $result['customer_id'] . $url, 'SSL')
            );

            $data['cust_ids'][] = $result['customer_id'];
        }
        $data['cust_ids'] = implode(',', $data['cust_ids']);

        $data['token'] = $this->session->data['token'];

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_email'])) {
            $url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_customer_group_id'])) {
            foreach ($this->request->get['filter_customer_group_id'] as $gr)
                $url .= '&filter_customer_group_id[]=' . $gr;
        }

        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }

        if (isset($this->request->get['filter_approved'])) {
            $url .= '&filter_approved=' . $this->request->get['filter_approved'];
        }

        if (isset($this->request->get['filter_ip'])) {
            $url .= '&filter_ip=' . $this->request->get['filter_ip'];
        }

        if (isset($this->request->get['filter_date_added'])) {
            $url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
        }

        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $url .= $data['url_params'];

        $data['sort_name'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&sort=name' . $url, 'SSL');
        $data['sort_email'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&sort=c.email' . $url, 'SSL');
        $data['sort_customer_group'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&sort=customer_group' . $url, 'SSL');
        $data['sort_status'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&sort=c.status' . $url, 'SSL');
        $data['sort_ip'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&sort=c.ip' . $url, 'SSL');
        $data['sort_date_added'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&sort=c.date_added' . $url, 'SSL');

        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_email'])) {
            $url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_customer_group_id'])) {
            foreach ($this->request->get['filter_customer_group_id'] as $gr)
                $url .= '&filter_customer_group_id[]=' . $gr;
        }

        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }

        if (isset($this->request->get['filter_approved'])) {
            $url .= '&filter_approved=' . $this->request->get['filter_approved'];
        }

        if (isset($this->request->get['filter_ip'])) {
            $url .= '&filter_ip=' . $this->request->get['filter_ip'];
        }

        if (isset($this->request->get['filter_date_added'])) {
            $url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        $url .= $data['url_params'];

        parse_str($url, $params);
        unset($params['page']);
        $url = '&' . http_build_query($params);

        $pagination = new Pagination();
        $pagination->total = $customer_total;
        $pagination->page = $page;
        $pagination->limit = $limit;
        $pagination->url = $this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSL');

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($customer_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($customer_total - $this->config->get('config_limit_admin'))) ? $customer_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $customer_total, ceil($customer_total / $this->config->get('config_limit_admin')));

        $data['filter_name'] = $filter_name;
        $data['filter_email'] = $filter_email;
        $data['filter_customer_group_id'] = $filter_customer_group_id;
        $data['filter_status'] = $filter_status;
        $data['filter_approved'] = $filter_approved;
        $data['filter_ip'] = $filter_ip;
        $data['filter_date_added'] = $filter_date_added;

        $this->load->model('customer/customer_group');

        $data['customer_groups'] = $this->model_customer_customer_group->getCustomerGroups();

        $this->load->model('setting/store');

        $data['stores'] = $this->model_setting_store->getStores();

        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/total/hyper_discount/discount/edit_client_group.tpl', $data));
    }

    public function allFilteredClients() {
        if (isset($this->request->post['filter_name'])) {
            $filter_name = $this->request->post['filter_name'];
        } else {
            $filter_name = null;
        }

        if (isset($this->request->post['filter_email'])) {
            $filter_email = $this->request->post['filter_email'];
        } else {
            $filter_email = null;
        }

        if (isset($this->request->post['filter_customer_group_id']) && $this->request->post['filter_customer_group_id'] != '*') {
            $filter_customer_group_id = $this->request->post['filter_customer_group_id'];
        } else {
            $filter_customer_group_id = array();
        }

        if (isset($this->request->post['filter_status']) && $this->request->post['filter_status'] != '*') {
            $filter_status = $this->request->post['filter_status'];
        } else {
            $filter_status = null;
        }

        if (isset($this->request->post['filter_approved']) && $this->request->post['filter_approved'] != '*') {
            $filter_approved = $this->request->post['filter_approved'];
        } else {
            $filter_approved = null;
        }

        if (isset($this->request->post['filter_ip'])) {
            $filter_ip = $this->request->post['filter_ip'];
        } else {
            $filter_ip = null;
        }

        if (isset($this->request->post['filter_date_added'])) {
            $filter_date_added = $this->request->post['filter_date_added'];
        } else {
            $filter_date_added = null;
        }

        $data['customers'] = array();

        if (count($filter_customer_group_id)) {
            if (array_search('*', $filter_customer_group_id) !== FALSE)
                $string_filter_customer_group_id = NULL;
            else
                $string_filter_customer_group_id = implode(',', $filter_customer_group_id);
        } else
            $string_filter_customer_group_id = NULL;

        $filter_data = array(
            'filter_name' => $filter_name,
            'filter_email' => $filter_email,
            'filter_customer_group_id' => $string_filter_customer_group_id,
            'filter_status' => $filter_status,
            'filter_approved' => $filter_approved,
            'filter_date_added' => $filter_date_added,
            'filter_ip' => $filter_ip,
            'start' => 0,
            'limit' => 100000
        );

//        $this->load->model('customer/customer');

        $this->load->model('extension/total/hyper_discount/customer');

        $results = $this->model_extension_total_hyper_discount_customer->getCustomers($filter_data);

        $url = '';

        if (isset($this->request->post['filter_name']) && !empty($this->request->post['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->post['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->post['filter_email']) && !empty($this->request->post['filter_email'])) {
            $url .= '&filter_email=' . urlencode(html_entity_decode($this->request->post['filter_email'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->post['filter_customer_group_id'])) {
            foreach ($this->request->post['filter_customer_group_id'] as $gr)
                $url .= '&filter_customer_group_id[]=' . $gr;
        }

        if (isset($this->request->post['filter_status']) && !empty($this->request->post['filter_status']) && $this->request->post['filter_status'] != '*') {
            $url .= '&filter_status=' . $this->request->post['filter_status'];
        }

        if (isset($this->request->post['filter_approved']) && !empty($this->request->post['filter_approved']) && $this->request->post['filter_approved'] != '*') {
            $url .= '&filter_approved=' . $this->request->post['filter_approved'];
        }

        if (isset($this->request->post['filter_ip']) && !empty($this->request->post['filter_ip'])) {
            $url .= '&filter_ip=' . $this->request->post['filter_ip'];
        }

        if (isset($this->request->post['filter_date_added']) && !empty($this->request->post['filter_date_added'])) {
            $url .= '&filter_date_added=' . $this->request->post['filter_date_added'];
        }

        if (isset($this->request->post['sort']) && !empty($this->request->post['sort'])) {
            $url .= '&sort=' . $this->request->post['sort'];
        }

        if (isset($this->request->post['order']) && !empty($this->request->post['order'])) {
            $url .= '&order=' . $this->request->post['order'];
        }

        if (isset($this->request->post['page']) && !empty($this->request->post['page'])) {
            $url .= '&page=' . $this->request->post['page'];
        }

        $groups = array();

        foreach ($results as $result) {
            $groups[] = $result['customer_id'];
        }

        if (isset($this->request->post['discount_action'])) {
            $form_action = $this->request->post['discount_action'];

            $editable_clients = isset($this->request->post['editable_clients']) ? $this->request->post['editable_clients'] : null;

            $this->session->data['editable_clients'] = $groups;

            if ($form_action == 'users') {
                $this->load->model('extension/total/hyper_discount/users_discount');

                //$this->model_extension_total_hyper_discount_users_discount->editClientGroups($this->request->get['user_discount_id'], $groups, $editable_clients);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'] . $url, 'SSL'));
            } elseif ($form_action == 'accumulative') {
                $this->load->model('extension/total/hyper_discount/accumulative_discount');

                //$this->model_extension_total_hyper_discount_accumulative_discount->editClientGroups($this->request->get['accumulative_discount_id'], $groups, $editable_clients);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'] . $url, 'SSL'));
            } elseif ($form_action == 'quantitative') {
                $this->load->model('extension/total/hyper_discount/quantitative_discount');

                //$this->model_extension_total_hyper_discount_quantitative_discount->editClientGroups($this->request->get['quantitative_discount_id'], $groups, $editable_clients);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'] . $url, 'SSL'));
            } elseif ($form_action == 'kit') {
                $this->load->model('extension/total/hyper_discount/kit_discount');

                //$this->model_extension_total_hyper_discount_kit_discount->editClientGroups($this->request->get['kit_discount_id'], $groups, $editable_clients);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'] . $url, 'SSL'));
            }
        }
    }

    public function update() {
        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_email'])) {
            $url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_customer_group_id'])) {
            foreach ($this->request->get['filter_customer_group_id'] as $gr)
                $url .= '&filter_customer_group_id[]=' . $gr;
        }

        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }

        if (isset($this->request->get['filter_approved'])) {
            $url .= '&filter_approved=' . $this->request->get['filter_approved'];
        }

        if (isset($this->request->get['filter_ip'])) {
            $url .= '&filter_ip=' . $this->request->get['filter_ip'];
        }

        if (isset($this->request->get['filter_date_added'])) {
            $url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $this->deleteUnselected();

        $form_action = $this->request->post['discount_action'];

        $groups = $this->session->data['editable_clients'];

        $this->session->data['editable_clients'] = FALSE;

        //permission
        if (!$this->validateForm()) {
            $this->session->data['error'] = $this->error;
            $this->response->redirect($this->url->link('extension/total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
        }
        //permission
        else if ($form_action == 'users' && $this->validateForm()) {
            $this->load->model('extension/total/hyper_discount/users_discount');

            $this->model_extension_total_hyper_discount_users_discount->editClientGroups($this->request->get['user_discount_id'], $groups, $url);

            $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'] . $url, 'SSL'));
        } elseif ($form_action == 'accumulative' && $this->validateForm()) {
            $this->load->model('extension/total/hyper_discount/accumulative_discount');

            $this->model_extension_total_hyper_discount_accumulative_discount->editClientGroups($this->request->get['accumulative_discount_id'], $groups, $url);

            $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'] . $url, 'SSL'));
        } elseif ($form_action == 'quantitative' && $this->validateForm()) {
            $this->load->model('extension/total/hyper_discount/quantitative_discount');

            $this->model_extension_total_hyper_discount_quantitative_discount->editClientGroups($this->request->get['quantitative_discount_id'], $groups, $url);

            $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'] . $url, 'SSL'));
        } elseif ($form_action == 'kit' && $this->validateForm()) {
            $this->load->model('extension/total/hyper_discount/kit_discount');

            $this->model_extension_total_hyper_discount_kit_discount->editClientGroups($this->request->get['kit_discount_id'], $groups, $url);

            $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'] . $url, 'SSL'));
        }
    }

    protected function validateForm() {
        $this->language->load('extension/total/hyper_discount');

        if (!$this->user->hasPermission('modify', 'extension/total/hyper_discount'))
            $this->error['warning'] = $this->language->get('error_permission');

        return !$this->error;
    }

}
