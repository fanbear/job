<?php
class ControllerExtensionTotalHyperDiscountAbouts extends Controller{

    public function index() {

    }

}