<?php

class ControllerExtensionTotalHyperDiscountDiscountKitAddKitDiscount extends Controller
{
    private $error = array();
    private $_text_string = array(
        'add_name',
        'hyper_discount_name',
        'hyper_discount_title',
        'button_save',
        'button_cancel',
        'kit_discount_text',
        'heading_action_text',
    // Help
        'help_name',
        'help_name_titles',
        'help_name_title',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
    // Help Users
        'help_name_kit',
        'help_first_kit',
        'help_second_kit',
        'entry_title',
        'entry_description',
        'description_author',
        'description_author_start',
        'description_author_copyright',
        'thank_you',
        'heading_action_text',
        'description_copyright',
    );

    public function index()
    {
        $this->load->language('extension/total/hyper_discount/discount/kit/add_kit_discount');

        $this->document->addStyle('view/stylesheet/hyper_loyalty.css');
        //permission
        if ($this->request->server['REQUEST_METHOD'] == 'POST' && !$this->validateForm())
        {
            $this->session->data['error']=$this->error;
            $this->response->redirect($this->url->link('extension/total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
        }
        //permission
        else if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm())
        {
            $this->load->model('extension/total/hyper_discount/kit_discount');

            $this->model_extension_total_hyper_discount_kit_discount->addKitDiscount($this->request->post['kit_discount']);
            $this->response->redirect($this->url->link('extension/total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-discount-kit', 'SSL'));
        }


        $this->document->setTitle($this->language->get('heading_title'));

        foreach ($this->_text_string as $text)
        {
            $data[$text] = $this->language->get($text);
        }

        $data['action'] = $this->url->link('extension/total/hyper_discount/discount/kit/add_kit_discount', 'token=' . $this->session->data['token'] . '&tab=tab-discount-kit', 'SSL');
        $data['cancel'] = $this->url->link('extension/total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-discount-kit', 'SSL');
        $data['edit_shops_list'] = $this->url->link('extension/total/hyper_discount/discount/edit_shops_list', 'token=' . $this->session->data['token'], 'SSL');
        $data['edit_product_groups'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'], 'SSL');

        $this->load->model('localisation/language');

        $data['languages'] = $this->model_localisation_language->getLanguages();

        $data['lang'] = $this->language->get('lang');

        $data['config_language_id'] = $this->config->get('config_language_id');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/total/hyper_discount/discount/kit/add_kit_discount.tpl', $data));
    }

    protected function validateForm()
    {
        if (!$this->user->hasPermission('modify', 'extension/total/hyper_discount'))
            $this->error['warning'] = $this->language->get('error_permission');

        foreach ($this->request->post['kit_discount']['name'] as $language_id => $value)
        {
            if ((utf8_strlen($value) < 3) || (utf8_strlen($value) > 255))
            {
                $this->error['warning'] = $this->language->get('error_name');
            }
        }

        if ($this->error && !isset($this->error['warning']))
        {
            $this->error['warning'] = $this->language->get('error_warning');
        }

        return !$this->error;
    }

}
