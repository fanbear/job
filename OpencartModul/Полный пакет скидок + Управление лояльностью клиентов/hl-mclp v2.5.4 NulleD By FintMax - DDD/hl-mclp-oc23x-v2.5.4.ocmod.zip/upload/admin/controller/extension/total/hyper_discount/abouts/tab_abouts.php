<?php

class ControllerExtensionTotalHyperDiscountAboutsTabAbouts extends Controller
{

    private $_text_string = array(
        'text_abouts',
        'heading_text_name',
        'hd_description',
        'activation_key_name',
        'description_name',
        'description_start',
        'description_warning',
        'description_warning_start',
        'hyper_discount_name',
        'hyper_discount_title',
        'description_author',
        'description_author_start',
        'description_author_copyright',
        'heading_action_text',
        'description_copyright',
        // Buttons
        'button_out',
        'name_key',
        'save_key',
        // Help
        'help_name',
        'help_list',
        'help_name_abouts',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
    );

    public function index()
    {
        $this->load->language('extension/total/hyper_discount/abouts/tab_abouts');

        foreach ($this->_text_string as $text)
        {
            $data[$text] = $this->language->get($text);
        }

        $data['cancel'] = $this->url->link('extension/total', 'type=total&token=' . $this->session->data['token'], 'SSL');

        $this->load->model('extension/total/hyper_discount/discount');
		$this->load->model('extension/total/hyper_discount/setting');

        $settings = $this->model_extension_total_hyper_discount_setting->getSetting();


        $data['tmp'] = 'tmp';

        return $this->load->view('extension/total/hyper_discount/abouts/tab_abouts.tpl', $data);
    }

}
