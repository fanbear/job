<?php

class ControllerExtensionTotalHyperDiscountSupplementTabSupplement extends Controller
{

    private $_text_string = array(
        'text_abouts',
        'hd_supplement',
        'supplement_title',
        'supplement_name',
        'supplement_title',
        'supplement_start',
        'supplement_warning',
        'supplement_warning_start',
        // Help
        'help_name',
        'help_name_title',
        //'help_name_titles',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
    );

    public function index()
    {
        $this->load->language('extension/total/hyper_discount/supplement/tab_supplement');

        foreach ($this->_text_string as $text)
        {
            $data[$text] = $this->language->get($text);
        }


        $data['tmp'] = 'tmp';

        return $this->load->view('extension/total/hyper_discount/supplement/tab_supplement.tpl', $data);
    }

}
