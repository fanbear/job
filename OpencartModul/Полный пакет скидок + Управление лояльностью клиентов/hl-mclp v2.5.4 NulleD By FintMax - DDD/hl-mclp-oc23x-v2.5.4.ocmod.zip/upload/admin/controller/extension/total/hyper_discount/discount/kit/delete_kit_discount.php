<?php

class ControllerExtensionTotalHyperDiscountDiscountKitDeleteKitDiscount extends Controller
{
    private $error = array();
    public function index()
    {
        //permission
        if (isset($this->request->get['kit_discount_id']) && !$this->validateForm())
        {
            $this->session->data['error']=$this->error;
            $this->response->redirect($this->url->link('extension/total/hyper_discount/error', 'token=' . $this->session->data['token']. '&tab=tab-discount-kit', 'SSL'));
        }
        //permission
        else if (isset($this->request->get['kit_discount_id']) && $this->validateForm())
        {
            $this->load->model('extension/total/hyper_discount/kit_discount');
            $this->model_extension_total_hyper_discount_kit_discount->deleteKitDiscount($this->request->get['kit_discount_id']);
        }

        $this->response->redirect($this->url->link('extension/total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-discount-kit', 'SSL'));
    }

    protected function validateForm()
    {
        $this->language->load('extension/total/hyper_discount');

        if (!$this->user->hasPermission('modify', 'extension/total/hyper_discount'))
            $this->error['warning'] = $this->language->get('error_permission');

        return !$this->error;
    }

}
