<?php
class ControllerExtensionTotalHyperDiscountSupplement extends Controller{

    public function index() {

    }

}