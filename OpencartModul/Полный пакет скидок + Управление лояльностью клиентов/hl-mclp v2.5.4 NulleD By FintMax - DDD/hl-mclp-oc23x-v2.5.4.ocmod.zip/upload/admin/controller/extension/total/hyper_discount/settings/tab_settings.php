<?php
class ControllerExtensionTotalHyperDiscountSettingsTabSettings extends Controller {

    public function index() {

        $data['tmp'] = 'tmp';

        return $this->load->view('extension/total/hyper_discount/settings/tab_settings.tpl', $data);
    }

}