<?php

class ControllerExtensionTotalHyperDiscountDiscountAccumulativeEditAccumulativeDiscount extends Controller {

    private $error = array();
    private $_text_string = array(
        'hyper_discount_name',
        'hyper_discount_title',
        'heading_text_title',
        'settings_text',
        'heading_action_text',
        'discount_editor_text',
        'column_delete',
        'column_delete_titles',
        // Buttons
        'button_save',
        'button_cancel',
        'button_apply',
        'button_remove',
        'button_add',
        'button_edit_shops_list',
        'button_edit_geo_list',
        'button_users_groups_list',
        'button_client_group_list',
        'button_product_group_list',
        // For select
        'entry_title',
        'entry_title_titles',
        'entry_description',
        'entry_description_titles',
        'entry_shops',
        'entry_shops_titles',
        'entry_geo',
        'entry_geo_titles',
        'entry_users_groups',
        'entry_users_groups_titles',
        'entry_client_group',
        'entry_client_group_titles',
        'entry_variant_accumulative',
        'entry_variant_accumulative_titles',
        'entry_client_status',
        'entry_client_status_titles',
        'entry_discount_sum',
        'entry_discount_sum_titles',
        'entry_date_available',
        'entry_accumulative_condition',
        'entry_accumulative_condition_titles',
        'entry_product_groups',
        'entry_product_groups_titles',
        'entry_sum_status_orders',
        'entry_sum_status_orders_titles',
        'entry_sum_data_orders_titles',
        'entry_discounts',
        'entry_discounts_titles',
        'name_function_orders',
        'accumulative_price_correction_titles',
        'name_function_orders_titles',
        'name_function_products',
        'name_function_products_titles',
        'name_function_sum',
        'name_function_sum_titles',
        'entry_options',
        'entry_options_titles',
        'entry_stock',
        'entry_stock_titles',
        'entry_users_variants',
        'entry_users_variants_titles',
        'entry_product_group',
        'entry_product_group_titles',
        'entry_discount_percent',
        'entry_discount_percent_titles',
        'entry_discount_editor_status',
        'entry_discount_editor_status_titles',
        'entry_date',
        'entry_date_titles',
        'entry_date_start',
        'entry_date_end',
        // Help
        'help_name',
        'help_name_title',
        'help_name_titles',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help Users
        'help_name_accumulative',
        'help_first_accumulative',
        'help_second_accumulative',
        'info_first_accumulative',
        'info_second_accumulative',
        'info_third_accumulative',
        'info_fourth_accumulative',
        // Help Users One
        'help_name_accumulative_one',
        'helper_name_accumulative_one',
        'helpers_name_accumulative_one',
        'help_first_accumulative_one',
        'help_second_accumulative_one',
        'help_third_accumulative_one',
        'help_fourth_accumulative_one',
        'help_fifth_accumulative_one',
        'help_sixth_accumulative_one',
        'help_seventh_accumulative_one',
        'help_eighth_accumulative_one',
        'help_ninth_accumulative_one',
        'help_tenth_accumulative_one',
        'help_eleventh_accumulative_one',
        'help_twelfth_accumulative_one',
        'help_thirteenth_accumulative_one',
        'help_fourteenth_accumulative_one',
        'help_fifteenth_accumulative_one',
        'help_sixteenth_accumulative_one',
        'help_seventeenth_accumulative_one',
        'help_seventeenth_accumulative_one',
        'help_eighteenth_accumulative_one',
        'help_nineteenth_accumulative_one',
        'help_twentieth_accumulative_one',
        'help_twentyfirst_accumulative_one',
        'help_twentysecond_accumulative_one',


        // Help Users Two
        'help_name_accumulative_two',
        'help_first_accumulative_two',
        'help_second_accumulative_two',
        'help_third_accumulative_two',
        'help_fourth_accumulative_two',
        'help_fifth_accumulative_two',
        'help_sixth_accumulative_two',
        'help_seventh_accumulative_two',
        'help_eighth_accumulative_two',
        'help_ninth_accumulative_two',
        'help_tenth_accumulative_two',
        'help_eleventh_accumulative_two',
        'help_twelfth_accumulative_two',
        'help_thirteenth_accumulative_two',
        'help_fourteenth_accumulative_two',
        'help_fifteenth_accumulative_two',
        'help_sixteenth_accumulative_two',
        'help_seventeenth_accumulative_two',
        'help_eighteenth_accumulative_two',
        'help_nineteenth_accumulative_two',
        'help_twentieth_accumulative_two',
        'help_twentyfirst_accumulative_two',
        'help_twentysecond_accumulative_two',
        'help_twentythird_accumulative_two',
        'description_author',
        'description_author_start',
        'description_author_copyright',
        'thank_you',
        'heading_action_text',
        'description_copyright',
        //protected
        'protect_all',
        'protect_custom',
        'protect_default',
        'protect_active',
        'protect_ignore',
        'protect_active_plus',
        'protect_ignore_minus',
        'protect_priority',
        'protect_summary',
        'protect_discount',
        'protect_markup',
    );
    protected $_discount_function = array('protect_all', 'protect_custom');
    protected $_discounts = array('protect_active', 'protect_ignore', 'protect_priority', 'protect_summary');
    protected $_options = array('protect_active', 'protect_ignore');
    protected $_specials = array('protect_active', 'protect_ignore', 'protect_summary');
    protected $_discount_condition = array('protect_discount', 'protect_markup');
    protected $_discount_specials_condition = array('protect_priority', 'protect_default');
    protected $_discount_types = array("%", "each fix", "full fix");

    public function index() {
         $this->load->language('extension/total/hyper_discount/discount/accumulative/add_accumulative_discount');

        $this->session->data['editable_prods'] = FALSE;
        $this->session->data['editable_clients'] = FALSE;
        // 
        $all_protected_arr = array(
            '_discount_function',
            '_discounts',
            '_options',
            '_specials',
            '_discount_condition',
            '_discount_specials_condition'
        );

        foreach ($all_protected_arr as $arr_name)
            foreach ($this->$arr_name as $key => $val) {
                $arr = &$this->$arr_name;
                $arr[$val] = $this->language->get($val);
                unset($arr[$key]);
            }
        //
        $this->document->addStyle('view/stylesheet/hyper_loyalty.css');
        $this->document->addStyle('view/javascript/bootstrap/css/bootstrap-switch.min.css');
        $this->document->addStyle('view/javascript/bootstrap/css/bootstrap-multiselect.css');
        $this->document->addScript('view/javascript/bootstrap/js/bootstrap-switch.min.js');
        $this->document->addScript('view/javascript/bootstrap/js/bootstrap-multiselect.js');

        $this->load->model('extension/total/hyper_discount/accumulative_discount');
        //permission
        if ($this->request->server['REQUEST_METHOD'] == 'POST' && !$this->validateForm()) {
            $this->session->data['error'] = $this->error;
            $this->response->redirect($this->url->link('extension/total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
        }
        //permission
        else if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validateForm()) {
            $this->model_extension_total_hyper_discount_accumulative_discount->editAccumulativeDiscount($this->request->post['accumulative_discount']);
            $this->response->redirect($this->url->link('extension/total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-discount-accumulative', 'SSL'));
        } elseif (isset($this->request->get['accumulative_discount_id'])) {
            $discount_settings = $this->model_extension_total_hyper_discount_accumulative_discount->getAccumulativeDiscount($this->request->get['accumulative_discount_id']);

            $discount_editor = $this->model_extension_total_hyper_discount_accumulative_discount->getAccumulativeDiscountEditors($this->request->get['accumulative_discount_id']);

            $data['accumulative_discount'] = array(
                'discount_id' => $discount_settings['id'],
                'name' => ($discount_settings['name']) ? json_decode($discount_settings['name'], true) : null,
                'description' => ($discount_settings['description']) ? $discount_settings['description'] : null,
                'sort' => isset($discount_settings['sort']) ? $discount_settings['sort'] : null,
                'status' => isset($discount_settings['status']) ? $discount_settings['status'] : null,
                'correction' => ($discount_settings['correction']) ? $discount_settings['correction'] : null,
                'geos_all' => ($discount_settings['geos_all']) ? $discount_settings['geos_all'] : false,
                'shops_all' => isset($discount_settings['shops_all']) ? $discount_settings['shops_all'] : null,
                'customers_all' => isset($discount_settings['customers_all']) ? $discount_settings['customers_all'] : null,
                'products_all' => isset($discount_settings['products_all']) ? $discount_settings['products_all'] : null,
                'order_statuses' => ($discount_settings['order_statuses']) ? json_decode($discount_settings['order_statuses'], true) : null,
                'discount_editor' => $discount_editor,
                
                'discount_variant_condition' => $discount_settings['discount_variant_condition'],
                'discount_variant_discount' => $discount_settings['discount_variant_discount'],
                'discount_variant_specials' => $discount_settings['discount_variant_specials'],
                'discount_variant_options' => $discount_settings['discount_variant_options'],
                
                'start_date' => $discount_settings['start_date'],
                'end_date' => $discount_settings['end_date']
            );
        }


        $this->document->setTitle($this->language->get('heading_title'));

        foreach ($this->_text_string as $text) {
            $data[$text] = $this->language->get($text);
        }

        $this->load->model('localisation/order_status');
        $this->load->model('extension/total/hyper_discount/accamulation_status');
        $accamulation_statuses_list = $this->model_extension_total_hyper_discount_accamulation_status->getAccamulationStatussList();

        $data['accamulation_statuses'] = array();

        foreach ($accamulation_statuses_list as $status) {
            $data['accamulation_statuses'][] = array(
                'statuses_id' => $status['id'],
                'name' => ($status['name']) ? json_decode($status['name'], true)[$this->config->get('config_language_id')] : null,
            );
        }

        $data['array_order_status'] = $this->model_localisation_order_status->getOrderStatuses();
        $data['array_discount_function'] = $this->_discount_function;
        $data['array_discounts'] = $this->_discounts;
        $data['array_options'] = $this->_options;
        $data['array_specials'] = $this->_specials;
        $data['array_discount_types'] = $this->_discount_types;
        $data['array_discount_condition'] = $this->_discount_condition;
        $data['array_discount_specials_condition'] = $this->_discount_specials_condition;

        $data['action'] = $this->url->link('extension/total/hyper_discount/discount/accumulative/edit_accumulative_discount', 'token=' . $this->session->data['token'], 'SSL');
        $data['update_stay'] = $this->url->link('extension/total/hyper_discount/discount/accumulative/edit_accumulative_discount/update', 'token=' . $this->session->data['token'], 'SSL');
        $data['cancel'] = $this->url->link('extension/total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-discount-accumulative', 'SSL');

        $data['edit_geo_list'] = $this->url->link('extension/total/hyper_discount/discount/edit_geo_list', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
        $data['edit_shops_list'] = $this->url->link('extension/total/hyper_discount/discount/edit_shops_list', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
//        $data['edit_users_groups'] = $this->url->link('extension/total/hyper_discount/discount/edit_users_groups', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
        $data['edit_client_group'] = $this->url->link('extension/total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
        $data['edit_product_groups'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
        $data['discount_editor_edit_product_groups'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');

        $product_filter_url = $this->model_extension_total_hyper_discount_accumulative_discount->getProductFilterUrl($this->request->get['accumulative_discount_id']);
        if ($product_filter_url)
            $data['edit_product_groups'] .= $product_filter_url;

        $client_filter_url = $this->model_extension_total_hyper_discount_accumulative_discount->getClientFilterUrl($this->request->get['accumulative_discount_id']);
        if ($client_filter_url)
            $data['edit_client_group'] .= $client_filter_url;


        $this->load->model('localisation/language');

        $data['languages'] = $this->model_localisation_language->getLanguages();

        $data['lang'] = $this->language->get('lang');

        $data['config_language_id'] = $this->config->get('config_language_id');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/total/hyper_discount/discount/accumulative/accumulative_discount_form.tpl', $data));
    }

    public function update() {
        //permisson
        if ($this->request->server['REQUEST_METHOD'] == 'POST' && isset($this->request->post['accumulative_discount']['discount_id']) && !$this->validateForm()) {
            $this->session->data['error'] = $this->error;
            $this->response->redirect($this->url->link('extension/total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
        }
        //
        else if ($this->request->server['REQUEST_METHOD'] == 'POST' && isset($this->request->post['accumulative_discount']['discount_id']) && $this->validateForm()) {
            $this->load->model('extension/total/hyper_discount/accumulative_discount');

            $this->model_extension_total_hyper_discount_accumulative_discount->editAccumulativeDiscount($this->request->post['accumulative_discount']);
            $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/accumulative/edit_accumulative_discount', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->post['accumulative_discount']['discount_id'], 'SSL'));
        }
    }

    protected function validateForm() {
        $this->language->load('extension/total/hyper_discount');

        if (!$this->user->hasPermission('modify', 'extension/total/hyper_discount'))
            $this->error['warning'] = $this->language->get('error_permission');

        return !$this->error;
    }

}
