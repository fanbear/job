<?php

class ControllerExtensionTotalHyperDiscountSettingsTabSettingsCommon extends Controller
{
    private $error = array();
    private $_text_string = array(
        // Colomn One
        'name_settings_common',
        'common_status',
        'discount_variants',
        'discount_variants_titles',

        'entry_discount_all',
        'entry_discount_all_titles',
        'entry_condition_all',
        'entry_condition_all_titles',
        'entry_stock_all',
        'entry_stock_all_titles',
        'entry_options_all',
        'entry_options_all_titles',

        'most_summ',
        'most_profitable',
        // Colomn Two
        'statuses_common',
        'back_mode',
        'personal_area',
        'personal_area_titles',
        'area_output_form',
        'area_output_form_titles',
        'info_page',
        'info_page_titles',
        'info_output_form',
        'info_output_form_titles',
        'card_product',
        'card_product_titles',
        'card_output_form',
        'card_output_form_titles',
        // Help
        'help_name',
        'help_name_title',
        //'help_name_titles',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help Common One
        'help_name_common',
        'help_description_common',
        'help_first_common',
        'help_second_common',
        'help_third_common',
        'help_fourth_common',
        'help_fifth_common',
        'help_sixth_common',
        'help_seventh_common',
        'help_eighth_common',
        'help_ninth_common',
        'help_tenth_common',

        'help_eleventh_common',
        'help_twelfth_common',
        'help_thirteenth_common',
        'help_fourteenth_common',
        'help_fifteenth_common',
        'help_sixteenth_common',
        // Help Common Two
        'help_name_statuses_common',
        'help_description_statuses_common',
        'help_first_statuses_common',
        'help_second_statuses_common',
        'help_third_statuses_common',
        'help_fourth_statuses_common',
        'help_fifth_statuses_common',
        'help_sixth_statuses_common',
        'help_seventh_statuses_common',
        'help_ninth_statuses_common',
        //protected
        'protect_default',
        'protect_active',
        'protect_ignore',
        'protect_active_plus',
        'protect_ignore_minus',
        'protect_priority',
        'protect_summary',
        //Stage Second
        'before',
        'after_that',
        'after',
    );
    protected $_setting_variants = array('most_profitable_type', 'most_profitable_for_products');
    protected $_discounts = array('protect_active', 'protect_ignore', 'protect_priority', 'protect_summary');
    protected $_options = array('protect_active', 'protect_ignore');
    protected $_specials = array('protect_active', 'protect_ignore', 'protect_summary');
    protected $_discount_specials_condition = array('protect_priority', 'protect_default');
    //Stage Second
    protected $_setting_info_area = array('before', 'after_that', 'after');

    public function index()
    {

        $this->load->language('extension/total/hyper_discount/settings/tab_settings_common');

        //
        $all_protected_arr = array(
            '_setting_variants',
            '_discounts',
            '_options',
            '_specials',
            '_discount_specials_condition',
            '_setting_info_area'
        );

        foreach ($all_protected_arr as $arr_name)
            foreach ($this->$arr_name as $key => $val) {
                $arr = &$this->$arr_name;
                $arr[$val] = $this->language->get($val);
                unset($arr[$key]);
            }
        //

        foreach ($this->_text_string as $text)
        {
            $data[$text] = $this->language->get($text);
        }

        $data['array_discounts'] = $this->_discounts;
        $data['array_specials'] = $this->_specials;
        $data['array_options'] = $this->_options;
        $data['array_discount_types'] = $this->_discount_types;
        $data['array_discount_specials_condition'] = $this->_discount_specials_condition;
        $data['array_setting_variants'] = $this->_setting_variants;
        $data['array_setting_info_area'] = $this->_setting_info_area;
        $data['tmp'] = 'tmp';

        $discount_variant = array();
        $this->load->model('extension/total/hyper_discount/discount');
        
        $settings = $this->model_extension_total_hyper_discount_setting->getSetting();
        $data['discount_variant'] = $settings;
      

        return $this->load->view('extension/total/hyper_discount/settings/tab_settings_common.tpl', $data);
    }

    protected function validateForm() {
        $this->language->load('extension/total/hyper_discount');

        if (!$this->user->hasPermission('modify', 'extension/total/hyper_discount'))
            $this->error['warning'] = $this->language->get('error_permission');

        return !$this->error;
    }

}
