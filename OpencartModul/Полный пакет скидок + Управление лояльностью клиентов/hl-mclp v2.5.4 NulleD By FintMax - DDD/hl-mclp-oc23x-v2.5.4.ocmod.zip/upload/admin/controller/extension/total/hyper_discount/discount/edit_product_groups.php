<?php

header('Content-Type: text/html; charset=utf-8');

class ControllerExtensionTotalHyperDiscountDiscountEditProductGroups extends Controller {

    private $error = array();
    private $_text_string = array(
        'heading_title',
        'hyper_discount_name',
        'hyper_discount_title',
        'button_apply',
        'button_save',
        'button_cancel',
        'button_copy',
        'button_add',
        'button_edit',
        'button_delete',
        'button_filter',
        'button_clears',
        // Filter
        'entry_name',
        'entry_model',
        'entry_suppler',
        'entry_manufacturer',
        'entry_price',
        'entry_quantity',
        'entry_status',
        'filters_action',
        'filtered_products',
        'filtered_products_titles',
        'text_list',
        'text_enabled',
        'text_disabled',
        'text_no_results',
        'text_confirm',
        // Column
        'column_action',
        'column_image',
        'column_name',
        'column_model',
        'column_suppler',
        'column_manufacturer',
        'column_category',
        'column_price',
        'column_quantity',
        'column_status',
        // Help
        'help_name',
        'help_name_titles',
        'help_name_title',
        'help_list',
        'help_text',
        'help_end_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help Users
        'help_first_text',
        'help_second_text',
        'help_third_text',
        'help_fourth_text',
        'help_fifth_text',
        'entry_description',
        'description_author',
        'description_author_start',
        'description_author_copyright',
        'thank_you',
        'heading_action_text',
        'description_copyright',
    );

    public function clear() {

        $data['url_params'] = '';

        $this->session->data['editable_prods'] = array();

        if (isset($this->request->get['user_discount_id'])) {
            $this->load->model('extension/total/hyper_discount/users_discount');

            $data['url_params'] .= '&user_discount_id=' . $this->request->get['user_discount_id'];
        } elseif (isset($this->request->get['accumulative_discount_id'])) {
            $this->load->model('extension/total/hyper_discount/accumulative_discount');
            $data['url_params'] .= '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'];
        } elseif (isset($this->request->get['quantitative_discount_id'])) {

            $this->load->model('extension/total/hyper_discount/quantitative_discount');

            $data['url_params'] .= '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'];
        } elseif (isset($this->request->get['kit_discount_id'])) {

            $this->load->model('extension/total/hyper_discount/kit_discount');

            $data['url_params'] .= '&kit_discount_id=' . $this->request->get['kit_discount_id'];
        } elseif (isset($this->request->get['kit_discount_id2'])) {

            $this->load->model('extension/total/hyper_discount/kit_discount');

            $data['url_params'] .= '&kit_discount_id2=' . $this->request->get['kit_discount_id2'];
        } elseif (isset($this->request->get['products_discount_id'])) {
            $this->load->model('extension/total/hyper_discount/kit_discount');

            $data['url_params'] .= '&products_discount_id=' . $this->request->get['products_discount_id'];
        }

        $url = '';
        $url .= $data['url_params'];

        $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . $url, 'SSL'));
    }

    public function getUrlFromPostRequest() {
        $url = '';

        if (isset($this->request->post['filter_name'])) {
            $url .= '&filter_name=' . $this->request->post['filter_name'];
        }

        if (isset($this->request->post['filter_category'])) {
            $url .= '&filter_category=' . urlencode(implode(',', $this->request->post['filter_category']));
        }

        if (isset($this->request->post['filter_manufacturer'])) {
            $url .= '&filter_manufacturer=' . urlencode(implode(',', $this->request->post['filter_manufacturer']));
        }

        if (isset($this->request->post['filter_suppler'])) {
            $url .= '&filter_suppler=' . urlencode(implode(',', $this->request->post['filter_suppler']));
        }

        if (!empty($this->request->post['filter_model'])) {
            $url .= '&filter_model=' . $this->request->post['filter_model'];
        }

        if (!empty($this->request->post['filter_price'])) {
            $url .= '&filter_price=' . $this->request->post['filter_price'];
        }

        if (!empty($this->request->post['filter_quantity'])) {
            $url .= '&filter_quantity=' . $this->request->post['filter_quantity'];
        }


        if (!empty($this->request->post['filter_status']) && $this->request->post['filter_status'] != '*') {
            $url .= '&filter_status=' . $this->request->post['filter_status'];
        }

        if (isset($this->request->post['sort'])) {
            $url .= '&sort=' . $this->request->post['sort'];
        }

        if (isset($this->request->post['order'])) {
            $url .= '&order=' . $this->request->post['order'];
        }

        if (isset($this->request->post['page'])) {
            $url .= '&page=' . $this->request->post['page'];
        }

        return $url;
    }

    public function getUrlFromGetRequest() {
        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_category'])) {
            $url .= '&filter_category=' . urlencode(html_entity_decode($this->request->get['filter_category'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_manufacturer'])) {
            $url .= '&filter_manufacturer=' . urlencode(html_entity_decode($this->request->get['filter_manufacturer'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_suppler'])) {
            $url .= '&filter_suppler=' . urlencode(html_entity_decode($this->request->get['filter_suppler'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_price'])) {
            $url .= '&filter_price=' . $this->request->get['filter_price'];
        }

        if (isset($this->request->get['filter_quantity'])) {
            $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
        }


        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        return $url;
    }

    function getVarFromGetRequest() {
        $result = array();

        if (isset($this->request->get['filter_name'])) {
            $result['filter_name'] = $this->request->get['filter_name'];
        } else {
            $result['filter_name'] = null;
        }

        if (isset($this->request->get['filter_model'])) {
            $result['filter_model'] = $this->request->get['filter_model'];
        } else {
            $result['filter_model'] = null;
        }

        if (isset($this->request->get['filter_manufacturer'])) {
            $result['filter_manufacturer'] = $this->request->get['filter_manufacturer'];
        } else {
            $result['filter_manufacturer'] = null;
        }

        if (isset($this->request->get['filter_suppler'])) {
            $result['filter_suppler'] = $this->request->get['filter_suppler'];
        } else {
            $result['filter_suppler'] = null;
        }


        if (isset($this->request->get['filter_category'])) {
            $result['filter_category'] = $this->request->get['filter_category'];
        } else {
            $result['filter_category'] = null;
        }

        if (isset($this->request->get['filter_price'])) {
            $result['filter_price'] = $this->request->get['filter_price'];
        } else {
            $result['filter_price'] = null;
        }

        if (isset($this->request->get['filter_quantity'])) {
            $result['filter_quantity'] = $this->request->get['filter_quantity'];
        } else {
            $result['filter_quantity'] = null;
        }


        if (isset($this->request->get['filter_status'])) {
            $result['filter_status'] = $this->request->get['filter_status'];
        } else {
            $result['filter_status'] = null;
        }

        if (isset($this->request->get['sort'])) {
            $result['sort'] = $this->request->get['sort'];
        } else {
            $result['sort'] = 'pd.name';
        }

        if (isset($this->request->get['order'])) {
            $result['order'] = $this->request->get['order'];
        } else {
            $result['order'] = 'ASC';
        }

        if (isset($this->request->get['page'])) {
            $result['page'] = $this->request->get['page'];
        } else {
            $result['page'] = 1;
        }

        return $result;
    }

    function getVarFromPostRequest() {
        $result = array();

        if (isset($this->request->post['filter_name'])) {
            $result['filter_name'] = $this->request->post['filter_name'];
        } else {
            $result['filter_name'] = null;
        }

        if (!empty($this->request->post['filter_model'])) {
            $result['filter_model'] = $this->request->post['filter_model'];
        } else {
            $result['filter_model'] = null;
        }

        if (isset($this->request->post['filter_manufacturer'])) {
            $result['filter_manufacturer'] = implode(',', $this->request->post['filter_manufacturer']);
        } else {
            $result['filter_manufacturer'] = null;
        }

        if (isset($this->request->post['filter_suppler'])) {
            $result['filter_suppler'] = implode(',', $this->request->post['filter_suppler']);
        } else {
            $result['filter_suppler'] = null;
        }


        if (isset($this->request->post['filter_category'])) {
            $result['filter_category'] = implode(',', $this->request->post['filter_category']);
        } else {
            $result['filter_category'] = null;
        }

        if (!empty($this->request->post['filter_price'])) {
            $result['filter_price'] = $this->request->post['filter_price'];
        } else {
            $result['filter_price'] = null;
        }

        if (!empty($this->request->post['filter_quantity'])) {
            $result['filter_quantity'] = $this->request->post['filter_quantity'];
        } else {
            $result['filter_quantity'] = null;
        }


        if (!empty($this->request->post['filter_status']) && $this->request->post['filter_status'] != '*') {
            $result['filter_status'] = $this->request->post['filter_status'];
        } else {
            $result['filter_status'] = null;
        }

        if (isset($this->request->post['sort'])) {
            $result['sort'] = $this->request->post['sort'];
        } else {
            $result['sort'] = 'pd.name';
        }

        if (isset($this->request->post['order'])) {
            $result['order'] = $this->request->post['order'];
        } else {
            $result['order'] = 'ASC';
        }

        if (isset($this->request->post['page'])) {
            $result['page'] = $this->request->post['page'];
        } else {
            $result['page'] = 1;
        }

        return $result;
    }

    public function deleteUnselected() {
        if (isset($this->request->post['editable_prods']) && !empty($this->request->post['editable_prods'])) {
            $edit_prods = explode(',', $this->request->post['editable_prods']);

            if (isset($this->request->post['selected']) && is_array($this->request->post['selected']))
                $selected = $this->request->post['selected'];
            else
                $selected = array();

            $unselected = array_diff($edit_prods, $selected);

            if (isset($this->session->data['editable_prods']) && $this->session->data['editable_prods'] !== FALSE) {
                $this->session->data['editable_prods'] = array_unique(array_merge($this->session->data['editable_prods'], $selected));

                if (count($this->session->data['editable_prods']))
                    $this->session->data['editable_prods'] = array_diff($this->session->data['editable_prods'], $unselected);
                else
                    $this->session->data['editable_prods'] = array_diff($edit_prods, $unselected);
            }
        }
    }

    public function index() {

        $this->document->addStyle('view/stylesheet/hyper_loyalty.css');
        $this->document->addStyle('view/javascript/bootstrap/css/bootstrap-switch.min.css');
        $this->document->addStyle('view/javascript/bootstrap/css/bootstrap-multiselect.css');

        $this->document->addScript('view/javascript/bootstrap/js/bootstrap-multiselect.js');

        $data['selected'] = array();

        $data['url_params'] = '';

        if (isset($this->request->get['user_discount_id'])) {

            $this->load->model('extension/total/hyper_discount/users_discount');
            $parent_id = $this->model_extension_total_hyper_discount_users_discount->getGroupIdDiscount($this->request->get['user_discount_id']);

            $data['save_all_filtered_products'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups/allFilteredProducts', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');
            $data['update_stay'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups/update', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');
            $data['action_save'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');
            $data['cancel'] = $this->url->link('extension/total/hyper_discount/discount/users/edit_users_discount', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $parent_id, 'SSL');
            $data['discount_action'] = 'users';



            $data['selected'] = $this->model_extension_total_hyper_discount_users_discount->getDiscountEditorGroupProducts($this->request->get['user_discount_id']);

            $data['url_params'] .= '&user_discount_id=' . $this->request->get['user_discount_id'];
        } elseif (isset($this->request->get['accumulative_discount_id'])) {

            $this->load->model('extension/total/hyper_discount/accumulative_discount');
          

            $data['save_all_filtered_products'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups/allFilteredProducts', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
            $data['update_stay'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups/update', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
            $data['action_save'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
            $data['cancel'] = $this->url->link('extension/total/hyper_discount/discount/accumulative/edit_accumulative_discount', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
            $data['discount_action'] = 'accumulative';




            $data['selected'] = $this->model_extension_total_hyper_discount_accumulative_discount->getAccumulativeProducts($this->request->get['accumulative_discount_id']);

            $data['url_params'] .= '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'];
        } elseif (isset($this->request->get['quantitative_discount_id'])) {
            $this->load->model('extension/total/hyper_discount/quantitative_discount');
            $parent_id = $this->model_extension_total_hyper_discount_quantitative_discount->getGroupIdDiscount($this->request->get['quantitative_discount_id']);

            $data['save_all_filtered_products'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups/allFilteredProducts', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'], 'SSL');
            $data['update_stay'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups/update', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'], 'SSL');
            $data['action_save'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'], 'SSL');
            $data['cancel'] = $this->url->link('extension/total/hyper_discount/discount/quantitative/edit_quantitative_discount', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $parent_id, 'SSL');
            $data['discount_action'] = 'quantitative';




            $data['selected'] = $this->model_extension_total_hyper_discount_quantitative_discount->getQuantitativeProducts($this->request->get['quantitative_discount_id']);

            $data['url_params'] .= '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'];
        } elseif (isset($this->request->get['kit_discount_id'])) {
            $this->load->model('extension/total/hyper_discount/kit_discount');
            $parent_id = $this->model_extension_total_hyper_discount_kit_discount->getGroupIdDiscount($this->request->get['kit_discount_id']);

            $data['save_all_filtered_products'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups/allFilteredProducts', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'], 'SSL');
            $data['update_stay'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups/update', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'], 'SSL');
            $data['action_save'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'], 'SSL');
            $data['cancel'] = $this->url->link('extension/total/hyper_discount/discount/kit/edit_kit_discount', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $parent_id, 'SSL');
            $data['discount_action'] = 'kit';


            $data['selected'] = $this->model_extension_total_hyper_discount_kit_discount->getKitProducts($this->request->get['kit_discount_id']);

            $data['url_params'] .= '&kit_discount_id=' . $this->request->get['kit_discount_id'];
        } elseif (isset($this->request->get['kit_discount_id2'])) {


            $this->load->model('extension/total/hyper_discount/kit_discount');
            $parent_id = $this->model_extension_total_hyper_discount_kit_discount->getGroupIdDiscount($this->request->get['kit_discount_id2']);

            $data['save_all_filtered_products'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups/allFilteredProducts', 'token=' . $this->session->data['token'] . '&kit_discount_id2=' . $this->request->get['kit_discount_id2'], 'SSL');
            $data['update_stay'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups/update', 'token=' . $this->session->data['token'] . '&kit_discount_id2=' . $this->request->get['kit_discount_id2'], 'SSL');
            $data['action_save'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&kit_discount_id2=' . $this->request->get['kit_discount_id2'], 'SSL');
            $data['cancel'] = $this->url->link('extension/total/hyper_discount/discount/kit/edit_kit_discount', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $parent_id, 'SSL');
            $data['discount_action'] = 'kit2';




            $data['selected'] = $this->model_extension_total_hyper_discount_kit_discount->getKitProducts2($this->request->get['kit_discount_id2']);

            $data['url_params'] .= '&kit_discount_id2=' . $this->request->get['kit_discount_id2'];
        } elseif (isset($this->request->get['products_discount_id'])) {

            $this->load->model('extension/total/hyper_discount/products_discount');
            $parent_id = $this->model_extension_total_hyper_discount_products_discount->getGroupIdDiscount($this->request->get['products_discount_id']);

            $data['save_all_filtered_products'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups/allFilteredProducts', 'token=' . $this->session->data['token'] . '&products_discount_id=' . $this->request->get['products_discount_id'], 'SSL');
            $data['update_stay'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups/update', 'token=' . $this->session->data['token'] . '&products_discount_id=' . $this->request->get['products_discount_id'], 'SSL');
            $data['action_save'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&products_discount_id=' . $this->request->get['products_discount_id'], 'SSL');
            $data['cancel'] = $this->url->link('extension/total/hyper_discount/discount/products/edit_products_discount', 'token=' . $this->session->data['token'] . '&products_discount_id=' . $parent_id, 'SSL');
            $data['discount_action'] = 'products';




            $data['selected'] = $this->model_extension_total_hyper_discount_products_discount->getDiscountEditorGroupProducts($this->request->get['products_discount_id']);

            $data['url_params'] .= '&products_discount_id=' . $this->request->get['products_discount_id'];
        }

        if (!$data['selected'])
            $data['selected'] = array();

        if (isset($this->session->data['editable_prods']) && $this->session->data['editable_prods'] !== FALSE)
            $data['selected'] = $this->session->data['editable_prods'];
        else {
            $this->session->data['editable_prods'] = $data['selected'];
        }
        //permission
        if (isset($this->request->post['discount_action']) && !$this->validateForm()) {
            $this->session->data['error'] = $this->error;
            $this->response->redirect($this->url->link('extension/total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
        }
        //permission
        //SAVE
        else if (isset($this->request->post['discount_action']) && $this->validateForm()) {
            $this->deleteUnselected();

            $url = $this->getUrlFromGetRequest();
            $form_action = $this->request->post['discount_action'];

            $groups = $this->session->data['editable_prods'];

            $this->session->data['editable_prods'] = FALSE;

            if ($form_action == 'users') {

                $this->load->model('extension/total/hyper_discount/users_discount');

                $discount_id = $this->model_extension_total_hyper_discount_users_discount->editUsersProducts($this->request->get['user_discount_id'], $groups, $url);
                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/users/edit_users_discount', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $discount_id, 'SSL'));
            } elseif ($form_action == 'accumulative') {

                $this->load->model('extension/total/hyper_discount/accumulative_discount');

                $this->model_extension_total_hyper_discount_accumulative_discount->editAccumulativeProducts($this->request->get['accumulative_discount_id'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/accumulative/edit_accumulative_discount', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL'));
            } elseif ($form_action == 'quantitative') {
                $this->load->model('extension/total/hyper_discount/quantitative_discount');

                $discount_id = $this->model_extension_total_hyper_discount_quantitative_discount->editQuantitativeProducts($this->request->get['quantitative_discount_id'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/quantitative/edit_quantitative_discount', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $discount_id, 'SSL'));
            } elseif ($form_action == 'kit') {
                $this->load->model('extension/total/hyper_discount/kit_discount');

                $discount_id = $this->model_extension_total_hyper_discount_kit_discount->editKitProducts($this->request->get['kit_discount_id'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/kit/edit_kit_discount', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $discount_id, 'SSL'));
            } elseif ($form_action == 'kit2') {
                $this->load->model('extension/total/hyper_discount/kit_discount');

                $discount_id = $this->model_extension_total_hyper_discount_kit_discount->editKitProducts2($this->request->get['kit_discount_id2'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/kit/edit_kit_discount', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $discount_id, 'SSL'));
            } elseif ($form_action == 'products') {

                $this->load->model('extension/total/hyper_discount/products_discount');

                $discount_id = $this->model_extension_total_hyper_discount_products_discount->editDiscountEditorGroupProducts($this->request->get['products_discount_id'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/products/edit_products_discount', 'token=' . $this->session->data['token'] . '&products_discount_id=' . $discount_id, 'SSL'));
            }
        }
        //SAVE

        $url = $this->getUrlFromGetRequest();

        $url .= $data['url_params'];

        $this->load->language('extension/total/hyper_discount/discount/edit_product_groups');

        foreach ($this->_text_string as $text) {
            $data[$text] = $this->language->get($text);
        }
        $this->document->setTitle($this->language->get('heading_title'));

        extract($this->getVarFromGetRequest());



        $data['products'] = array();

        $filter_data = array(
            'filter_name' => $filter_name,
            'filter_model' => $filter_model,
            'filter_manufacturer' => $filter_manufacturer,
            'filter_price' => $filter_price,
            'filter_quantity' => $filter_quantity,
            'filter_category' => $filter_category,
            'filter_status' => $filter_status,
            'filter_suppler' => $filter_suppler,
            'sort' => $sort,
            'order' => $order,
            'start' => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit' => $this->config->get('config_limit_admin')
        );


        $this->load->model('tool/image');

        $this->load->model('catalog/product');

        $this->load->model('extension/total/hyper_discount/product_groups');

        $product_total = $this->model_extension_total_hyper_discount_product_groups->getTotalProducts($filter_data);

        $results = $this->model_extension_total_hyper_discount_product_groups->getProducts($filter_data);

        $this->load->model('catalog/category');


        $this->load->model('catalog/manufacturer');

        $filter_data = array(
            'sort' => 'name',
            'order' => 'ASC'
        );
        if (file_exists(DIR_APPLICATION . 'controller/catalog/suppler.php')) {
            $this->load->model('catalog/suppler');
            $data['supplers'] = $this->model_catalog_suppler->getSupplers('ASC');
        } else
            $data['supplers'] = false;

        $data['categories'] = $this->model_extension_total_hyper_discount_product_groups->getCategories($filter_data);

        $data['manufacturers'] = $this->model_catalog_manufacturer->getManufacturers($filter_data);

        $data['prod_ids'] = array();


        foreach ($results as $result) {

            $category = $this->model_catalog_product->getProductCategories($result['product_id']);

            if (is_file(DIR_IMAGE . $result['image'])) {
                $image = $this->model_tool_image->resize($result['image'], 40, 40);
            } else {
                $image = $this->model_tool_image->resize('no_image.png', 40, 40);
            }

            $special = false;

            $product_specials = $this->model_catalog_product->getProductSpecials($result['product_id']);

            foreach ($product_specials as $product_special) {
                if (($product_special['date_start'] == '0000-00-00' || strtotime($product_special['date_start']) < time()) && ($product_special['date_end'] == '0000-00-00' || strtotime($product_special['date_end']) > time())) {
                    $special = $product_special['price'];

                    break;
                }
            }

            $data['products'][] = array(
                'product_id' => $result['product_id'],
                'image' => $image,
                'name' => $result['name'],
                'manufacturer' => $result['manufacturer_name'],
                'manufacturer_id' => $result['manufacturer_id'],
                'model' => $result['model'],
                'price' => $result['price'],
                'category' => $category,
                'special' => $special,
                'quantity' => $result['quantity'],
                'status' => ($result['status']) ? $this->language->get('text_enabled') : $this->language->get('text_disabled'),
                'edit' => $this->url->link('catalog/product/edit', 'token=' . $this->session->data['token'] . '&product_id=' . $result['product_id'] . $url, 'SSL')
            );

            $data['prod_ids'][] = $result['product_id'];
        }

        $data['prod_ids'] = implode(',', $data['prod_ids']);

        $data['token'] = $this->session->data['token'];

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        $url = $this->getUrlFromGetRequest();

        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }


        $url .= $data['url_params'];

        $data['sort_name'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&sort=pd.name' . $url, 'SSL');
        $data['sort_model'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&sort=p.model' . $url, 'SSL');
        $data['sort_manufacturer'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&sort=md.manufacturer' . $url, 'SSL');
        $data['sort_price'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&sort=p.price' . $url, 'SSL');
        $data['sort_quantity'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&sort=p.quantity' . $url, 'SSL');
        $data['sort_status'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&sort=p.status' . $url, 'SSL');
        $data['sort_order'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&sort=p.sort_order' . $url, 'SSL');

        $url = $this->getUrlFromGetRequest();

        $url .= $data['url_params'];

        parse_str($url, $params);
        unset($params['page']);
        $url = '&' . http_build_query($params);


        $pagination = new Pagination();
        $pagination->total = $product_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->url = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSL');

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($product_total - $this->config->get('config_limit_admin'))) ? $product_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $product_total, ceil($product_total / $this->config->get('config_limit_admin')));

        $data['filter_name'] = $filter_name;
        $data['filter_model'] = $filter_model;
        $data['filter_manufacturer'] = explode(',', $filter_manufacturer);
        $data['filter_suppler'] = explode(',', $filter_suppler);
        $data['filter_category'] = explode(',', $filter_category);

        $data['filter_price'] = $filter_price;
        $data['filter_quantity'] = $filter_quantity;
        $data['filter_status'] = $filter_status;

        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/total/hyper_discount/discount/edit_product_groups.tpl', $data));
    }

    public function allFilteredProducts() {


        $url = $this->getUrlFromPostRequest();

        extract($this->getVarFromPostRequest());


        $data['products'] = array();

        $filter_data = array(
            'filter_name' => $filter_name,
            'filter_model' => $filter_model,
            'filter_manufacturer' => $filter_manufacturer,
            'filter_price' => $filter_price,
            'filter_quantity' => $filter_quantity,
            'filter_category' => $filter_category,
            'filter_status' => $filter_status,
            'filter_suppler' => $filter_suppler,
        );

        $this->load->model('extension/total/hyper_discount/product_groups');

        $results = $this->model_extension_total_hyper_discount_product_groups->getProducts($filter_data, true);

        //var_dump($results);exit();
        $groups = array();
        //fixed 08.08.18 12:18


        foreach ($results as $result)
            $groups[] = $result['product_id'];


        //$this->session->data['editable_prods']=$new_arr;
        //fixed 08.08.18 12:18
        if (isset($this->request->post['discount_action'])) {

            $form_action = $this->request->post['discount_action'];


            $editable_prods = isset($this->request->post['editable_prods']) ? $this->request->post['editable_prods'] : null;

            $this->session->data['editable_prods'] = $groups;


            if ($form_action == 'users') {
                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'] . $url, 'SSL'));
            } elseif ($form_action == 'accumulative') {
                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'] . $url, 'SSL'));
            } elseif ($form_action == 'quantitative') {
                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'] . $url, 'SSL'));
            } elseif ($form_action == 'kit') {
                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'] . $url, 'SSL'));
            } elseif ($form_action == 'kit2')
                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&kit_discount_id2=' . $this->request->get['kit_discount_id2'] . $url, 'SSL'));
            else if ($form_action == 'products')
                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&products_discount_id=' . $this->request->get['products_discount_id']));
        }
    }

    public function autocomplete() {
        $json = array();

        if (isset($this->request->get['filter_name']) || isset($this->request->get['filter_model'])) {
            $this->load->model('catalog/product');
            $this->load->model('catalog/option');

            if (isset($this->request->get['filter_name'])) {
                $filter_name = $this->request->get['filter_name'];
            } else {
                $filter_name = '';
            }

            if (isset($this->request->get['filter_model'])) {
                $filter_model = $this->request->get['filter_model'];
            } else {
                $filter_model = '';
            }

            if (isset($this->request->get['limit'])) {
                $limit = $this->request->get['limit'];
            } else {
                $limit = 5;
            }

            $filter_data = array(
                'filter_name' => $filter_name,
                'filter_model' => $filter_model,
                'start' => 0,
                'limit' => $limit
            );

            $results = $this->model_catalog_product->getProducts($filter_data);

            foreach ($results as $result) {
                $option_data = array();

                $product_options = $this->model_catalog_product->getProductOptions($result['product_id']);

                foreach ($product_options as $product_option) {
                    $option_info = $this->model_catalog_option->getOption($product_option['option_id']);

                    if ($option_info) {
                        $product_option_value_data = array();

                        foreach ($product_option['product_option_value'] as $product_option_value) {
                            $option_value_info = $this->model_catalog_option->getOptionValue($product_option_value['option_value_id']);

                            if ($option_value_info) {
                                $product_option_value_data[] = array(
                                    'product_option_value_id' => $product_option_value['product_option_value_id'],
                                    'option_value_id' => $product_option_value['option_value_id'],
                                    'name' => $option_value_info['name'],
                                    'price' => (float) $product_option_value['price'] ? $this->currency->format($product_option_value['price'], $this->config->get('config_currency')) : false,
                                    'price_prefix' => $product_option_value['price_prefix']
                                );
                            }
                        }

                        $option_data[] = array(
                            'product_option_id' => $product_option['product_option_id'],
                            'product_option_value' => $product_option_value_data,
                            'option_id' => $product_option['option_id'],
                            'name' => $option_info['name'],
                            'type' => $option_info['type'],
                            'value' => $product_option['value'],
                            'required' => $product_option['required']
                        );
                    }
                }

                $json[] = array(
                    'product_id' => $result['product_id'],
                    'name' => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
                    'model' => $result['model'],
                    'option' => $option_data,
                    'price' => $result['price']
                );
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function update() {
        $url = $this->getUrlFromGetRequest();
        $this->deleteUnselected();


        if (isset($this->request->post['discount_action'])) {

            $form_action = $this->request->post['discount_action'];

            $groups = $this->session->data['editable_prods'];

            $this->session->data['editable_prods'] = FALSE;

            //permission
            if (!$this->validateForm()) {
                $this->session->data['error'] = $this->error;
                $this->response->redirect($this->url->link('extension/total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
            }
            //permission
            else if ($form_action == 'users' && $this->validateForm()) {

                $this->load->model('extension/total/hyper_discount/users_discount');

                $this->model_extension_total_hyper_discount_users_discount->editUsersProducts($this->request->get['user_discount_id'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'] . $url, 'SSL'));
            } elseif ($form_action == 'accumulative' && $this->validateForm()) {

                $this->load->model('extension/total/hyper_discount/accumulative_discount');

                $this->model_extension_total_hyper_discount_accumulative_discount->editAccumulativeProducts($this->request->get['accumulative_discount_id'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'] . $url, 'SSL'));
            } elseif ($form_action == 'quantitative' && $this->validateForm()) {

                $this->load->model('extension/total/hyper_discount/quantitative_discount');

                $this->model_extension_total_hyper_discount_quantitative_discount->editQuantitativeProducts($this->request->get['quantitative_discount_id'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'] . $url, 'SSL'));
            } elseif ($form_action == 'kit' && $this->validateForm()) {

                $this->load->model('extension/total/hyper_discount/kit_discount');

                $this->model_extension_total_hyper_discount_kit_discount->editKitProducts($this->request->get['kit_discount_id'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'] . $url, 'SSL'));
            } elseif ($form_action == 'kit2' && $this->validateForm()) {

                $this->load->model('extension/total/hyper_discount/kit_discount');

                $this->model_extension_total_hyper_discount_kit_discount->editKitProducts2($this->request->get['kit_discount_id2'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&kit_discount_id2=' . $this->request->get['kit_discount_id2'] . $url, 'SSL'));
            } elseif ($form_action == 'products' && $this->validateForm()) {

                $this->load->model('extension/total/hyper_discount/products_discount');

                $this->model_extension_total_hyper_discount_products_discount->editDiscountEditorGroupProducts($this->request->get['products_discount_id'], $groups, $url);

                $this->response->redirect($this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&products_discount_id=' . $this->request->get['products_discount_id'] . $url, 'SSL'));
            }
        }
    }

    protected function validateForm() {
        $this->language->load('extension/total/hyper_discount');

        if (!$this->user->hasPermission('modify', 'extension/total/hyper_discount'))
            $this->error['warning'] = $this->language->get('error_permission');

        return !$this->error;
    }

}
