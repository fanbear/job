<?php

class ControllerExtensionTotalHyperDiscountDiscountTabDiscountAccumulative extends Controller
{
    private $_text_string = array(
        'tab_name_discount_accumulative',
    // Column
        'column_name',
        'column_name_titles',
        'column_description',
        'column_description_titles',
        'column_edit',
        'column_edit_titles',
        'column_sort_order',
        'column_sort_order_titles',
        'column_status',
        'column_status_titles',
        'column_delete',
        'column_delete_titles',
    // Buttons
        'button_add',
        'button_edit',
        'button_delete',
    // Help
        'help_name',
        'help_name_title',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
    // Help Accumulative
        'help_name_accumulative',
        'help_first_accumulative',
        'help_second_accumulative',
        'help_third_accumulative',
        'help_fourth_accumulative',
        'help_fifth_accumulative',
        'help_sixth_accumulative',
        'help_seventh_accumulative',
        'help_ninth_accumulative',
        'help_eighth_accumulative',
        'help_tenth_accumulative',
        'help_eleventh_accumulative',
        'help_twelfth_accumulative',
        'help_thirteenth_accumulative',
        'help_fourteenth_accumulative',
        'help_fifteenth_accumulative',
        'help_sixteenth_accumulative',
    );

    public function index()
    {
        $this->load->language('extension/total/hyper_discount/discount/tab_discount_accumulative');

        foreach ($this->_text_string as $text)
        {
            $data[$text] = $this->language->get($text);
        }

        $this->load->model('extension/total/hyper_discount/accumulative_discount');

        $discounts_list = $this->model_extension_total_hyper_discount_accumulative_discount->getAccumulativeDiscountsList();

        $data['accumulative_discounts'] = array();

        foreach($discounts_list as $discount)
        {
            $data['accumulative_discounts'][] = array(
                'discount_id' => $discount['id'],
                'name' => ($discount['name']) ? json_decode($discount['name'], true)[$this->config->get('config_language_id')] : null,
                'description' => isset($discount['description']) ? $discount['description'] : null,
                'sort' => isset($discount['sort']) ? $discount['sort'] : null,
                'status' => isset($discount['status']) ? $discount['status'] : null,
                'delete'        => $this->url->link('extension/total/hyper_discount/discount/accumulative/delete_accumulative_discount', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $discount['id'], 'SSL'),
                'edit'        => $this->url->link('extension/total/hyper_discount/discount/accumulative/edit_accumulative_discount', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $discount['id'], 'SSL'),

            );
        }

        $data['add_discount_accumulative'] = $this->url->link('extension/total/hyper_discount/discount/accumulative/add_accumulative_discount', 'token=' . $this->session->data['token'], 'SSL');

        return $this->load->view('extension/total/hyper_discount/discount/tab_discount_accumulative.tpl', $data);
    }

}