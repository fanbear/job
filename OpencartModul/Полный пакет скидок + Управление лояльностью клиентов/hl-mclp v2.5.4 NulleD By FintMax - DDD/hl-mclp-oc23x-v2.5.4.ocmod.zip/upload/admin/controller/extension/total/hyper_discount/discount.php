<?php
class ControllerExtensionTotalHyperDiscountDiscount extends Controller{

    public function index() {

    }

}