<?php

class ControllerExtensionTotalHyperDiscountSettingsStatusesAccamulationStatus extends Controller {

    private $error = array();
    private $_text_string_add = array(
        'heading_text_title',
        'hyper_discount_name',
        'hyper_discount_title',
        'add_name',
        'button_save',
        'heading_action_text',
        // Buttons
        'button_cancel',
        'button_apply',
        'entry_title',
        'entry_title_titles',
        'entry_description',
        'entry_description_titles',
        // Help
        'help_name',
        'help_name_title',
        'help_name_titles',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help Users
        'help_name_accumulative',
        'help_first_accumulative',
        'help_second_accumulative',
        'description_author',
        'description_author_start',
        'description_author_copyright',
        'thank_you',
        'heading_action_text',
        'description_copyright',
    );
    private $_text_string_edit = array(
        'hyper_discount_name',
        'hyper_discount_title',
        'description_author',
        'description_author_start',
        'heading_text_title',
        'add_name',
        'button_save',
        'heading_action_text',
        // Buttons
        'button_cancel',
        'button_apply',
        'entry_title',
        'entry_title_titles',
        'entry_description',
        'entry_description_titles',
        // Help
        'help_name',
        'help_name_title',
        'help_name_titles',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help Users
        'help_name_accumulative',
        'help_first_accumulative',
        'help_second_accumulative',
        'description_author',
        'description_author_start',
        'description_author_copyright',
        'thank_you',
        'heading_action_text',
        'description_copyright',
    );

    public function add() {
        $this->document->addStyle('view/stylesheet/hyper_loyalty.css');
        $this->load->language('extension/total/hyper_discount/settings/statuses/accamulation_status_add');

        if ($this->request->server['REQUEST_METHOD'] == 'POST') {
            if ($this->validateForm()) {

                $this->load->model('extension/total/hyper_discount/accamulation_status');

                $this->model_extension_total_hyper_discount_accamulation_status->addAccamulationStatus($this->request->post['accamulation_status']);

                $this->response->redirect($this->url->link('extension/total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-settings-statuses', 'SSL'));
            } else {

                $this->session->data['error'] = $this->error;
                $this->response->redirect($this->url->link('extension/total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
            }
        }

        if (isset($this->error['name'])) {
            $data['error_name'] = $this->error['name'];
        } else {
            $data['error_name'] = array();
        }


        $this->document->setTitle($this->language->get('heading_title'));

        foreach ($this->_text_string_add as $text) {
            $data[$text] = $this->language->get($text);
        }

        $data['action'] = $this->url->link('extension/total/hyper_discount/settings/statuses/accamulation_status/add', 'token=' . $this->session->data['token'] . '&tab=tab-settings-statuses', 'SSL');

        $data['cancel'] = $this->url->link('extension/total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-settings-statuses', 'SSL');
        //  $data['edit_shops_list'] = $this->url->link('extension/total/hyper_discount/discount/edit_shops_list', 'token=' . $this->session->data['token'], 'SSL');
        //   $data['edit_product_groups'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'], 'SSL');

        $this->load->model('localisation/language');

        $data['languages'] = $this->model_localisation_language->getLanguages();

        $data['lang'] = $this->language->get('lang');

        $data['config_language_id'] = $this->config->get('config_language_id');


        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/total/hyper_discount/settings/statuses/add_accamulation_status.tpl', $data));
    }

    protected function validateForm() {

        if (!$this->user->hasPermission('modify', 'extension/total/hyper_discount'))
            $this->error['warning'] = $this->language->get('error_permission');
        
        if(isset($this->request->post['accumulative_discount']['name']))
        foreach ($this->request->post['accumulative_discount']['name'] as $language_id => $value) {
            if ((utf8_strlen($value) < 3) || (utf8_strlen($value) > 255)) {
                $this->error['name'][$language_id] = $this->language->get('error_name');
            }
        }

        if ($this->error && !isset($this->error['warning'])) {
            $this->error['warning'] = $this->language->get('error_warning');
        }


        return !$this->error;
    }

    public function delete() {

        //permission
        if (isset($this->request->get['accamulation_status_id']) && !$this->validateForm()) {
            $this->session->data['error'] = $this->error;
            $this->response->redirect($this->url->link('extension/total/hyper_discount/error', 'token=' . $this->session->data['token']. '&tab=tab-settings-statuses', 'SSL'));
        }
        if (isset($this->request->get['accamulation_status_id']) && $this->validateForm()) {

            $this->load->model('extension/total/hyper_discount/accamulation_status');
            $this->model_extension_total_hyper_discount_accamulation_status->deleteAccamulationStatus($this->request->get['accamulation_status_id']);
        }

        $this->response->redirect($this->url->link('extension/total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-settings-statuses', 'SSL'));
    }

    public function edit() {
        $this->document->addStyle('view/stylesheet/hyper_loyalty.css');
        $this->load->language('extension/total/hyper_discount/settings/statuses/accamulation_status_edit');

        $this->load->model('extension/total/hyper_discount/accamulation_status');

        $status = $this->model_extension_total_hyper_discount_accamulation_status->getAccamulationStatus($this->request->get['accamulation_status_id']);

        $data['accamulation_status'] = array(
            'name' => ($status['name']) ? json_decode($status['name'], true) : null,
            'description' => ($status['description']) ? json_decode($status['description'], true) : null,
        );

        if ($this->request->server['REQUEST_METHOD'] == 'POST') {
            if ($this->validateForm()) {

                $this->load->model('extension/total/hyper_discount/accamulation_status');

                $this->model_extension_total_hyper_discount_accamulation_status->editAccamulationStatus($this->request->get['accamulation_status_id'], $this->request->post['accamulation_status']);

                $this->response->redirect($this->url->link('extension/total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-settings-statuses', 'SSL'));
            } else {

                $this->session->data['error'] = $this->error;
                $this->response->redirect($this->url->link('extension/total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
            }
        }



        if (isset($this->error['name'])) {
            $data['error_name'] = $this->error['name'];
        } else {
            $data['error_name'] = array();
        }


        $this->document->setTitle($this->language->get('heading_title'));

        foreach ($this->_text_string_edit as $text) {
            $data[$text] = $this->language->get($text);
        }

        $data['action'] = $this->url->link('extension/total/hyper_discount/settings/statuses/accamulation_status/edit', 'token=' . $this->session->data['token'] . '&accamulation_status_id=' . $this->request->get['accamulation_status_id'], 'SSL');

        $data['cancel'] = $this->url->link('extension/total/hyper_discount', 'token=' . $this->session->data['token'], 'SSL');
        //  $data['edit_shops_list'] = $this->url->link('extension/total/hyper_discount/discount/edit_shops_list', 'token=' . $this->session->data['token'], 'SSL');
        //   $data['edit_product_groups'] = $this->url->link('extension/total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'], 'SSL');

        $this->load->model('localisation/language');

        $data['languages'] = $this->model_localisation_language->getLanguages();

        $data['lang'] = $this->language->get('lang');

        $data['config_language_id'] = $this->config->get('config_language_id');


        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/total/hyper_discount/settings/statuses/add_accamulation_status.tpl', $data));
    }

}
