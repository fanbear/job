<?php

class ControllerExtensionTotalHyperDiscountDiscountTabDiscountProducts extends Controller {

    private $_text_string = array(
        'tab_name_discount_products',
        // Column
        'column_name',
        'column_name_titles',
        'column_description',
        'column_description_titles',
        'column_edit',
        'column_edit_titles',
        'column_status',
        'column_status_titles',
        'column_delete',
        'column_delete_titles',
        'column_sort_order',
        'column_sort_order_titles',
        // Buttons
        'button_add',
        'button_edit',
        'button_delete',
        // Help
        'help_name',
        'help_name_title',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help Users
        'help_name_products',
        'help_discount_text',
        'help_first_products',
        'help_second_products',
        'help_third_products',
        'help_fourth_products',
        'help_fifth_products',
        'help_sixth_products',
        'help_seventh_products',
        'help_eighth_products',
        'help_eleventh_products',
        'help_twelfth_products',
        'help_thirteenth_products',
        'help_fourteenth_products',
        'help_fifteenth_products',
        'help_sixteenth_products',
    );

    public function index() {

        $this->load->language('extension/total/hyper_discount/discount/tab_discount_products');

        foreach ($this->_text_string as $text) {
            $data[$text] = $this->language->get($text);
        }

        $this->load->model('extension/total/hyper_discount/products_discount');

        $discounts_list = $this->model_extension_total_hyper_discount_products_discount->getProductsDiscountsList();

        $data['products_discounts'] = array();
        foreach ($discounts_list as $discount) {
            $data['products_discounts'][] = array(
                'discount_id' => $discount['id'],
                'name' => ($discount['name']) ? json_decode($discount['name'], true)[$this->config->get('config_language_id')] : null,
                'description' => ($discount['description']) ? $discount['description'] : null,
                'sort' => isset($discount['sort']) ? $discount['sort'] : null,
                'status' => isset($discount['status']) ? $discount['status'] : null,
                'delete' => $this->url->link('extension/total/hyper_discount/discount/products/delete_products_discount', 'token=' . $this->session->data['token'] . '&products_discount_id=' . $discount['id'], 'SSL'),
                'edit' => $this->url->link('extension/total/hyper_discount/discount/products/edit_products_discount', 'token=' . $this->session->data['token'] . '&products_discount_id=' . $discount['id'], 'SSL'),
            );
        }

        $data['add_discount_products'] = $this->url->link('extension/total/hyper_discount/discount/products/add_products_discount', 'token=' . $this->session->data['token'], 'SSL');

        return $this->load->view('extension/total/hyper_discount/discount/tab_discount_products.tpl', $data);
    }

}
