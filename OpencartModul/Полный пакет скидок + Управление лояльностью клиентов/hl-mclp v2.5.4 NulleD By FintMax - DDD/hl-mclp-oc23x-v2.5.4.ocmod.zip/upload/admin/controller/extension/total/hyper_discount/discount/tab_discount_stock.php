<?php

class ControllerExtensionTotalHyperDiscountDiscountTabDiscountStock extends Controller {

    private $_text_string = array(
        'tab_name_stock',
        // Column
        'column_name',
        'column_name_titles',
        'column_description',
        'column_description_titles',
        'column_edit',
        'column_edit_titles',
        'column_status',
        'column_status_titles',
        'column_delete',
        'column_delete_titles',
        'column_sort_order',
        'column_sort_order_titles',
        // Buttons
        'button_add',
        'button_edit',
        'button_delete',
        // Help
        'help_name',
        'help_name_title',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help Users
        'help_name_stock',
        'help_stock_text',
        'help_first_stock',
        'help_second_stock',
        'help_third_stock',
        'help_fourth_stock',
        'help_fifth_stock',
        'help_sixth_stock',
        'help_seventh_stock',
        'help_eighth_stock',
        'help_eleventh_stock',
        'help_twelfth_stock',
        'help_thirteenth_stock',
        'help_fourteenth_stock',
        'help_fifteenth_stock',
        'help_sixteenth_stock',
    );

    public function index() {

        $this->load->language('extension/total/hyper_discount/discount/tab_discount_stock');

        foreach ($this->_text_string as $text) {
            $data[$text] = $this->language->get($text);
        }

        $this->load->model('extension/total/hyper_discount/stock_discount');

        $discounts_list = $this->model_extension_total_hyper_discount_stock_discount->getStockDiscountsList();

        $data['stock_discounts'] = array();
        foreach ($discounts_list as $discount) {
            $data['stock_discounts'][] = array(
                'discount_id' => $discount['id'],
                'name' => ($discount['name']) ? json_decode($discount['name'], true)[$this->config->get('config_language_id')] : null,
                'description' => ($discount['description']) ? $discount['description'] : null,
                'sort' => isset($discount['sort']) ? $discount['sort'] : null,
                'status' => isset($discount['status']) ? $discount['status'] : null,
                'delete' => $this->url->link('extension/total/hyper_discount/discount/stock/delete_stock_discount', 'token=' . $this->session->data['token'] . '&stock_discount_id=' . $discount['id'], 'SSL'),
                'edit' => $this->url->link('extension/total/hyper_discount/discount/stock/edit_stock_discount', 'token=' . $this->session->data['token'] . '&stock_discount_id=' . $discount['id'], 'SSL'),
            );
        }

        $data['add_discount_stock'] = $this->url->link('extension/total/hyper_discount/discount/stock/add_stock_discount', 'token=' . $this->session->data['token'], 'SSL');

        return $this->load->view('extension/total/hyper_discount/discount/tab_discount_stock.tpl', $data);
    }

}
