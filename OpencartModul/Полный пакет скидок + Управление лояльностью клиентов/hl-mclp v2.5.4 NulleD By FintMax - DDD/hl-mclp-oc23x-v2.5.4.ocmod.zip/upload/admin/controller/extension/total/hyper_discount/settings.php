<?php
class ControllerExtensionTotalHyperDiscountSettings extends Controller{

    public function index() {

    }

}