<?php
// Heading
$_['heading_title']				= 'Список гео зон';
$_['hyper_discount_name']		= 'HYPER LOYALTY +';
$_['hyper_discount_title']		= 'Управление лояльностью клиентов';
//Button
$_['button_apply']				= 'Применить';
$_['button_save']				= 'Сохранить';
$_['button_cancel']				= 'Отменить';
// Text
$_['text_success']				= 'Список гео зон обновлён!';
$_['text_list']					= 'Редактор гео зон';
// Column
$_['column_name']				= 'Название';
$_['column_descr']				= 'Описание';
$_['column_action']				= 'Действие';
// Help
$_['help_name']			= 'HELPER';
$_['help_name_titles']	= 'Подсказки';
$_['help_name_title']	= 'Помощь';
$_['help_text']			= 'Помощник';
$_['help_ok']			= 'Сё понял! Спасибо!';
$_['help_first_text']	= 'Редактор позволяет выбирать конкретные ГЕО зоны, на которые будет действовать данная скидка.';
$_['help_second_text']	= 'Для выбора ГЕО зон, на которые будет действовать данная скидка, помечайте каждый из них галочкой справа.';
$_['help_third_text']	= 'Каждая созданная скидка будет распространяться именно на те ГЕО зоны, которые вы выбрали.';
$_['help_fourth_text']	= 'Для выбора всех ГЕО зон достаточно установить свитчер в позицию "ALL" на странице редактирования скидок.';
$_['help_end_text']		= '<span style="color:red;">Завершив выбор, обязательно сохраните все изменения которые вы внесли -
кнопками <i class="fa fa-lg fa-check-square-o"></i> или <i class="fa fa-lg fa-save"></i>  в правом верхнем углу!</span>';
// Authors
$_['description_author']			= 'Разработка';
$_['description_copyright']			= 'Правообладатели';
$_['description_author_start']		= '2016-2017 © k&A';
$_['description_author_copyright']	= 'Все права на данное программное обеспечение пренадлежат её авторам <br>
<br><br><b>2016-2017 © k&A</b>';
$_['thank_you']			= '';
// Error
$_['error_warning']				= 'Внимательно проверьте форму на ошибки!';
