<?php

class hdCart {

    protected $products_cost;
    protected $products;
    protected $data_indexed;

    public function clearHD() {
        unset($this->session->data['hyper_discount']);
    }

    public function hd_debugmode() {
        $query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "hd_setting` WHERE `key`='debugmode'; ");
        return (int) $query->row['value'];
    }

    public function hd_activate() {
        $query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "hd_setting` WHERE `key`='status'; ");
        return (int) $query->row['value'];
    }

    public function getGlobalTypeDiscount() {
        $query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "hd_setting` WHERE `key` = 'setting_variants';");
        return $query->row['value'];
    }

    public function debug($data = array()) {
        echo "<pre>";
        var_dump($data);
        exit();
    }

    public function getProducts() {

        $this->clearHD();

        $this->setCartProducts();
        $this->setDataIndexed();

        $products=$this->products;

        if($this->hd_activate() && $products)
        {

            $type = $this->getGlobalTypeDiscount();

            if ($type == 'most_profitable_type') 
                $products=$this->mostProfitableType();
            else if ($type == 'most_profitable_for_products') 
                $products=$this->mostProfitableForProducts();

            $_total=0;
            $total=0;
            foreach ($products as $key => $pr) 
                $total+=$pr['total'];
            foreach ($this->products as $key => $pr) 
                $_total+=$pr['total'];

            if ($this->hd_debugmode())
            {
                if($total!==$_total)
                {

                    if (isset($this->session->data['hyper_discount']) && is_array($this->session->data['hyper_discount']))
                    {
                        $total_discount=0;
                        foreach($this->session->data['hyper_discount']  as $title=>$value) 
                            $total_discount+=$value;
                        $total=$total-$total_discount;
                        $need_disc=$_total-$total;

                        foreach($this->session->data['hyper_discount']  as $title=>$value) 
                        {
                            $precent=$value/($total_discount/100);
                            $this->session->data['hyper_discount'][$title]=$precent*$need_disc/100;
                        }
                        $products=$this->products;
                        $total=$_total;
                    }
                }
            }

            $this->fixTitle($total);
        }
        return $products;
    }
    
    public function fixTitle($total)
    {
        $temp=array();
        if (isset($this->session->data['hyper_discount']) && is_array($this->session->data['hyper_discount']))
        {
            foreach($this->session->data['hyper_discount']  as $title=>$value)
            {
                $new_title=$title." (-".round($value/($total/100),1)."%)";
                $temp[$new_title]=$value;
            }
            $this->session->data['hyper_discount']=$temp;
        }
    }
    public function debugmode()
    {
        $type = $this->getGlobalTypeDiscount();

        if ($type == 'most_profitable_type') {
            $debug_products=$this->mostProfitableType();
        } else if ($type == 'most_profitable_for_products') {
            $debug_products=$this->mostProfitableForProducts();
        }
    }
    public function mostProfitableForProducts() {

        $all_ds = array();
        $products = $this->products;

        $users_ds = $this->getTotalUsers();
        $acc_ds = $this->getTotalAccumulative();
        $quant_ds = $this->getTotalQuantitative();
        $kit_ds = $this->getTotalKit();
        $subtotal=0;
        if (isset($users_ds) && is_array($users_ds) && count($users_ds))
            $all_ds = array_merge($users_ds, $all_ds);
        if (isset($acc_ds) && is_array($acc_ds) && count($acc_ds))
            $all_ds = array_merge($acc_ds, $all_ds);
        if (isset($quant_ds) && is_array($quant_ds) && count($quant_ds))
            $all_ds = array_merge($quant_ds, $all_ds);
        if (isset($kit_ds) && is_array($kit_ds) && count($kit_ds))
            $all_ds = array_merge($kit_ds, $all_ds);
       //      $this->debug($all_ds);
        foreach ($products as $key => $p) {
            $best_price = false;
            $best_key = false;
            foreach ($all_ds as $key2 => $ds)
                if (isset($ds['products'][$key]) && ($ds['products'][$key]['final_total'] < $best_price || $best_price === false)) {
                    $best_price = $ds['products'][$key]['final_total'];

                    $best_key = $key2;
                }

                if ($best_key !== false) {
                    $products[$key]['price'] = $all_ds[$best_key]['products'][$key]['price'];
                    $products[$key]['total'] = $all_ds[$best_key]['products'][$key]['total'];
                    $subtotal+=$all_ds[$best_key]['products'][$key]['total'];

                    $title = $all_ds[$best_key]['title'];

                    if ($all_ds[$best_key]['products'][$key]['profit'] > 0)
                        if (isset($this->session->data['hyper_discount'][$title]))
                            $this->session->data['hyper_discount'][$title] += $all_ds[$best_key]['products'][$key]['profit'];
                        else
                         $this->session->data['hyper_discount'][$title] = $all_ds[$best_key]['products'][$key]['profit'];
                 }
                 else
                    $subtotal+=$p['total'];


        }

        return $products;
    }

    public function mostProfitableType() {
        $all_ds = array();


        $users_ds = $this->getTotalUsers();
        $acc_ds = $this->getTotalAccumulative();
        $quant_ds = $this->getTotalQuantitative();
        $kit_ds = $this->getTotalKit();

        $products = $this->products;

        if (isset($users_ds) && is_array($users_ds) && count($users_ds))
            $all_ds[] = $this->getSummDiscount($users_ds);


        if (isset($acc_ds) && is_array($acc_ds) && count($acc_ds))
            $all_ds[] = $this->getSummDiscount($acc_ds);

        if (isset($quant_ds) && is_array($quant_ds) && count($quant_ds))
            $all_ds[] = $this->getSummDiscount($quant_ds);

        if (isset($kit_ds) && is_array($kit_ds) && count($kit_ds))
            $all_ds[] = $this->getSummDiscount($kit_ds);

        if (count($all_ds)) {

            $best_key = 0;
            $best_total = $all_ds[$best_key]['finat_total'];

            foreach ($all_ds as $key => $d) {
                if ($best_total > $d['finat_total']) {
                    $best_key = $key;
                    $best_total = $d['finat_total'];
                }
            }
            
            $this->session->data['hyper_discount'][$all_ds[$best_key]['title']] = $all_ds[$best_key]['profit'];

            foreach ($products as $key => $p) {

                if (isset($all_ds[$best_key]['products'][$key])) {

                    $price = $all_ds[$best_key]['products'][$key]['price'];

                    $products[$key]['price'] = $price;
                    $products[$key]['total'] = $price * $p['quantity'];
                }
            }
        }
        return $products;
    }

    public function getSummDiscount($ds) {
        $total = array();
        $best_products = array();

        if (count($ds) > 1) {
            foreach ($ds as $key=>$d) {
                if(isset($d['products']) && is_array($d['products']))
                foreach ($d['products'] as $key2 => $p) {
                    $p['dkey']=$key;
                    
                    if (isset($best_products[$key2])) {
                        if ($best_products[$key2]['final_total'] > $p['final_total'])
                            $best_products[$key2] = $p;
                    } else
                        $best_products[$key2] = $p;
                }
            }
            if(count($best_products)==0)
                return;
            
            $ntotal_profit = 0;
            $ntotal = 0;
           
            
            foreach ($this->products as $key => $p)
                $ntotal += $best_products[$key]['total'];


            foreach ($best_products as $p)
                $ntotal_profit += $p['profit'];

            $all_titles=array();
            foreach ($best_products as $p)
                $all_titles[]=$ds[$p['dkey']]['title'];
     
            
            $all_titles=array_unique($all_titles);
            
            $total['title'] = implode(' / ',$all_titles);
            $total['products'] = $best_products;
            $total['total'] = $ntotal;
            $total['profit'] = $ntotal_profit;
            $total['finat_total'] = $ntotal - $ntotal_profit;


            return $total;
        } else {
            $d = array_pop($ds);
            return $d;
        }
    }

    protected function setDiscountValue($disc_prd_price) {

        //   $this->debug($disc_prd_price);

        $total_profit = 0;
        $result = array();
        $total = 0;
        $total_qty = 0;

        $k = -1;

        if (isset($disc_prd_price['products']))
            foreach ($disc_prd_price['products'] as $product_id => $value) {
                $profit = 0;
                $no_profit = !$value['profit'];
                $product_quantity = $value['product_quantity'];
                $product_price = $value['nominal_product_price'];
                $default_discount_price = $value['default_discount_price'];
                $default_special_price = $value['default_special_price'];
                $option_price = $value['option_price'];
                $special = false;
                $discount = false;
                $total_qty += $product_quantity;

                if ($option_price)
                    switch ($disc_prd_price['discount_options']) {
                        case 'protect_active':
                            $product_price += $option_price;
                            $default_discount_price += $option_price;
                            $default_special_price += $option_price;
                            break;
                    }


                if ($disc_prd_price['discount_type'] == 'full fix') {
                    $product_discount = $product_price + $k * ($disc_prd_price['discount_percent'] / $product_quantity);
                } else if ($disc_prd_price['discount_type'] == '%') {
                    $product_discount = $product_price + $k * (($product_price / 100) * $disc_prd_price['discount_percent']);
                } else {
                    $product_discount = $product_price + $k * ($disc_prd_price['discount_percent']);
                }


                if (isset($disc_prd_price['discount_variant_condition']))
                    switch ($disc_prd_price['discount_variant_condition']) {
                        case 'protect_priority':

                            if ($default_special_price > $default_discount_price) {
                                $discount = true;
                            } else if ($default_special_price < $default_discount_price) {
                                $special = true;
                            } else {
                                $special = (isset($disc_prd_price['special_variant']) && $value['special_variant_ignore']);
                                $discount = !$special;
                            }
                            break;

                        case 'protect_default':

                            $special = (isset($disc_prd_price['special_variant']) && $value['special_variant_ignore']);
                            $discount = !$special;
                    }





                if (isset($disc_prd_price['discount_variant']) && $discount)
                    switch ($disc_prd_price['discount_variant']) {
                        //Активировать: применяется наиболее выгодная скидка! -
                        //(т.е. одно из двух, или пользовательская скидка | наценка, или количественная скидка карточки товара от 2х и более).
                        case 'protect_active':


                            if ($product_discount >= $default_discount_price) {
                                $product_price = $default_discount_price;
                            } else {
                                $profit = $this->f1($product_price, $product_discount, $product_quantity);
                            }

                            break;
                        //Игнорировать: пользовательская скидка | наценка не применяется на кол-во товаров на которое не распространяется количественная скидка товара!
                        //(Пример: если у товара какая либо скидка активна на кол-во от одного и более штук, то скидка | наценка не применяется).
                        case 'protect_ignore':

                            if ($value['exist_specials']) {
                                $product_price = $default_discount_price;
                            } else {

                                $profit = $this->f1($product_price, $product_discount, $product_quantity);
                            }

                            break;
                        //Приоритет: пользовательская скидка | наценка применяется только на то кол-во товаров на которое не распространяется количественная скидка товара!
                        //(Пример: если у товара скидка активна на кол-во двух штук (больше одного), то скидк | наценка а применяется только к одному товару а не на два и более товаров).
                        case 'protect_priority':


                            if ($value['discount_variant_ignore'] &&
                                    $product_quantity >= $value['discount_cart_product_quantity'] &&
                                    $value['discount_cart_product_quantity'] > 1) {
                                $product_price = $default_discount_price;
                            } else {
                                $profit = $this->f1($product_price, $product_discount, $product_quantity);
                            }

                            break;

                        //Суммировать: суммируется пользовательская скидка | наценка и скидка товара!
                        //(т.е. количественная скидка карточки товара + пользовательская скидка | наценка).
                        case 'protect_summary':

                            if ($disc_prd_price['discount_type'] == 'full fix')
                                $product_price = $default_discount_price + $k * ($disc_prd_price['discount_percent'] / $product_quantity);
                            else if ($disc_prd_price['discount_type'] == '%')
                                $product_price = $default_discount_price + $k * (($default_discount_price / 100) * $disc_prd_price['discount_percent']);
                            else
                                $product_price = $default_discount_price + $k * ($disc_prd_price['discount_percent']);


                            $profit = $this->f1($default_discount_price, $product_price, $product_quantity);


                            $product_price = $default_discount_price;

                            break;
                    }


                if (isset($disc_prd_price['special_variant']) && $special) {
                    switch ($disc_prd_price['special_variant']) {
                        //Активировать: применяется наиболее выгодная скидка! - 
                        //(т.е. одно из двух, или пользовательская скидка | наценка, или количественная скидка карточки товара от 2х и более). 
                        case 'protect_active':



                            if ($product_discount >= $default_special_price) {
                                $product_price = $default_special_price;
                            } else {

                                $profit = $this->f1($product_price, $product_discount, $product_quantity);
                            }


                            break;
                        //Игнорировать: пользовательская скидка | наценка не применяется на кол-во товаров на которое не распространяется количественная скидка товара! 
                        //(Пример: если у товара какая либо скидка активна на кол-во от одного и более штук, то скидка | наценка не применяется). 
                        case 'protect_ignore':
                            //var_dump($value['special_variant_ignore']);
                            if ($value['special_variant_ignore']) {
                                $product_price = $default_special_price;
                            } else {

                                $profit = $this->f1($product_price, $product_discount, $product_quantity);
                            }

                            break;

                        //Суммировать: суммируется пользовательская скидка | наценка и скидка товара! 
                        //(т.е. количественная скидка карточки товара + пользовательская скидка | наценка).
                        case 'protect_summary':

                            if ($disc_prd_price['discount_type'] == 'full fix')
                                $product_price = $default_special_price + $k * ($disc_prd_price['discount_percent'] / $product_quantity);
                            else if ($disc_prd_price['discount_type'] == '%')
                                $product_price = $default_special_price + $k * (($default_special_price / 100) * $disc_prd_price['discount_percent']);
                            else
                                $product_price = $default_special_price + $k * ($disc_prd_price['discount_percent']);

                            $profit = $this->f1($default_special_price, $product_price, $product_quantity);

                            $product_price = $default_special_price;

                            break;
                    }
                }



                if ($no_profit)
                    $profit = 0;


                $total += $product_price * $product_quantity;

                $total_profit += $profit;
                $result['products'][$product_id]['total'] = $product_price * $product_quantity;
                $result['products'][$product_id]['final_total'] = $product_price * $product_quantity - $profit;
                $result['products'][$product_id]['profit'] = $profit;
                $result['products'][$product_id]['price'] = $product_price;
            }


        $result['total'] = $total;
        $result['profit'] = $total_profit;
        $result['finat_total'] = $total - $total_profit;

        return $result;
    }

    public function f1($op, $ap, $q) {
        return ($op - $ap) * $q;
    }

    public function getTotalQuantitative() {
        $discounts = array();

        $customer_id = $this->customer->getId();
        $current_shop_id = $this->config->get('config_store_id');
        $customer_group_id = $this->customer->getGroupId();


        $query_quantitative = $this->db->query("SELECT * FROM " . DB_PREFIX . "hd_quantitative WHERE `status` = '1';");


        if ($query_quantitative->rows) {

            $query_users_discount_editor = $this->db->query("SELECT * FROM " . DB_PREFIX . "hd_quantitative_discount_editor ");

            if ($query_users_discount_editor->rows)
                foreach ($query_users_discount_editor->rows as $key => $editor_value)
                    $discount_editorz[$editor_value['discount_id']][$editor_value['editor_id']] = $editor_value;

            $quantitative_discounts = $query_quantitative->rows;

            foreach ($quantitative_discounts as $quantitative_discount) {
                $discount_id = $quantitative_discount['id'];

                $guests = $quantitative_discount['guests'];

                $shops_list = $quantitative_discount['shops'] ? json_decode($quantitative_discount['shops'], true) : array();
                $customer_ids = $quantitative_discount['customers'] ? json_decode($quantitative_discount['customers'], true) : array();

                if (($quantitative_discount['shops_all'] == '1' || in_array($current_shop_id, $shops_list)) == FALSE)
                    continue;

                if ((int) $quantitative_discount['guests']) {
                    //гости и залогиненный

                    if ($customer_id)
                        continue;
                }
                else {
                    if (!$customer_id)
                        continue;

                    if (!(int) $quantitative_discount['customers_all']) {
                        $customers_ids = json_decode($quantitative_discount['customers'], true);
                        if ($customers_ids) {
                            if (!in_array($customer_id, $customers_ids))
                                continue;
                        }
                        else {
                            if ($quantitative_discount['customers_filter_url']) {
                                parse_str($quantitative_discount['customers_filter_url'], $customers_filter_url);
                                if (isset($customers_filter_url['filter_customer_group_id']) && is_array($customers_filter_url['filter_customer_group_id'])) {
                                    if (array_search($customer_group_id, $customers_filter_url['filter_customer_group_id']) === FALSE)
                                        continue;
                                } else
                                    continue;
                            } else
                                continue;
                        }
                    }
                }

                $all_sum = 0;
                $all_count = 0;

                foreach ($this->products as $product) {
                    $all_sum += $this->tax->calculate($product['price'], $product['tax_class_id'], $this->config->get('config_tax')) * $product['quantity'];
                    $all_count += $product['quantity'];
                }

                if (isset($discount_editorz[$discount_id]))
                    foreach ($discount_editorz[$discount_id] as $discount_editor_key => $discount_editor_value) {
                        $discount_percent = $discount_editor_value['discount_percent'];

                        if (($discount_percent != 0 && isset($discount_editor_value['status']) && $discount_editor_value['status'] == 1) == FALSE)
                            continue;


                        if (
                                ((strtotime($discount_editor_value['start_date']) < time() && strtotime($discount_editor_value['end_date']) > time()) ||
                                ($discount_editor_value['start_date'] == false && $discount_editor_value['end_date'] == false) ||
                                (strtotime($discount_editor_value['start_date']) < time() && $discount_editor_value['end_date'] == false) ||
                                ($discount_editor_value['start_date'] == false && strtotime($discount_editor_value['end_date'] > time()))
                                ) == FALSE)
                            continue;

                        if($discount_editor_value['discount_function'] == 'protect_all')
                        {
                            if(empty($discount_editor_value['discount_count_products']) && empty($discount_editor_value['discount_accumulation_sum']))
                                continue;

                            if(!empty($discount_editor_value['discount_count_products']) && (int) $discount_editor_value['discount_count_products'] > $all_count)
                                continue;
                            if(!empty($discount_editor_value['discount_accumulation_sum']) && (int) $discount_editor_value['discount_accumulation_sum'] > $all_sum )
                                continue;
                         
                        } else if($discount_editor_value['discount_function'] == 'protect_custom')
                        {
                            $res=array();

                            if(!empty($discount_editor_value['discount_count_products']))
                                $res[]=(int) $discount_editor_value['discount_count_products'] <= $all_count;
                           
                            if(!empty($discount_editor_value['discount_accumulation_sum']))
                                $res[]=(int) $discount_editor_value['discount_accumulation_sum'] <= $all_sum;


                            if(!$res || in_array(true,$res)===FALSE)
                                continue;
                        }

                       

                        $disc_prd_price = false;
                        $discount_type = $discount_editor_value['discount_type'];


                        $profit_all = false;
                        $filter = false;
                        $discount_products = array();

                        if ($discount_editor_value['products_all']==1) {
                            $profit_all = true;
                        } else {
                            if (!empty($discount_editor_value['products'])) {
                                $discount_products = json_decode($discount_editor_value['products'], true);
                            }
                            if (!$discount_products && $discount_editor_value['products_filter_url']) {
                                $filter = true;
                            }
                        }

                        foreach ($this->products as $key2 => $cart_product_val) {
                            $key = (floatval(VERSION) > 2.0) ? $key2 : $cart_product_val['key'];

                            $profit = false;
                            if ($profit_all)
                                $profit = true;
                            else if ($discount_products)
                                $profit = in_array($cart_product_val['product_id'], $discount_products);
                            else if ($filter) {
                                $profit = $this->filter($cart_product_val, $discount_editor_value['products_filter_url']);
                            }




                            $disc_prd_price['discount_variant'] = $discount_editor_value['discount_variant_discount'];
                            $disc_prd_price['special_variant'] = $discount_editor_value['discount_variant_specials'];
                            $disc_prd_price['discount_variant_condition'] = $discount_editor_value['discount_variant_condition'];
                            $disc_prd_price['discount_options'] = $discount_editor_value['discount_variant_options'];

                            $disc_prd_price['discount_percent'] = $discount_percent;
                            $disc_prd_price['discount_type'] = $discount_type;

                            if (isset($this->data_indexed[$key]))
                                $this->addProduct($this->data_indexed[$key], $disc_prd_price, $profit, $quantitative_discount['correction']);
                        }

                        $discount = $this->setDiscountValue($disc_prd_price);
                        if ($discount) {
                            $discount['title'] = json_decode($quantitative_discount['name'], true)[$this->config->get('config_language_id')];
                            $discounts[] = $discount;
                        }
                    }
            }
        }

        return $discounts;
    }

    public function getTotalKit() {
        $discounts = array();

        $customer_id = $this->customer->getId();
        $current_shop_id = $this->config->get('config_store_id');
        $customer_group_id = $this->customer->getGroupId();


        $query_kit = $this->db->query("SELECT * FROM " . DB_PREFIX . "hd_kit WHERE `status` = '1'");
        $query_users_discount_editor = $this->db->query("SELECT * FROM " . DB_PREFIX . "hd_kit_discount_editor ");

        if ($query_kit->rows) {

            if ($query_users_discount_editor->rows)
                foreach ($query_users_discount_editor->rows as $key => $editor_value)
                    $discount_editorz[$editor_value['discount_id']][$editor_value['editor_id']] = $editor_value;

            $kit_discounts = $query_kit->rows;


            foreach ($kit_discounts as $kit_discount) {
                $discount_id = $kit_discount['id'];
                $guests = $kit_discount['guests'];

                $shops_list = $kit_discount['shops'] ? json_decode($kit_discount['shops'], true) : array();
                $customer_ids = $kit_discount['customers'] ? json_decode($kit_discount['customers'], true) : array();
                if (($kit_discount['shops_all'] == '1' || in_array($current_shop_id, $shops_list)) == FALSE)
                    continue;

                if ((int) $kit_discount['guests']) {
                    //гости и залогиненный

                    if ($customer_id)
                        continue;
                }
                else {
                    if (!$customer_id)
                        continue;

                    if (!(int) $kit_discount['customers_all']) {
                        $customers_ids = json_decode($kit_discount['customers'], true);
                        if ($customers_ids) {
                            if (!in_array($customer_id, $customers_ids))
                                continue;
                        }
                        else {
                            if ($kit_discount['customers_filter_url']) {
                                parse_str($kit_discount['customers_filter_url'], $customers_filter_url);
                                if (isset($customers_filter_url['filter_customer_group_id']) && is_array($customers_filter_url['filter_customer_group_id'])) {
                                    if (array_search($customer_group_id, $customers_filter_url['filter_customer_group_id']) === FALSE)
                                        continue;
                                } else
                                    continue;
                            } else
                                continue;
                        }
                    }
                }

                if (isset($discount_editorz[$discount_id]))
                    foreach ($discount_editorz[$discount_id] as $discount_editor_key => $discount_editor_value) {
                        $discount_percent = $discount_editor_value['discount_percent'];


                        if (($discount_percent != 0 && isset($discount_editor_value['status']) && $discount_editor_value['status'] == 1) == FALSE)
                            continue;

                        if ((
                                (strtotime($discount_editor_value['start_date']) < time() && strtotime($discount_editor_value['end_date']) > time()) ||
                                ($discount_editor_value['start_date'] == false && $discount_editor_value['end_date'] == false) ||
                                (strtotime($discount_editor_value['start_date']) < time() && $discount_editor_value['end_date'] == false) ||
                                ($discount_editor_value['start_date'] == false && strtotime($discount_editor_value['end_date'] > time()))
                                ) == FALSE)
                            continue;

                        $disc_prd_price = false;
                        $discount_type = $discount_editor_value['discount_type'];


                        $profit_all = false;
                        $filter = false;
                        $filter2 = false;
                        $discount_products = array();
                        $discount_products2 = array();
                        $check = false;
                        $copy = $discount_editor_value['products_all'] == 1;



                        if (!empty($discount_editor_value['products2'])) {
                            $discount_products2 = json_decode($discount_editor_value['products2'], true);
                        }
                        if (!$discount_products2 && $discount_editor_value['products_filter_url2']) {
                            $filter2 = true;
                        }

                        if (!empty($discount_editor_value['products'])) {
                            $discount_products = json_decode($discount_editor_value['products'], true);
                        }
                        if (!$discount_products && $discount_editor_value['products_filter_url2']) {
                            $filter = true;
                        }
                        if ($copy) {
                            $discount_products = $discount_products2;
                            $filter = $filter2;
                        }

                        $flag2 = true;
                        $flag = true;

                        $type_qty = $discount_editor_value['type_qty'] == '1';
                        $need_qty = (!empty($discount_editor_value['discount_count_products2'])) ? (int) $discount_editor_value['discount_count_products2'] : 1;

                        $count_exist_pr = 0;
                        foreach ($this->products as $key2 => $cart_product_val) {
                            if ($discount_products2)
                                $lflag = in_array($cart_product_val['product_id'], $discount_products2);
                            else if ($filter2) {
                                $lflag = $this->filter($cart_product_val, $discount_editor_value['products_filter_url2']);
                            } else
                                $lflag = false;

                            if ($lflag)
                                if ($type_qty) {
                                    if ($need_qty >= (int) $cart_product_val['quantity']) {
                                        $count_exist_pr++;
                                    }
                                } else {
                                    $count_exist_pr++;
                                }
                        }

                        if ($type_qty)
                            $flag2 = $count_exist_pr == count($discount_products2);
                        else
                            $flag2 = $count_exist_pr >= $need_qty;

                        //  var_dump($count_exist_pr);
                        //  var_dump(count($discount_products2));
                        if (!$flag2)
                            continue;

                         $need_qty = (!empty($discount_editor_value['discount_count_products'])) ? (int) $discount_editor_value['discount_count_products'] : 1;
                        $count_exist_pr = 0;
                        foreach ($this->products as $key2 => $cart_product_val) {
                            if ($discount_products)
                                $lflag = in_array($cart_product_val['product_id'], $discount_products);
                            else if ($filter) {
                                $lflag = $this->filter($cart_product_val, $discount_editor_value['products_filter_url']);
                            } else
                                $lflag = false;

                            if ($lflag)
                                if ($type_qty) {
                                    if ($need_qty >= (int) $cart_product_val['quantity']) {
                                        $count_exist_pr++;
                                    }
                                } else {
                                    $count_exist_pr++;
                                }
                        }
                        if ($type_qty)
                            $flag = $count_exist_pr == count($discount_products);
                        else
                            $flag = $count_exist_pr >= $need_qty;

                        if (!$flag)
                            continue;



                        foreach ($this->products as $key2 => $cart_product_val) {
                            $key = (floatval(VERSION) > 2.0) ? $key2 : $cart_product_val['key'];
                            $profit = false;
                            if ($discount_products)
                                $profit = in_array($cart_product_val['product_id'], $discount_products);
                            else if ($filter) {
                                $profit = $this->filter($cart_product_val, $discount_editor_value['products_filter_url']);
                            }

                            $disc_prd_price['discount_variant'] = $discount_editor_value['discount_variant_discount'];
                            $disc_prd_price['special_variant'] = $discount_editor_value['discount_variant_specials'];
                            $disc_prd_price['discount_variant_condition'] = $discount_editor_value['discount_variant_condition'];
                            $disc_prd_price['discount_options'] = $discount_editor_value['discount_variant_options'];

                            $disc_prd_price['discount_percent'] = $discount_percent;
                            $disc_prd_price['discount_type'] = $discount_type;

                            if (isset($this->data_indexed[$key])) {
                                $this->addProduct($this->data_indexed[$key], $disc_prd_price, $profit, $kit_discount['correction']);
                            }
                        }

                        $discount = $this->setDiscountValue($disc_prd_price);

                        if ($discount) {
                            $discount['title'] = json_decode($kit_discount['name'], true)[$this->config->get('config_language_id')];
                            $discounts[] = $discount;
                        }
                    }
            }
        }

        return $discounts;
    }

    public function endsWith($haystack, $needle) {
        $length = strlen($needle);

        return $length === 0 ||
                (substr($haystack, -$length) === $needle);
    }

    public function filter($product, $filter) {

        parse_str($filter, $filter);
        foreach ($filter as $key => $val) {
            $filter[$key] = explode(',', $val);
        }


        if (isset($filter['filter_suppler'])) {
            $model = $product['model'];
            $find = false;
            foreach ($filter['filter_suppler'] as $suppler)
                if ($this->endsWith($model, trim($suppler))) {
                    $find = true;
                    break;
                }
            if (!$find)
                return false;
        }

        if (isset($filter['filter_manufacturer'])) {
            $manufac = $this->getProductManufacturer($product['product_id']);
            if ($manufac) {
                if (array_search($manufac['manufacturer_id'], $filter['filter_manufacturer']) === false)
                    return false;
            } else
                return false;
        }

        if (isset($filter['filter_category'])) {
            $product_cats = $this->getProductCategories($product['product_id']);

            $cats = array();
            if ($product_cats) {
                foreach ($product_cats as $cat)
                    $cats[] = $cat['category_id'];


                $childs = $this->getCategoriesParent($cats);
                foreach ($childs as $child)
                    $cats[] = $child['path_id'];

                $cats = array_unique($cats);
                if (count(array_diff($cats, $filter['filter_category'])) === count($cats))
                    return false;
            } else
                return false;
        }

        return true;
    }

    public function getProductManufacturer($id) {
        $query = $this->db->query("SELECT `manufacturer_id` FROM " . DB_PREFIX . "product WHERE product_id = '" . (int) $id . "'");
        return $query->row;
    }

    public function getProductCategories($id) {
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_to_category WHERE product_id = '" . (int) $id . "'");

        return $query->rows;
    }

    public function getCategoriesParent($ids = 0) {
        $path_ids = implode("','", $ids);
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_path WHERE `category_id` IN('$path_ids');");

        return $query->rows;
    }

    public function getTotalAccumulative() {
        $discounts = array();

        $customer_id = $this->customer->getId();

        if (!$customer_id)
            return;

        $current_shop_id = $this->config->get('config_store_id');
        $customer_group_id = $this->customer->getGroupId();
        $query_accumulative = $this->db->query("SELECT * FROM " . DB_PREFIX . "hd_accumulative WHERE `status` = '1'");

        if ($query_accumulative->rows) {

            $accumulative_discounts = $query_accumulative->rows;
            $query_users_discount_editor = $this->db->query("SELECT * FROM " . DB_PREFIX . "hd_accumulative_discount_editor");
            if ($query_users_discount_editor->rows)
                foreach ($query_users_discount_editor->rows as $key => $editor_value)
                    $discount_editorz[$editor_value['discount_id']][$editor_value['editor_id']] = $editor_value;

            foreach ($accumulative_discounts as $accumulative_discount) {

                $discount_id = $accumulative_discount['id'];
                $shops_list = $accumulative_discount['shops'] ? json_decode($accumulative_discount['shops'], true) : array();
                $summary = $accumulative_discount['order_statuses'] ? json_decode($accumulative_discount['order_statuses'], true) : array();
                $product_ids = $accumulative_discount['products'] ? json_decode($accumulative_discount['products'], true) : false;


                //  Проверка магазина и клиента

                if (!isset($accumulative_discount['customers_all'])) {
                    $customers_ids = json_decode($accumulative_discount['customers'], true);
                    if ($customers_ids) {
                        if (!in_array($customer_id, $customers_ids))
                            continue;
                    }
                    else {
                        if ($accumulative_discount['customers_filter_url']) {
                            parse_str($accumulative_discount['customers_filter_url'], $customers_filter_url);
                            if (isset($customers_filter_url['filter_customer_group_id']) && is_array($customers_filter_url['filter_customer_group_id'])) {
                                if (array_search($customer_group_id, $customers_filter_url['filter_customer_group_id']) === FALSE)
                                    continue;
                            } else
                                continue;
                        } else
                            continue;
                    }
                }


                $glob_discount = $accumulative_discount['discount_variant_discount'];
                $glob_discount_variant_condition = $accumulative_discount['discount_variant_condition'];
                $glob_stock = $accumulative_discount['discount_variant_specials'];
                $glob_discount_options = $accumulative_discount['discount_variant_options'];


                $implode_orders_status = implode(',', $summary);
                if (!$implode_orders_status)
                    continue;

                $sql = "SELECT o.order_id,o.total AS total,SUM(op.quantity) AS quantity FROM `" . DB_PREFIX . "order` o LEFT JOIN " . DB_PREFIX . "order_product op ON (o.order_id = op.order_id) WHERE customer_id = '" . $customer_id . "' AND order_status_id IN (" . $implode_orders_status . ")";
                
                if($accumulative_discount['start_date'])
                    $sql.=" AND DATE(o.date_added)>'".$accumulative_discount['start_date']."' ";
                if($accumulative_discount['end_date'])
                    $sql.=" AND DATE(o.date_added)<'".$accumulative_discount['end_date']."' ";
                $sql.="  group by o.order_id";
                $discount_summary_res = $this->db->query($sql);
               

                $all_sum = 0;
                $all_purchased = 0;
                if ($discount_summary_res->rows)
                    foreach ($discount_summary_res->rows as $prod_val) {
                        $all_sum += (float) $prod_val['total'];
                        $all_purchased += $prod_val['quantity'];
                    }
                $all_orders = count($discount_summary_res->rows);
                $sort_order = array();
                $tmp_discount_array = array();

                

                if (isset($discount_editorz[$discount_id]))
                    foreach ($discount_editorz[$discount_id] as $discount_editor_key => $discount_editor_value) {

                        if (($discount_editor_value != 0 && isset($discount_editor_value['status']) && $discount_editor_value['status'] == 1) == FALSE)
                            continue;

                        if ((

                                (strtotime($discount_editor_value['start_date']) < time() && strtotime($discount_editor_value['end_date']) > time()) ||
                                ($discount_editor_value['start_date'] == false && $discount_editor_value['end_date'] == false) ||
                                (strtotime($discount_editor_value['start_date']) < time() && $discount_editor_value['end_date'] == false) ||
                                ($discount_editor_value['start_date'] == false && strtotime($discount_editor_value['end_date']) > time())
                                ) == FALSE)
                            continue;
                          
                  

                        if($discount_editor_value['discount_function'] == 'protect_all')
                        {
                            if(empty($discount_editor_value['discount_function_orders']) && empty($discount_editor_value['discount_function_products']) && empty($discount_editor_value['discount_function_sum']))
                                continue;
                            
                            if(!empty($discount_editor_value['discount_function_orders']) && (int) $discount_editor_value['discount_function_orders'] > $all_orders)
                                continue;
                            if(!empty($discount_editor_value['discount_function_products']) && (int) $discount_editor_value['discount_function_products'] > $all_purchased )
                                continue;
                            if(!empty($discount_editor_value['discount_function_sum']) && (int) $discount_editor_value['discount_function_sum'] > $all_sum)
                                continue;
                        } else if($discount_editor_value['discount_function'] == 'protect_custom')
                        {
                            $res=array();

                            if(!empty($discount_editor_value['discount_function_orders']))
                                $res[]=(int) $discount_editor_value['discount_function_orders'] <= $all_orders;
                           
                            if(!empty($discount_editor_value['discount_function_products']))
                                $res[]=(int) $discount_editor_value['discount_function_products'] <= $all_purchased;

                            if(!empty($discount_editor_value['discount_function_sum']))
                                $res[]=(int) $discount_editor_value['discount_function_sum'] <= $all_sum;

                            if(!$res || in_array(true,$res)===FALSE)
                                continue;
                        }
                               


                        $disc_prd_price = array();
                        $discount_type = $discount_editor_value['discount_type'];
                        $discount_percent = $discount_editor_value['discount_percent'];

                        $profit_all = false;
                        $filter = false;
                        $discount_products = array();

                        if ($accumulative_discount['products_all']==1) {
                            $profit_all = true;
                        } else {
                            if (!empty($accumulative_discount['products'])) {
                                $discount_products = json_decode($accumulative_discount['products'], true);
                            }
                            if (!$discount_products && $accumulative_discount['products_filter_url']) {
                                $filter = true;
                            }
                        }


                        foreach ($this->products as $key2 => $cart_product_val) {

                            $key = (floatval(VERSION) > 2.0) ? $key2 : $cart_product_val['key'];

                            $profit = false;
                            if ($profit_all)
                                $profit = true;
                            else if ($discount_products)
                                $profit = in_array($cart_product_val['product_id'], $discount_products);
                            else if ($filter) {
                                $profit = $this->filter($cart_product_val, $accumulative_discount['products_filter_url']);
                            }


                            $disc_prd_price['discount_variant'] = $glob_discount;
                            $disc_prd_price['special_variant'] = $glob_stock;
                            $disc_prd_price['discount_variant_condition'] = $glob_discount_variant_condition;
                            $disc_prd_price['discount_options'] = $glob_discount_options;

                            $disc_prd_price['discount_percent'] = $discount_percent;
                            $disc_prd_price['discount_type'] = $discount_type;
                            if (isset($this->data_indexed[$key]))
                            {

                                $this->addProduct($this->data_indexed[$key], $disc_prd_price, $profit, $accumulative_discount['correction']);
                            }
                        }

                        $discount = $this->setDiscountValue($disc_prd_price);

                        if ($discount) {
                            $discount['title'] = json_decode($accumulative_discount['name'], true)[$this->config->get('config_language_id')];
                            $discounts[] = $discount;
                        }
                    }
            }
        }

        return $discounts;
    }

    public function addProduct($iproduct, &$disc_prd_price, $profit, $correction = false) {


        $customer_group_id = $this->customer->getGroupId();

        $options_cart_products = isset($iproduct['options']) ? json_decode($iproduct['options'], true) : array();


        //option pirce fix
        foreach ($this->products[$iproduct['key']]['option'] as $option)
            if ($option['price_prefix'] == '=') {
                $iproduct['price'] = 0;
                break;
            }

        $discounts_cart_products = isset($iproduct['discounts']) ? json_decode($iproduct['discounts'], true) : array();
        $specials_cart_products = isset($iproduct['specials']) ? json_decode($iproduct['specials'], true) : array();
        $nominal_product_price = isset($iproduct['price']) ? $iproduct['price'] : 0;

        $default_discount_price = $iproduct['price'];
        $default_special_price = $iproduct['price'];


        $cart_product_quantity = $this->products[$iproduct['key']]['quantity'];

        $discount_variant_ignore = false;
        $special_variant_ignore = false;
        $discount_option_price = false;

        $discount_minimum_quantity = (count($discounts_cart_products) > 1) ? $discounts_cart_products[1]['quantity'] : null;

        if (!empty($discounts_cart_products)) {

            if (count($specials_cart_products) > 1) {
                $sort=array();
                
                foreach ($discounts_cart_products as $key => $row)
                    $sort[$key] = $row['priority'];
                array_multisort($sort, SORT_DESC, $discounts_cart_products);
            }
            foreach ($discounts_cart_products as $discounts_cart_product) {
                if (
                        $this->products[$iproduct['key']]['quantity'] >= $discounts_cart_product['quantity'] &&
                        (($discounts_cart_product['customer_group_id'] == $customer_group_id) || (!$customer_group_id && $discounts_cart_product['customer_group_id'] == (int) $this->config->get('config_customer_group_id'))) &&
                        (strtotime($discounts_cart_product['date_start']) < time() || $discounts_cart_product['date_start'] == '0000-00-00') &&
                        (strtotime($discounts_cart_product['date_end']) > time() || $discounts_cart_product['date_end'] == '0000-00-00')
                ) {
                    $default_discount_price = $discounts_cart_product['price'];
                    $cart_product_quantity = $this->products[$iproduct['key']]['quantity'];
                    $discounts_cart_product_quantity = $discounts_cart_product['quantity'];
                    $discount_variant_ignore = true;
                }

                if ($correction == 0 && $discounts_cart_product['quantity'] == 1 &&
                        (($discounts_cart_product['customer_group_id'] == $customer_group_id) || (!$customer_group_id && $discounts_cart_product['customer_group_id'] == (int) $this->config->get('config_customer_group_id')))
                ) {
                    $nominal_product_price = $discounts_cart_product['price'];
                }
            }
        }

        if ($specials_cart_products) {
            if (count($specials_cart_products) > 1) {
                $sort = array();
                
                foreach ($specials_cart_products as $key => $row)
                    $sort[$key] = $row['priority'];
                
                array_multisort($sort, SORT_DESC, $specials_cart_products);
            }
            

            foreach ($specials_cart_products as $specials_cart_product) {
                if (
                        (($specials_cart_product['customer_group_id'] == $customer_group_id) || (!$customer_group_id && $specials_cart_product['customer_group_id'] == (int) $this->config->get('config_customer_group_id'))) &&
                        (strtotime($specials_cart_product['date_start']) < time() || $specials_cart_product['date_start'] == '0000-00-00') &&
                        (strtotime($specials_cart_product['date_end']) > time() || $specials_cart_product['date_end'] == '0000-00-00')
                ) {
                    $default_special_price = $specials_cart_product['price'];
                    $special_variant_ignore = true;
                }
            }
        }
        $disc_prd_price['products'][$iproduct['key']]['id'] = $iproduct['id'];
        $disc_prd_price['products'][$iproduct['key']]['profit'] = $profit;
        $disc_prd_price['products'][$iproduct['key']]['option_price'] = $this->products[$iproduct['key']]['option_price'];
        $disc_prd_price['products'][$iproduct['key']]['exist_specials'] = !empty($discounts_cart_products);

        $disc_prd_price['products'][$iproduct['key']]['default_discount_price'] = $default_discount_price;
        $disc_prd_price['products'][$iproduct['key']]['nominal_product_price'] = $nominal_product_price;
        $disc_prd_price['products'][$iproduct['key']]['product_quantity'] = $cart_product_quantity;

        $disc_prd_price['products'][$iproduct['key']]['discount_variant_ignore'] = $discount_variant_ignore;
        $disc_prd_price['products'][$iproduct['key']]['discount_cart_product_quantity'] = isset($discounts_cart_product_quantity) ? $discounts_cart_product_quantity : false;
        $disc_prd_price['products'][$iproduct['key']]['discount_option_price'] = $discount_option_price;

        $disc_prd_price['products'][$iproduct['key']]['default_special_price'] = $default_special_price;
        $disc_prd_price['products'][$iproduct['key']]['special_variant_ignore'] = $special_variant_ignore;
    }

    public function setCartProducts() {
        $this->products = $this->_getProducts();
    }

    public function setDataIndexed() {
        $this->data_indexed = array();
        $cart_products_ids = array();

        foreach ($this->products as $p)
            $cart_products_ids[] = $p['product_id'];

        if (!count($cart_products_ids))
            return;

        $implode_cart_products_ids = implode(',', $cart_products_ids);
        $product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "hd_products WHERE id IN (" . $implode_cart_products_ids . ")");


        if ($product_query->rows) {
            foreach ($this->products as $tmp_key => $tmp_value) {
                foreach ($product_query->rows as $tmp_key2 => $tmp_value2) {
                    if ($tmp_value['product_id'] == $tmp_value2['id']) {

                        if (floatval(VERSION) > 2.0)
                            $this->data_indexed[$tmp_key]['key'] = $tmp_key;
                        else
                            $this->data_indexed[$tmp_key]['key'] = $tmp_value['key'];

                        $this->data_indexed[$tmp_key]['id'] = $tmp_value2['id'];
                        $this->data_indexed[$tmp_key]['cart_id'] = $tmp_value['cart_id'];
                        $this->data_indexed[$tmp_key]['price'] = $tmp_value2['price'];
                        $this->data_indexed[$tmp_key]['options'] = $tmp_value2['options'];
                        $this->data_indexed[$tmp_key]['discounts'] = $tmp_value2['discounts'];
                        $this->data_indexed[$tmp_key]['specials'] = $tmp_value2['specials'];
                    }
                }
            }
        } else
            return false;
    }

    public function getTotalUsers() {

        $discounts = array();
        $customer_id = ($this->customer->getId()) ? (int) $this->customer->getId() : false;
        $customer_group_id = $this->customer->getGroupId();
        $current_shop_id = $this->config->get('config_store_id');

        //Инициализация массива скидок $discount_data[group][proc]
        $query_users = $this->db->query("SELECT * FROM " . DB_PREFIX . "hd_users WHERE `status` = '1';");

        if ($query_users->rows) {

            $user_discounts = $query_users->rows;
            $query_users_discount_editor = $this->db->query("SELECT * FROM " . DB_PREFIX . "hd_users_discount_editor");
            if ($query_users_discount_editor->rows)
                foreach ($query_users_discount_editor->rows as $key => $editor_value)
                    $discount_editorz[$editor_value['discount_id']][$editor_value['editor_id']] = $editor_value;



            foreach ($user_discounts as $user_discount) {
                $discount_id = (int) $user_discount['id'];
                $discount_settings = isset($user_discount['shops_all']) ? $user_discount['shops_all'] : false;
                $shops_list = json_decode($user_discount['shops'], true);

                if ((isset($discount_settings) || in_array($current_shop_id, $shops_list)) == FALSE)
                    continue;

                if ((int) $user_discount['guests']) {
                    //гости и залогиненный

                    if ($customer_id)
                        continue;
                }
                else {
                    if (!$customer_id)
                        continue;

                    if (!(int) $user_discount['customers_all']) {
                        $customers_ids = json_decode($user_discount['customers'], true);
                        if ($customers_ids) {
                            if (!in_array($customer_id, $customers_ids))
                                continue;
                        }
                        else {

                            if ($user_discount['customers_filter_url']) {
                                parse_str($user_discount['customers_filter_url'], $customers_filter_url);
                                if (isset($customers_filter_url['filter_customer_group_id']) && is_array($customers_filter_url['filter_customer_group_id'])) {
                                    if (array_search($customer_group_id, $customers_filter_url['filter_customer_group_id']) === FALSE)
                                        continue;
                                } else
                                    continue;
                            } else
                                continue;
                        }
                    }
                }


                if (isset($discount_editorz[$discount_id]))
                    foreach ($discount_editorz[$discount_id] as $discount_editor_key => $discount_editor) {

                        $discount_products = !empty($editor_value['products']) ? json_decode($editor_value['products'], true) : array();
                        $disc_prd_price = false;

                        $discount_percent = $discount_editor['discount_percent'];


                        if (($discount_percent != 0 && isset($discount_editor['status']) && $discount_editor['status'] == 1) == FALSE)
                            continue;


                       if (
                                ((strtotime($discount_editor['start_date']) < time() && strtotime($discount_editor['end_date']) > time()) ||
                                ($discount_editor['start_date'] == false && $discount_editor['end_date'] == false) ||
                                (strtotime($discount_editor['start_date']) < time() && $discount_editor['end_date'] == false) ||
                                ($discount_editor['start_date'] == false && strtotime($discount_editor['end_date'] > time()))
                                ) == FALSE)
                            continue;

                        $profit_all = false;
                        $filter = false;
                        $discount_products = array();

                        if ($discount_editor['products_all'] == 1)
                            $profit_all = true;
                        else {
                            if (!empty($editor_value['products'])) {
                                $discount_products = json_decode($discount_editor['products'], true);
                            }
                            if (!$discount_products && $discount_editor['products_filter_url']) {
                                $filter = true;
                            }
                        }
                     
                
                        foreach ($this->products as $key2 => $cart_product_val) {

                            $profit = false;

                            if ($profit_all)
                                $profit = true;
                            else if ($discount_products)
                                $profit = in_array($cart_product_val['product_id'], $discount_products);
                            else if ($filter)
                                $profit = $this->filter($cart_product_val, $editor_value['products_filter_url']);


                            $key = (floatval(VERSION) > 2.0) ? $key2 : $cart_product_val['key'];


                            $disc_prd_price['discount_variant'] = $discount_editor['discount_variant_discount'];
                            $disc_prd_price['special_variant'] = $discount_editor['discount_variant_specials'];
                            $disc_prd_price['discount_variant_condition'] = $discount_editor['discount_variant_condition'];
                            $disc_prd_price['discount_options'] = $discount_editor['discount_variant_options'];

                            $disc_prd_price['discount_percent'] = ($discount_editor['discount_percent']) ? (int) $discount_editor['discount_percent'] : 0;
                            $disc_prd_price['discount_type'] = $discount_type = $discount_editor['discount_type'];


                            if (isset($this->data_indexed[$key]))
                                $this->addProduct($this->data_indexed[$key], $disc_prd_price, $profit, $user_discount['correction']);
                        }

                        $discount = $this->setDiscountValue($disc_prd_price);

                        if ($discount) {
                            $discount['title'] = json_decode($user_discount['name'], true)[$this->config->get('config_language_id')];
                            $discounts[] = $discount;
                        }
                    }
            }
        }
        // $this->debug($discounts);
        return $discounts;
    }

}
