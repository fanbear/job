<?php

class ModelTotalHyperDiscountQuantitativeDiscount extends Model {

    public function getQuantitativeDiscountsList() {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hd_quantitative` ");

        if ($query->rows) {
            return $query->rows;
        } else {
            return array();
        }
    }

    public function addQuantitativeDiscount($quantitative_discount) {
        $this->db->query("INSERT INTO `" . DB_PREFIX . "hd_quantitative` SET `name` = '" . $this->db->escape(json_encode($quantitative_discount['name'])) . "', `description` = '" . $this->db->escape($quantitative_discount['description']) . "'");
    }

    public function deleteQuantitativeDiscount($quantitative_discount_id) {
        $this->db->query("DELETE FROM " . DB_PREFIX . "hd_quantitative WHERE id = '" . (int) $quantitative_discount_id . "'");
    }

    public function getQuantitativeDiscount($quantitative_discount_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hd_quantitative` WHERE `id` = '" . (int) $quantitative_discount_id . "'");

        if ($query->row) {
            return $query->row;
        } else {
            return array();
        }
    }

    public function getQuantitativeDiscountEditors($quantitative_discount_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hd_quantitative_discount_editor` WHERE `discount_id` = '" . (int) $quantitative_discount_id . "'");

        if ($query->rows) {
            return $query->rows;
        } else {
            return false;
        }
    }

    public function editQuantitativeDiscount($quantitative_discount) {



        if (isset($quantitative_discount['discount_editor'])) {
            //  $this->db->query("DELETE FROM `" . DB_PREFIX . "hd_quantitative_discount_editor` WHERE `discount_id` = '" . (int) $quantitative_discount['discount_id'] . "'");

            $ids = array();
            foreach ($quantitative_discount['discount_editor'] as $editor_key => $editor_val)
                $ids[] = $editor_key;

            if ($ids)
                $this->db->query("DELETE FROM `" . DB_PREFIX . "hd_quantitative_discount_editor` WHERE `discount_id` = '" . (int) $quantitative_discount['discount_id'] . "' AND `editor_id` NOT IN ('" . implode("','", $ids) . "')");


            foreach ($quantitative_discount['discount_editor'] as $editor_key => $editor_val) {
                $discount_percent = $editor_val['discount_percent'];
                $start_date = (!empty($editor_val['start_date'])) ? "'".strtotime($editor_val['start_date'])."'" : 'null';
                $end_date = (!empty($editor_val['end_date'])) ? "'".strtotime($editor_val['end_date'])."'" : 'null';
                $status = isset($editor_val['status']) ? 1 : null;
                $product_group = isset($editor_val['products_all']) ? 1 : null;
                $discount_count_products = $editor_val['discount_count_products'];
                $discount_accumulation_sum = $editor_val['discount_accumulation_sum'];


                $result = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hd_quantitative_discount_editor` WHERE discount_id = '" . (int) $quantitative_discount['discount_id'] . "' AND editor_id='$editor_key'");



                if (!$result->row)
                    $this->db->query("INSERT INTO `" . DB_PREFIX . "hd_quantitative_discount_editor` SET
                     `discount_id` = '" . (int) $quantitative_discount['discount_id'] . "',
                     `editor_id` = '" . (int) $editor_val['editor_id'] . "',
                     `discount_count_products` = '" . $discount_count_products . "',
                     `discount_accumulation_sum` = '" . $discount_accumulation_sum . "',
                     `discount_function` = '" . $this->db->escape($editor_val['discount_function']) . "',
                     `discount_percent` = '" . $discount_percent . "',
                     `discount_type` = '" . $this->db->escape($editor_val['discount_type']) . "',
                     `start_date` = " . (int) $start_date . ",
                     `end_date` = " . (int) $end_date . ",
                     `products_all` = '" . $product_group . "',
                     `discount_variant_discount` = '" . $this->db->escape($editor_val['discount_variant_discount']) . "',
                     `discount_variant_condition` = '" . $this->db->escape($editor_val['discount_variant_condition']) . "',
                     `discount_variant_specials` = '" . $this->db->escape($editor_val['discount_variant_specials']) . "',
                     `discount_variant_options` = '" . $this->db->escape($editor_val['discount_variant_options']) . "',
                     `status` = '" . $status . "'");
                else
                    $this->db->query("UPDATE `" . DB_PREFIX . "hd_quantitative_discount_editor` SET
                     `discount_id` = '" . (int) $quantitative_discount['discount_id'] . "',
                     `editor_id` = '" . (int) $editor_val['editor_id'] . "',
                     `discount_count_products` = '" . $discount_count_products . "',
                     `discount_accumulation_sum` = '" . $discount_accumulation_sum . "',
                     `discount_function` = '" . $this->db->escape($editor_val['discount_function']) . "',
                     `discount_percent` = '" . $discount_percent . "',
                     `discount_type` = '" . $this->db->escape($editor_val['discount_type']) . "',
                     `start_date` = " . (int) $start_date . ",
                     `end_date` = " . (int) $end_date . ",
                     `products_all` = '" . $product_group . "',
                     `discount_variant_discount` = '" . $this->db->escape($editor_val['discount_variant_discount']) . "',
                     `discount_variant_condition` = '" . $this->db->escape($editor_val['discount_variant_condition']) . "',
                     `discount_variant_specials` = '" . $this->db->escape($editor_val['discount_variant_specials']) . "',
                     `discount_variant_options` = '" . $this->db->escape($editor_val['discount_variant_options']) . "',
                     `status` = '" . $status . "' WHERE discount_id = '" . (int) $quantitative_discount['discount_id'] . "' AND editor_id='$editor_key'");
            }
        }
        //   $set_discount_editor = isset($quantitative_discount['discount_editor']) ? $this->db->escape(json_encode($quantitative_discount['discount_editor'])) : '';
        $shops_all = isset($quantitative_discount['shops_all']) ? (int) $quantitative_discount['shops_all'] : null;
        $geos_alls = isset($quantitative_discount['geos_all']) ? (int) $quantitative_discount['geos_all'] : null;

        $correction = isset($quantitative_discount['correction']) ? (int) $quantitative_discount['correction'] : null;
        $customers_all = isset($quantitative_discount['customers_all']) ? (int) $quantitative_discount['customers_all'] : null;
        $guests = isset($quantitative_discount['guests']) ? (int) $quantitative_discount['guests'] : null;
        //echo '<pre>'; print_r($quantitative_discount); die;
        $this->db->query("UPDATE `" . DB_PREFIX . "hd_quantitative` SET
        `name` = '" . $this->db->escape(json_encode($quantitative_discount['name'])) . "',
        `description` = '" . $this->db->escape($quantitative_discount['description']) . "',
        `shops_all` = '" . $shops_all . "',
        `geos_all` = '" . $geos_alls . "',
        `correction` = '$correction', 
        `customers_all` = '" . $customers_all . "',
        `guests` = '" . $guests . "'
        WHERE `id` = '" . (int) $quantitative_discount['discount_id'] . "'");
    }

    public function editClientGroups($discount_id, $groups, $url) {

        $this->db->query("UPDATE `" . DB_PREFIX . "hd_quantitative` SET `customers_filter_url`='$url',`customers` = '" . $this->db->escape(json_encode($groups)) . "' WHERE `id` = '" . (int) $discount_id . "'");
    }

    public function getClientGroups($discount_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hd_quantitative` WHERE `id` = '" . (int) $discount_id . "'");

        if ($query->row['customers'] && !empty($query->row['customers'])) {
            return json_decode($query->row['customers'], true);
        } else {
            return array();
        }
    }

    public function editQuantitativeProducts($discount_id, $groups, $url) {

        $query = $this->db->query("SELECT `discount_id`,`products` FROM `" . DB_PREFIX . "hd_quantitative_discount_editor` WHERE `id` = '" . (int) $discount_id . "'");

        if ($query->row)
            $this->db->query("UPDATE `" . DB_PREFIX . "hd_quantitative_discount_editor` SET `products_filter_url`='$url', `products` = '" . $this->db->escape(json_encode($groups)) . "' WHERE `id` = '" . (int) $discount_id . "'");
        else
            $this->db->query("INSERT INTO `" . DB_PREFIX . "hd_quantitative_discount_editor` SET `products_filter_url`='$url', `id` = '" . (int) $discount_id . "', `products` = '" . $this->db->escape(json_encode($groups)) . "'");

        return $query->row['discount_id'];
    }

    public function getGroupIdDiscount($discount_id) {
        $query = $this->db->query("SELECT `discount_id` FROM `" . DB_PREFIX . "hd_quantitative_discount_editor` WHERE `id` = '" . (int) $discount_id . "' ");
        return $query->row['discount_id'];
    }

    public function getProductFilterUrl($discount_id) {
        $query = $this->db->query("SELECT products_filter_url FROM `" . DB_PREFIX . "hd_quantitative_discount_editor` WHERE `id` = '" . (int) $discount_id . "'");

        if ($query->row['products_filter_url'])
            return $query->row['products_filter_url'];
        else
            return false;
    }

    public function getClientFilterUrl($discount_id) {
        $query = $this->db->query("SELECT `customers_filter_url` FROM `" . DB_PREFIX . "hd_quantitative` WHERE `id` = '" . (int) $discount_id . "';");

        if (isset($query->row['customers_filter_url']))
            return $query->row['customers_filter_url'];
        else
            return false;
    }

    public function ClearGroupProducts($discount_id) {
        $this->db->query("UPDATE `" . DB_PREFIX . "hd_quantitative_discount_editor` SET `products` = '' WHERE `id` = '" . (int) $discount_id . "' ");
    }

    public function getQuantitativeProducts($discount_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "hd_quantitative_discount_editor` WHERE `id` = '" . (int) $discount_id . "'");

        if ($query->row['products']) {
            return json_decode($query->row['products'], true);
        } else {
            return array();
        }
    }

    public function editShopsList($discount_id, $groups) {

        $this->db->query("UPDATE `" . DB_PREFIX . "hd_quantitative` SET `shops` = '" . $this->db->escape(json_encode($groups)) . "' WHERE `id` = '" . (int) $discount_id . "'");
    }

    public function getShopsList($discount_id) {
        $query = $this->db->query("SELECT shops FROM `" . DB_PREFIX . "hd_quantitative` WHERE `id` = '" . (int) $discount_id . "'");

        if ($query->row['shops']) {
            return json_decode($query->row['shops'], true);
        } else {
            return array();
        }
    }

    public function getGeoList($discount_id) {
        $query = $this->db->query("SELECT geos FROM `" . DB_PREFIX . "hd_quantitative` WHERE `id` = '" . (int) $discount_id . "'");

        if ($query->row['geos']) {
            return json_decode($query->row['geos'], true);
        } else {
            return array();
        }
    }

    public function editGeoList($discount_id, $groups) {

        $this->db->query("UPDATE `" . DB_PREFIX . "hd_quantitative` SET `geos_all`='0',`geos` = '" . $this->db->escape(json_encode($groups)) . "' WHERE `id` = '" . (int) $discount_id . "'");
    }

}
