<?php
// Headers
$_['heading_title']				= 'HYPER LOYALTY+';
$_['hyper_wholesale_name']		= 'HYPER LOYALTY+';
$_['hyper_wholesale_title']		= 'Управление лояльностью клиентов';
$_['settings_text']				= 'Настройка';
$_['wholesale_editor_text']		= 'Редактор скидок';
$_['add_name']					= 'Создание скидки';
$_['heading_action_text']		= 'Редактор скидки от количества товара';
$_['wholesale_discount_text']	= 'Скидка от количества товара';
// Name
$_['entry_title']					= 'Заголовок';
$_['entry_title_titles']			= 'Наименование скидки';
$_['entry_description']				= 'Комментарий';
$_['entry_description_titles']		= 'Комментарий | описание к скидке';
$_['entry_shops']					= 'Магазины';
$_['entry_shops_titles']			= 'Редактор магазинов<br>ALL = все магазины<br>EDIT - редактировать';
$_['entry_geo']						= 'Гео-зоны';
$_['entry_geo_titles']				= 'Редактор гео-зон<br>ALL = все магазины<br>EDIT - редактировать';
$_['entry_products_variants']			= 'Вариант';
$_['entry_products_variants_titles']	= 'Скидка или Наценка';
//button
$_['button_edit_shops_list']		= 'Редактировать список магазинов<br>активно только в режиме EDIT';
$_['button_edit_geo_list']			= 'Редактировать список гео-зон<br>активно только в режиме EDIT';
$_['button_product_group_list']		= 'Редактировать группу товаров<br>активно только в режиме EDIT';
$_['button_clone_title']			= 'Клонирование';
$_['button_clone_titles']			= 'Клонировать';

// Editors
$_['entry_users_groups']				= 'Группа покупателей';
$_['entry_users_groups_titles']			= 'Группа покупателей<br>возможен мульти-выбор';
$_['entry_date']						= 'Дата';
$_['entry_date_titles']					= 'Дата начала и окончания<br>Если пусто = всегда';
$_['entry_date_start']					= 'начала';
$_['entry_date_end']					= 'окончания';
$_['entry_product_groups']				= 'Товары';
$_['entry_product_groups_titles']		= 'Редактор товаров<br>ALL = все товары<br>EDIT = редактировать';
$_['entry_qty_title']					= 'Количество и приоритет';
$_['entry_qty_titles']					= 'Кол-во';
$_['entry_priority_titles']				= 'Приоритет';
$_['entry_cost_title']					= 'Исходная цена<br>закупочная - COST<br>основная - PRICE<br>текущая - CURRENT';
$_['entry_round_name']					= 'Округлять';
$_['entry_round_title']					= 'Округление итоговой цены';
//protected
$_['protect_cost']			= 'COST';
$_['protect_price']			= 'PRICE';
$_['protect_current']		= 'CURRENT';
$_['round_no']				= 'Нет';
$_['round_tenth']			= 'до десятых';
$_['round_hundredths']		= 'до сотых';
$_['round_whole_number']	= 'до целого';
$_['round_five']			= 'до 5';
$_['round_nine']			= 'до 9';
$_['round_ten']				= 'до 10';
$_['round_ninety_nine']		= 'до 99';
//
$_['entry_groups_clients']				= 'Группа';
$_['entry_groups_clients_titles']		= 'Группа покупателей<br>';
$_['entry_product_group']				= 'Товары';
$_['entry_product_group_titles']		= 'Редактор товаров<br>ALL = все товары<br>EDIT - редактировать';
$_['entry_discount_formula']			= 'Формула';
$_['entry_discount_formula_titles']		= 'Формула получения<br>итоговой цены скидки';
$_['wholesale_start']			= 'Запуск и приостановка скидок';
$_['wholesale_start_title']		= 'Запустить?';
$_['wholesale_stop_title']		= 'Приостановить?';
$_['column_delete']						= '<b style="line-height: 0; font-size: 18px;">±</b>';
$_['column_delete_titles']				= 'Добавить<br>Удалить';

// Help
$_['help_name']				= 'HELPER';
$_['help_name_titles']		= 'Подсказки';
$_['help_name_title']		= '<b style="color:green;">FAQ</b>';
$_['help_list']				= '<span style="color:green;">Пользуйтесь подсказками "Хелпера" в правом вернем углу каждого пункта
если, что-то не понятно.</span>';
$_['help_text']				= 'Помошник';
$_['help_ok']				= 'Сё понял! Спасибо!';
$_['help_warning']			= '<b style="color:red;">ВАЖНО!</b>';
$_['help_end']				= '<span style="color:red;">Обязательно сохраняйте все изменения в каждом пункте которые вы внесли
- кнопками в правом верхнем углу для перехода к следующему этапу настроек!
<br><i class="fa fa-check-circle-o"></i> - (применить изменения и остаться)
<br><i class="fa fa-lg fa-save"></i> - (сохранить изменения и выйти)</span>';
// Products
$_['help_name_wholesale']		= 'Редактор оптовых цен';

$_['help_first_wholesale']		= '<b>СТАРТ</b>';
$_['help_second_wholesale']		= 'Введите заголовок / наименование данной группы скидок от количества товаров
и его краткое описание / комментарий в соответсвующие для этого поля.
<br>Далее: Сохраните изменения кнопками в правом верхнем углу для перехода к следующему этапу настроек:
<br><i class="fa fa-check-circle-o"></i> - (применить изменения и остаться)
<br><i class="fa fa-lg fa-save"></i> - (сохранить изменения и выйти)
<br>После применения изменений, можете переходить на редактирование добавленной скидки кликнув на иконку
<i class="fa fa-pencil"></i> редактирования со страницы добавления скидки.';
// Info Modal Quantitative
$_['info_first_wholesale']	= '<b>ОПИСАНИЕ</b>';
$_['info_second_wholesale']	= 'Массовый редактор скидок от количества товаров (те самые скидки,
что расположены в редакторе карточки товара админ части).
<br>Позволяет массово создавать скидки от количества товара (от 2х и более)- с гибкими настройками для каждого магазина если вы используете
режим мультимагазина, для товаров на ваш выбор с возможностью их фильтрации по различным параметрам с памятью, тем самым подвязывая
определённую группу товаров к группам покупателей.<br>Получение конечной цены скидки от количества товара используя формулу.
<br>Каждый элемент более детально расписан в <b>HELPER</b>!';

// Help Products One
$_['help_name_wholesale_one']		= 'Настройка';
$_['helper_name_wholesale_one']		= '<b>ВТОРОЙ ЭТАП</b>';
$_['helpers_name_wholesale_one']		= 'Выбрав и настроив нужные вам значения: магазинов, исходную цену для расчёта цены на товар
и один из вариантов округления итоговой цены на ваше усмотрение - сохраните первоначальные изменения кнопками
<i class="fa fa-lg fa-check-circle-o"></i> или <i class="fa fa-lg fa-save"></i>  в правом верхнем углу!
<br>Далее можете переходить на массовое редактирование цен.';
$_['help_first_wholesale_one']		= '<i class="fa fa-pencil-square-o" aria-hidden="true"></i> <b>МАГАЗИНЫ</b>';
$_['help_second_wholesale_one']		= 'Магазины на товары которых будут назначаться цены по каждому товару.
<br>По умолчанию <b style="color:green;">ALL</b> - выбранны все магазины!
<br>Для назначения цен в конкретных магазинах: переключите свитчер в режим <b>EDIT</b> и кликните на активировавшуюся с права иконку
<i class="fa fa-pencil"></i> редактирования.
<br>На открывшейся странице редактора магазинов выберите их по своему усмотрению или при необходимости воспользуйтесь подсказками "Хелпера"!';

$_['help_third_wholesale_one']		= '<i class="fa fa-gg fa-rotate-90" aria-hidden="true"></i> <b>ИСХОДНАЯ ЦЕНА</b>';
$_['help_fourth_wholesale_one']		= 'Выбор исходной цены для расчёта формулой стоимости цены товара:
<br><b>COST</b> - от закупочной стоимости;
<br><b>PRICE</b> - от основной цены;
<br><b>CURRENT</b> - от текущей цены;
<br>Выбор расчёта от закупочной стоимости <b>COST</b> возможен только если вы используете подобный функционал и это поле имеется в БД.
<br>Выбор расчёта от текущей цены <b>CURRENT</b>  возможен только если вы уже настраивали стоимость для этих групп и товаров.';
$_['help_fifth_wholesale_one']		= '<i class="fa fa-pencil-square-o" aria-hidden="true"></i> <b>ОКРУГЛЕНИЕ</b>';
$_['help_sixth_wholesale_one']		= 'Выбор округления итоговой цены.';

// Help Products Two
$_['help_name_wholesale_two']		= 'Редактор скидок';
$_['help_first_wholesale_two']		= '<b>ТРЕТИЙ ЭТАП</b>';
$_['help_second_wholesale_two']		= 'Добавляйте нужное кол-во групп цен кнопкой <i class="fa fa-plus-circle"></i> добавить.
Настроив нужные вам значения <b style="color:green;">ALL</b> / <b>EDIT</b> - на ваше усмотрение и
сохраните изменения кнопкой в правом верхнем углу для перехода к следующему этапу настроек:
<br><i class="fa fa-check-circle-o"></i> - (применить изменения и остаться)
<br>Далее можете переходить на более гибкое редактирование цен для групп покупателей кликнув на иконку
<i class="fa fa-pencil"></i> редактирования.';

$_['help_third_wholesale_two']		= '<i class="fa fa-pencil-square-o" aria-hidden="true"></i> <b>ГРУППЫ ТОВАРОВ</b>';
$_['help_fourth_wholesale_two']		= 'Товары на которые будет назначена цена.
<br>По умолчанию <b style="color:green;">ALL</b> - выбранны все товары!
<br>Для назначения цены на конкретные товары: переключите свитчер в режим <b>EDIT</b> и кликните на активировавшуюся
с права иконку <i class="fa fa-pencil"></i> редактирования.
<br>На открывшейся странице редактора товаров выберите их по своему усмотрению или при необходимости воспользуйтесь подсказками "Хелпера"!';

$_['help_sixth_wholesale_two']		= '<i class="fa fa-pencil-square-o" aria-hidden="true"></i> <b>ГРУППА ПОКУПАТЕЛЕЙ</b>';
$_['help_seventh_wholesale_two']		= 'Выбор групп покупателей к которым будет подвязана назначаемая цена для товара.
<br>Так же возможен мульти-выбор групп покупателей.';

$_['help_eighth_wholesale_two']		= '<i class="fa fa-sort-amount-asc fa-rotate-180" aria-hidden="true"></i> <b>ПРИОРИТЕТ</b>';
$_['help_ninth_wholesale_two']		= 'Поле приоритет - (если кто мне объяснит смысл и надобность этого приоритета буду весьма вам признателен ;)';

$_['help_tenth_wholesale_two']		= '<i class="fa fa-pencil-square-o" aria-hidden="true"></i> <b>ФОРМУЛА</b>';
$_['help_eleventh_wholesale_two']		= 'Формула формирования итоговой цены.
<br>В выпадающем списке выберите одно из необходимых вам действий (+, -, *, /,.. и т.д.).
<br>Далее в поле с права от него введите необходимое значение.
<br>Учтите, что формула рассчитывает каждое поле последовательно!
<br>Можете использовать любое одно, любые два или все три поля на ваше усмотрение!
<br>Если нет надобности в каких либо полях, то просто оставьте в этом поле выподающий список действий пустым.
В таком случае это поле не зависимо от его значения будет игнорироваться.**';

$_['help_twelfth_wholesale_two']		= '<i class="fa fa-pencil-square-o" aria-hidden="true"></i> <b>ДАТА</b>';
$_['help_thirteenth_wholesale_two']		= 'Время действия цены.
<br>По умолчанию дата не установленна (Пустое поле = время действия - всегда).
<br>Для назначения цены в определённое время установите свою дату от её начала и до её конца включительно!';

$_['help_fourteenth_wholesale_two']		= '<i class="fa fa-eject fa-rotate-90" aria-hidden="true"></i> <b>СТАРТ и ПАУЗА</b>';
$_['help_fifteenth_wholesale_two']		= 'Запуск и отключение назначеных цен.
<br>На кнопке высвечивается индикатор <i class="fa fa-pause" aria-hidden="true"></i> - это значит, что отображение цен приостановлено.
<br>На кнопке высвечивается индикатор <i class="fa fa-play" aria-hidden="true"></i> - это значит, что отображение цен запущено.
<br>Для запуска или приостановки отображения цен нажмите на кнопку с индикаторами.
<br><b style="color:red;">ВАЖНО!</b>: Пркежде чем запустить какое либо отображение цен, обязательно сохраните все изменения кнопкой
<i class="fa fa-lg fa-check-circle-o"></i>  в правом верхнем углу!';

$_['help_sixteenth_wholesale_two']		= '<i class="fa fa-clone" aria-hidden="true"></i> <b>КЛОНИРОВАНИЕ</b>';
$_['help_seventeenth_wholesale_two']	= 'Функция клонирования отредактированной группы цен. Упрощает работу с редактированием товаров.
Если вы хотите применить иную формулу, группу покупателей к уже используемым товарам в каком либо редакторе, то просто нажмите для её
клонирования на кнопку <i class="fa fa-lg fa-clone" aria-hidden="true"></i> и отредактируйте на ваше усмотрение.';

$_['help_twentysecond_wholesale_two']	= '<b style="line-height: 0; font-size: 18px;">±</b>';
$_['help_twentythird_wholesale_two']	= 'Иконка <i class="fa fa-plus-circle"></i> добавить редактор:
добавляет неопределённое количество скидок.<br>Иконка <i class="fa fa-minus-circle"></i> удалить редактор: удаляет редактор и все сохранения в таблице!
Будьте осторожны, востановление данных удалёного редактора цен не возможно!';
$_['help_end_wholesale_two']			= 'Общее описание вкладок скидок';
// Authors
$_['description_author']			= 'Разработка';
$_['description_copyright']			= 'Правооблодатели';
$_['description_author_start']		= '2016-2017 © k&A';
$_['description_author_copyright']	= 'Все права на данное программное обеспечение пренадлежат её авторам <br>
<br><br><b>2016-2017 © k&A</b>';
$_['thank_you']			= '';
// Error
$_['error_name']			= 'Впишите заголовок!';
$_['error_warning']			= 'У вас не достаточно прав на добавление удаление и редактирование этого модуля!';