<?php
//Error page
$_['heading_title']				= 'Ошибка';
$_['hyper_discount_name']		= 'HYPER LOYALTY +';
$_['hyper_discount_title']		= 'Управление лояльностью клиентов';
$_['text_title']				= 'Не достаточно прав!';
$_['text_go_back']				= 'Вернуться обратно';
$_['text_errors']				= 'У вас не достаточно прав на редактирование и сохранение данных модуля, обратитесь к администратору!';
// Authors
$_['help_ok']						= 'Сё понял! Спасибо!';
$_['description_author']			= 'Разработка';
$_['description_copyright']			= 'Правообладатели';
$_['description_author_start']		= '2016-2017 © k&A';
$_['description_author_copyright']	= 'Все права на данное программное обеспечение пренадлежат её авторам <br>
<br><br><b>2016-2017 © k&A</b>';
$_['thank_you']			= '';

