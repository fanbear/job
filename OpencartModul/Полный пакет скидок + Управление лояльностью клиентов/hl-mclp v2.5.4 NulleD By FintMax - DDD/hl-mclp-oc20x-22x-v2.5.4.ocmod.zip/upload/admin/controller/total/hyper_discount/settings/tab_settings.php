<?php
class ControllerTotalHyperDiscountSettingsTabSettings extends Controller {

    public function index() {

        $data['tmp'] = 'tmp';

        return $this->load->view('total/hyper_discount/settings/tab_settings.tpl', $data);
    }

}