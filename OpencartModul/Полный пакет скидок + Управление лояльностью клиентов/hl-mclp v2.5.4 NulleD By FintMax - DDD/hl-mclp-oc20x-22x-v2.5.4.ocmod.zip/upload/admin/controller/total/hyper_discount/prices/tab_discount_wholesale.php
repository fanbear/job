<?php

class ControllerTotalHyperDiscountPricesTabDiscountWholesale extends Controller {

    private $_text_string = array(
        'tab_name_wholesale',
        // Column
        'column_name',
        'column_name_titles',
        'column_description',
        'column_description_titles',
        'column_edit',
        'column_edit_titles',
        'column_status',
        'column_status_titles',
        'column_delete',
        'column_delete_titles',
        'column_sort_order',
        'column_sort_order_titles',
        // Buttons
        'button_add',
        'button_edit',
        'button_delete',
        // Help
        'help_name',
        'help_name_title',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help Users
        'help_name_wholesale',
        'help_wholesale_text',
        'help_first_wholesale',
        'help_second_wholesale',
        'help_third_wholesale',
        'help_fourth_wholesale',
        'help_fifth_wholesale',
        'help_sixth_wholesale',
        'help_seventh_wholesale',
        'help_eighth_wholesale',
        'help_eleventh_wholesale',
        'help_twelfth_wholesale',
        'help_thirteenth_wholesale',
        'help_fourteenth_wholesale',
        'help_fifteenth_wholesale',
        'help_sixteenth_wholesale',
    );

    public function index() {

        $this->load->language('total/hyper_discount/prices/tab_discount_wholesale');

        foreach ($this->_text_string as $text) {
            $data[$text] = $this->language->get($text);
        }

        $this->load->model('total/hyper_discount/wholesale_discount');

        $discounts_list = $this->model_total_hyper_discount_wholesale_discount->getWholesaleDiscountsList();

        $data['wholesale_discounts'] = array();
        foreach ($discounts_list as $discount) {
            $data['wholesale_discounts'][] = array(
                'discount_id' => $discount['id'],
                'name' => ($discount['name']) ? json_decode($discount['name'], true)[$this->config->get('config_language_id')] : null,
                'description' => ($discount['description']) ? $discount['description'] : null,
                'sort' => isset($discount['sort']) ? $discount['sort'] : null,
                'status' => isset($discount['status']) ? $discount['status'] : null,
                'delete' => $this->url->link('total/hyper_discount/prices/wholesale/delete_wholesale_discount', 'token=' . $this->session->data['token'] . '&wholesale_discount_id=' . $discount['id'], 'SSL'),
                'edit' => $this->url->link('total/hyper_discount/prices/wholesale/edit_wholesale_discount', 'token=' . $this->session->data['token'] . '&wholesale_discount_id=' . $discount['id'], 'SSL'),
            );
        }

        $data['add_discount_wholesale'] = $this->url->link('total/hyper_discount/prices/wholesale/add_wholesale_discount', 'token=' . $this->session->data['token'], 'SSL');

        return $this->load->view('total/hyper_discount/prices/tab_discount_wholesale.tpl', $data);
    }

}
