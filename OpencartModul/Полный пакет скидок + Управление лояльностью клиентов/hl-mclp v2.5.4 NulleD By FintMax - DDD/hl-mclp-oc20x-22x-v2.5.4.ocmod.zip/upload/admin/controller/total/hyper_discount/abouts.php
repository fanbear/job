<?php
class ControllerTotalHyperDiscountAbouts extends Controller{

    public function index() {

    }

}