<?php

class ControllerTotalHyperDiscountDiscountEditShopsList extends Controller {

    private $error = array();
    private $_text_string = array(
        'heading_title',
        'hyper_discount_name',
        'hyper_discount_title',
        'description_author',
        'description_author_start',
        'description_author_copyright',
        'thank_you',
        'heading_action_text',
        'description_copyright',
        'button_apply',
        'button_save',
        'button_cancel',
        'text_list',
        'text_no_results',
        'text_confirm',
        'column_name',
        'column_url',
        'column_action',
        'help_name',
        'help_name_titles',
        'help_name_title',
        'help_text',
        'help_first_text',
        'help_second_text',
        'help_third_text',
        'help_fourth_text',
        'help_end_text',
        'help_ok',
    );

    public function index() {

        $this->document->addStyle('view/stylesheet/hyper_loyalty.css');

        if (isset($this->request->get['user_discount_id'])) {

            $data['action'] = $this->url->link('total/hyper_discount/discount/edit_shops_list', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');

            $data['cancel'] = $this->url->link('total/hyper_discount/discount/users/edit_users_discount', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');
            $data['discount_action'] = 'users';

            $this->load->model('total/hyper_discount/users_discount');

            $data['selected'] = $this->model_total_hyper_discount_users_discount->getShopsList($this->request->get['user_discount_id']);
        } elseif (isset($this->request->get['accumulative_discount_id'])) {

            $data['action'] = $this->url->link('total/hyper_discount/discount/edit_shops_list', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');

            $data['cancel'] = $this->url->link('total/hyper_discount/discount/accumulative/edit_accumulative_discount', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
            $data['discount_action'] = 'accumulative';

            $this->load->model('total/hyper_discount/accumulative_discount');

            $data['selected'] = $this->model_total_hyper_discount_accumulative_discount->getShopsList($this->request->get['accumulative_discount_id']);
        } elseif (isset($this->request->get['quantitative_discount_id'])) {

            $data['action'] = $this->url->link('total/hyper_discount/discount/edit_shops_list', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'], 'SSL');

            $data['cancel'] = $this->url->link('total/hyper_discount/discount/quantitative/edit_quantitative_discount', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'], 'SSL');
            $data['discount_action'] = 'quantitative';

            $this->load->model('total/hyper_discount/quantitative_discount');

            $data['selected'] = $this->model_total_hyper_discount_quantitative_discount->getShopsList($this->request->get['quantitative_discount_id']);
        } elseif (isset($this->request->get['kit_discount_id'])) {

            $data['action'] = $this->url->link('total/hyper_discount/discount/edit_shops_list', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'], 'SSL');

            $data['cancel'] = $this->url->link('total/hyper_discount/discount/quantitative/edit_kit_discount', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'], 'SSL');
            $data['discount_action'] = 'kit';

            $this->load->model('total/hyper_discount/kit_discount');

            $data['selected'] = $this->model_total_hyper_discount_kit_discount->getShopsList($this->request->get['kit_discount_id']);
        }
        elseif (isset($this->request->get['products_discount_id'])) {

            $data['action'] = $this->url->link('total/hyper_discount/discount/edit_shops_list', 'token=' . $this->session->data['token'] . '&products_discount_id=' . $this->request->get['products_discount_id'], 'SSL');

            $data['cancel'] = $this->url->link('total/hyper_discount/discount/quantitative/edit_shops_list', 'token=' . $this->session->data['token'] . '&products_discount_id=' . $this->request->get['products_discount_id'], 'SSL');
            $data['discount_action'] = 'products';

            $this->load->model('total/hyper_discount/products_discount');

            $data['selected'] = $this->model_total_hyper_discount_products_discount->getShopsList($this->request->get['products_discount_id']);
        }
        

        //permission
        if (isset($this->request->post['discount_action']) && !$this->validateForm()) {
            $this->session->data['error'] = $this->error;
            $this->response->redirect($this->url->link('total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
        }
        //permission
        else if (isset($this->request->post['discount_action']) && $this->validateForm()) {

            $form_action = $this->request->post['discount_action'];

            if ($form_action == 'users') {

                $this->load->model('total/hyper_discount/users_discount');

                $groups = isset($this->request->post['selected']) ? $this->request->post['selected'] : array();

                $this->model_total_hyper_discount_users_discount->editShopsList($this->request->get['user_discount_id'], $groups);

                $this->response->redirect($this->url->link('total/hyper_discount/discount/users/edit_users_discount', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL'));
            } elseif ($form_action == 'accumulative') {

                $this->load->model('total/hyper_discount/accumulative_discount');

                $groups = isset($this->request->post['selected']) ? $this->request->post['selected'] : array();

                $this->model_total_hyper_discount_accumulative_discount->editShopsList($this->request->get['accumulative_discount_id'], $groups);

                $this->response->redirect($this->url->link('total/hyper_discount/discount/accumulative/edit_accumulative_discount', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL'));
            } elseif ($form_action == 'quantitative') {

                $this->load->model('total/hyper_discount/quantitative_discount');

                $groups = isset($this->request->post['selected']) ? $this->request->post['selected'] : array();

                $this->model_total_hyper_discount_quantitative_discount->editShopsList($this->request->get['quantitative_discount_id'], $groups);

                $this->response->redirect($this->url->link('total/hyper_discount/discount/quantitative/edit_quantitative_discount', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $this->request->get['quantitative_discount_id'], 'SSL'));
            } elseif ($form_action == 'kit') {

                $this->load->model('total/hyper_discount/kit_discount');

                $groups = isset($this->request->post['selected']) ? $this->request->post['selected'] : array();

                $this->model_total_hyper_discount_kit_discount->editShopsList($this->request->get['kit_discount_id'], $groups);

                $this->response->redirect($this->url->link('total/hyper_discount/discount/kit/edit_kit_discount', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $this->request->get['kit_discount_id'], 'SSL'));
            }
            elseif ($form_action == 'products') {

                $this->load->model('total/hyper_discount/kit_discount');

                $groups = isset($this->request->post['selected']) ? $this->request->post['selected'] : array();

                $this->model_total_hyper_discount_products_discount->editShopsList($this->request->get['products_discount_id'], $groups);

                $this->response->redirect($this->url->link('total/hyper_discount/discount/products/edit_products_discount', 'token=' . $this->session->data['token'] . '&products_discount_id=' . $this->request->get['products_discount_id'], 'SSL'));
            }
        }

        $this->load->language('total/hyper_discount/discount/edit_shops_list');
        foreach ($this->_text_string as $text) {
            $data[$text] = $this->language->get($text);
        }
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/store');

        $data['stores'] = array();

        $data['stores'][] = array(
            'store_id' => 0,
            'name' => $this->config->get('config_name') . $this->language->get('text_default'),
            'url' => HTTP_CATALOG,
            'edit' => $this->url->link('setting/setting', 'token=' . $this->session->data['token'], 'SSL')
        );

        $results = $this->model_setting_store->getStores();

        foreach ($results as $result) {
            $data['stores'][] = array(
                'store_id' => $result['store_id'],
                'name' => $result['name'],
                'url' => $result['url'],
                'edit' => $this->url->link('setting/store/edit', 'token=' . $this->session->data['token'] . '&store_id=' . $result['store_id'], 'SSL')
            );
        }


        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('total/hyper_discount/discount/edit_shops_list.tpl', $data));
    }

    protected function validateForm() {
        $this->language->load('total/hyper_discount');

        if (!$this->user->hasPermission('modify', 'total/hyper_discount'))
            $this->error['warning'] = $this->language->get('error_permission');

        return !$this->error;
    }

}
