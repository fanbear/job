<?php
class ControllerTotalHyperDiscountDiscountTabDiscountQuantitative extends Controller {

    private $_text_string = array(

        // Head
        'tab_discount_quantitative',
        // Buttons
        'button_add',
        'button_edit',
        'button_delete',
        // Column
        'column_name',
        'column_name_titles',
        'column_description',
        'column_description_titles',
        'column_edit',
        'column_edit_titles',
        'column_sort_order',
        'column_sort_order_titles',
        'column_status',
        'column_status_titles',
        'column_delete',
        'column_delete_titles',
        // Help
        'help_name',
        'help_name_title',
        'help_name_titles',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help Quantitative
        'help_name_quantitative',
        'help_first_quantitative',
        'help_second_quantitative',
        'help_third_quantitative',
        'help_fourth_quantitative',
        'help_fifth_quantitative',
        'help_sixth_quantitative',
        'help_seventh_quantitative',
        'help_eighth_quantitative',
        'help_ninth_quantitative',
        'help_tenth_quantitative',
        'help_eleventh_quantitative',
        'help_twelfth_quantitative',
        'help_thirteenth_quantitative',
        'help_fourteenth_quantitative',
        'help_fifteenth_quantitative',
        'help_sixteenth_quantitative',

    );

    public function index() {

        $this->load->language('total/hyper_discount/discount/tab_discount_quantitative');

        foreach ($this->_text_string as $text) {
            $data[$text] = $this->language->get($text);
        }

        $this->load->model('total/hyper_discount/quantitative_discount');

        $discounts_list = $this->model_total_hyper_discount_quantitative_discount->getQuantitativeDiscountsList();

        $data['quantitative_discounts'] = array();

        foreach($discounts_list as $discount){
            $data['quantitative_discounts'][] = array(
                'discount_id' => $discount['id'],
                'name' => ($discount['name']) ? json_decode($discount['name'], true)[$this->config->get('config_language_id')] : null,
                'description' => ($discount['description']) ? $discount['description'] : null,
                'sort' => isset($discount['sort']) ? $discount['sort'] : null,
                'status' => isset($discount['status']) ? $discount['status'] : null,
                'delete'        => $this->url->link('total/hyper_discount/discount/quantitative/delete_quantitative_discount', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $discount['id'], 'SSL'),
                'edit'        => $this->url->link('total/hyper_discount/discount/quantitative/edit_quantitative_discount', 'token=' . $this->session->data['token'] . '&quantitative_discount_id=' . $discount['id'], 'SSL'),

            );
        }

        $data['add_discount_quantitative'] = $this->url->link('total/hyper_discount/discount/quantitative/add_quantitative_discount', 'token=' . $this->session->data['token'], 'SSL');

        return $this->load->view('total/hyper_discount/discount/tab_discount_quantitative.tpl', $data);
    }


}