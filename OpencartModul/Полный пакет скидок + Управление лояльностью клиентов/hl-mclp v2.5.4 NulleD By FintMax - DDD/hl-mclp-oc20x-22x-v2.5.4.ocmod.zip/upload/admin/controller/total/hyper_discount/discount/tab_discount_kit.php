<?php
class ControllerTotalHyperDiscountDiscountTabDiscountKit extends Controller {

    private $_text_string = array(

        // Head
        'tab_discount_kit',
        // Buttons
        'button_add',
        'button_edit',
        'button_delete',
        // Column
        'column_name',
        'column_name_titles',
        'column_description',
        'column_description_titles',
        'column_edit',
        'column_edit_titles',
        'column_sort_order',
        'column_sort_order_titles',
        'column_status',
        'column_status_titles',
        'column_delete',
        'column_delete_titles',
        // Help
        'help_name',
        'help_name_title',
        'help_name_titles',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help kit
        'help_name_kit',
        'help_first_kit',
        'help_second_kit',
        'help_third_kit',
        'help_fourth_kit',
        'help_fifth_kit',
        'help_sixth_kit',
        'help_seventh_kit',
        'help_eighth_kit',
        'help_ninth_kit',
        'help_tenth_kit',
        'help_eleventh_kit',
        'help_twelfth_kit',
        'help_thirteenth_kit',
        'help_fourteenth_kit',
        'help_fifteenth_kit',
        'help_sixteenth_kit',

    );

    public function index() {

        $this->load->language('total/hyper_discount/discount/tab_discount_kit');

        foreach ($this->_text_string as $text) {
            $data[$text] = $this->language->get($text);
        }

        $this->load->model('total/hyper_discount/kit_discount');

        $discounts_list = $this->model_total_hyper_discount_kit_discount->getKitDiscountsList();

        $data['kit_discounts'] = array();

        foreach($discounts_list as $discount){
            $data['kit_discounts'][] = array(
                'discount_id' => $discount['id'],
                'name' => ($discount['name']) ? json_decode($discount['name'], true)[$this->config->get('config_language_id')] : null,
                'description' => ($discount['description']) ? $discount['description'] : null,
                'sort' => isset($discount['sort']) ? $discount['sort'] : null,
                'status' => isset($discount['status']) ? $discount['status'] : null,
                'delete'        => $this->url->link('total/hyper_discount/discount/kit/delete_kit_discount', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $discount['id'], 'SSL'),
                'edit'        => $this->url->link('total/hyper_discount/discount/kit/edit_kit_discount', 'token=' . $this->session->data['token'] . '&kit_discount_id=' . $discount['id'], 'SSL'),

            );
        }

        $data['add_discount_kit'] = $this->url->link('total/hyper_discount/discount/kit/add_kit_discount', 'token=' . $this->session->data['token'], 'SSL');

        return $this->load->view('total/hyper_discount/discount/tab_discount_kit.tpl', $data);
    }


}