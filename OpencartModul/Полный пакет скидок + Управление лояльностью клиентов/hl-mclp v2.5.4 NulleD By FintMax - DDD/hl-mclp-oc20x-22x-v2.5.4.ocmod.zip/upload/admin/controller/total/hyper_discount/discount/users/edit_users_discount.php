<?php

class ControllerTotalHyperDiscountDiscountUsersEditUsersDiscount extends Controller {

    private $error = array();
    private $_text_string = array(
        'hyper_discount_name',
        'hyper_discount_title',
        'users_discount_text',
        'settings_text',
        'heading_action_text',
        'discount_editor_text',
        'column_delete',
        'column_delete_titles',
        // Buttons
        'button_save',
        'button_cancel',
        'button_apply',
        'button_remove',
        'button_add',
        'button_edit_shops_list',
        'button_edit_geo_list',
        'button_users_groups_list',
        'button_client_group_list',
        'button_product_group_list',
        // For select
        'entry_title',
        'entry_title_titles',
        'entry_description',
        'entry_description_titles',
        'entry_shops',
        'entry_shops_titles',
        'entry_geo',
        'entry_guest',
        'entry_guest_titles',
        'entry_geo_titles',
        'entry_users_groups',
        'entry_users_groups_titles',
        'entry_client_group',
        'entry_client_group_titles',
        'entry_users_variants',
        'entry_users_variants_titles',
        'users_price_correction_titles',
        'entry_date_available',
        'entry_discount_specials_condition',
        'entry_discount_specials_condition_titles',
        'entry_product_groups',
        'entry_product_groups_titles',
        'entry_discounts',
        'entry_discounts_titles',
        'entry_options',
        'entry_options_titles',
        'entry_stock',
        'entry_stock_titles',
        'entry_product_group',
        'entry_product_group_titles',
        'entry_discount_percent',
        'entry_discount_percent_titles',
        'entry_discount_editor_status',
        'entry_discount_editor_status_titles',
        'entry_date',
        'entry_date_titles',
        'entry_date_start',
        'entry_date_end',
        // Help
        'help_name',
        'help_name_title',
        'help_name_titles',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help Users
        'help_name_users',
        'help_first_users',
        'help_second_users',


        'info_first_users',
        'info_second_users',
        'info_third_users',
        'info_fourth_users',
        // Help Users One
        'help_name_users_one',
        'helper_name_users_one',
        'helpers_name_users_one',
        'help_first_users_one',
        'help_second_users_one',
        'help_third_users_one',
        'help_fourth_users_one',
        'help_fifth_users_one',
        'help_sixth_users_one',
        'help_seventh_users_one',
        'help_eighth_users_one',
        'help_ninth_users_one',
        'help_tenth_users_one',
        // Help Users Two
        'help_name_users_two',
        'help_first_users_two',
        'help_second_users_two',
        'help_third_users_two',
        'help_fourth_users_two',
        'help_fifth_users_two',
        'help_sixth_users_two',
        'help_seventh_users_two',
        'help_eighth_users_two',
        'help_ninth_users_two',
        'help_tenth_users_two',
        'help_eleventh_users_two',
        'help_twelfth_users_two',
        'help_thirteenth_users_two',
        'help_fourteenth_users_two',
        'help_fifteenth_users_two',
        'help_sixteenth_users_two',
        'help_seventeenth_users_two',
        'help_eighteenth_users_two',
        'help_nineteenth_users_two',
        'help_twentieth_users_two',
        'help_twentyfirst_users_two',
        'help_twentysecond_users_two',
        'help_twentythird_users_two',
        'description_author',
        'description_author_start',
        'description_author_copyright',
        'thank_you',
        'heading_action_text',
        'description_copyright',
        //protected
        'protect_default',
        'protect_active',
        'protect_ignore',
        'protect_active_plus',
        'protect_ignore_minus',
        'protect_priority',
        'protect_summary',
        'protect_discount',
        'protect_markup',
    );
    protected $_discounts = array('protect_active', 'protect_ignore', 'protect_priority', 'protect_summary');
    protected $_options = array('protect_active', 'protect_ignore');
    protected $_specials = array('protect_active', 'protect_ignore', 'protect_summary');
    protected $_discount_condition = array('protect_discount', 'protect_markup');
    protected $_discount_specials_condition = array('protect_priority', 'protect_default');
    protected $_discount_types = array("%", "each fix", "full fix");

    public function index() {
        $this->load->model('total/hyper_discount/setting');
        
        $settings = $this->model_total_hyper_discount_setting->getSetting();
        $data['discount_variant'] = $settings;
        $this->load->language('total/hyper_discount/discount/users/add_users_discount');

        $this->session->data['editable_prods'] = FALSE;
        $this->session->data['editable_clients'] = FALSE;
        //
        $all_protected_arr = array(
            '_discounts',
            '_options',
            '_specials',
            '_discount_condition',
            '_discount_specials_condition'
        );

        foreach ($all_protected_arr as $arr_name)
            foreach ($this->$arr_name as $key => $val) {
                $arr = &$this->$arr_name;
                $arr[$val] = $this->language->get($val);
                unset($arr[$key]);
            }
        //
        $this->document->addStyle('view/stylesheet/hyper_loyalty.css');
        $this->document->addStyle('view/javascript/bootstrap/css/bootstrap-switch.min.css');
        $this->document->addScript('view/javascript/bootstrap/js/bootstrap-switch.min.js');

        $this->load->model('total/hyper_discount/users_discount');
        //permission
        if ($this->request->server['REQUEST_METHOD'] == 'POST' && !$this->validateForm()) {
            $this->session->data['error'] = $this->error;
            $this->response->redirect($this->url->link('total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
        }
        //permission
        else if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validateForm()) {
            $this->model_total_hyper_discount_users_discount->editUsersDiscount($this->request->post['user_discount']);
            $this->response->redirect($this->url->link('total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-discount-users', 'SSL'));
        } elseif (isset($this->request->get['user_discount_id'])) {
            $discount_settings = $this->model_total_hyper_discount_users_discount->getUsersDiscount($this->request->get['user_discount_id']);
            $discount_editor = $this->model_total_hyper_discount_users_discount->getUsersDiscountEditor($this->request->get['user_discount_id']);
            
            foreach ($discount_editor as $discount_editor_k => $discount_editor_v) {
                $id=$discount_editor_v['id'];
     
                $editor_id = isset($discount_editor_v['editor_id']) ? $discount_editor_v['editor_id'] : 0;
                $save_param = $this->model_total_hyper_discount_users_discount->getProductFilterUrl($id);

                $discount_editor[$discount_editor_k]['product_group_href'] = $this->url->link('total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $id, 'SSL');

                if ($save_param)
                    $discount_editor[$discount_editor_k]['product_group_href'] .= $save_param;
            }


            $data['user_discount'] = array(
                'discount_id' => $discount_settings['id'],
                'name' => ($discount_settings['name']) ? json_decode($discount_settings['name'], true) : null,
                'description' => ($discount_settings['description']) ? $discount_settings['description'] : null,
                'geos_all' => ($discount_settings['geos_all']) ? $discount_settings['geos_all'] : false,
                'guests' => ($discount_settings['guests']) ? $discount_settings['guests'] : false,
                'correction' => ($discount_settings['correction']) ? $discount_settings['correction'] : null,
                'customers_all' => ($discount_settings['customers_all']) ? $discount_settings['customers_all'] : false,
                'shops_all' => ($discount_settings['shops_all']) ? $discount_settings['shops_all'] : false,
                'discount_editor' => isset($discount_editor) ? $discount_editor : array(),
                'status' => isset($discount_settings['status']) ? $discount_settings['status'] : null,
            );
        }

        $this->document->setTitle($this->language->get('heading_title'));


        foreach ($this->_text_string as $text) {
            $data[$text] = $this->language->get($text);
        }

        $data['array_discounts'] = $this->_discounts;
        $data['array_specials'] = $this->_specials;
        $data['array_options'] = $this->_options;
        $data['array_discount_types'] = $this->_discount_types;
        $data['array_discount_condition'] = $this->_discount_condition;
        $data['array_discount_specials_condition'] = $this->_discount_specials_condition;

        $data['action'] = $this->url->link('total/hyper_discount/discount/users/edit_users_discount', 'token=' . $this->session->data['token'], 'SSL');

        $data['update_stay'] = $this->url->link('total/hyper_discount/discount/users/edit_users_discount/update', 'token=' . $this->session->data['token'], 'SSL');

        $data['cancel'] = $this->url->link('total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-discount-users', 'SSL');

        $data['edit_client_group'] = $this->url->link('total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');
        $data['edit_geo_list'] = $this->url->link('total/hyper_discount/discount/edit_geo_list', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');
//        $data['edit_users_groups'] = $this->url->link('total/hyper_discount/discount/edit_users_groups', 'token=' . $this->session->data['token'] . '&accumulative_discount_id=' . $this->request->get['accumulative_discount_id'], 'SSL');
        $data['edit_shops_list'] = $this->url->link('total/hyper_discount/discount/edit_shops_list', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');
        $data['edit_product_groups'] = $this->url->link('total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');
        $data['discount_editor_edit_product_groups'] = $this->url->link('total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->get['user_discount_id'], 'SSL');

        $client_filter_url = $this->model_total_hyper_discount_users_discount->getClientFilterUrl($this->request->get['user_discount_id']);
        if ($client_filter_url)
            $data['edit_client_group'] .= $client_filter_url;


        $this->load->model('localisation/language');

        $data['languages'] = $this->model_localisation_language->getLanguages();

        $data['lang'] = $this->language->get('lang');

        $data['config_language_id'] = $this->config->get('config_language_id');


        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('total/hyper_discount/discount/users/users_discount_form.tpl', $data));
    }

    public function update() {
        //permisson
        if ($this->request->server['REQUEST_METHOD'] == 'POST' && isset($this->request->post['user_discount']['discount_id']) && !$this->validateForm()) {
            $this->session->data['error'] = $this->error;
            $this->response->redirect($this->url->link('total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
        }
        //
        else if ($this->request->server['REQUEST_METHOD'] == 'POST' && isset($this->request->post['user_discount']['discount_id']) && $this->validateForm()) {
            $this->load->model('total/hyper_discount/users_discount');

            $this->model_total_hyper_discount_users_discount->editUsersDiscount($this->request->post['user_discount']);
            $this->response->redirect($this->url->link('total/hyper_discount/discount/users/edit_users_discount', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $this->request->post['user_discount']['discount_id'], 'SSL'));
        }
    }

    protected function validateForm() {
        $this->language->load('total/hyper_discount');

        if (!$this->user->hasPermission('modify', 'total/hyper_discount'))
            $this->error['warning'] = $this->language->get('error_permission');

        return !$this->error;
    }

}
