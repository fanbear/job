<?php

class ControllerTotalHyperDiscountDiscountAccumulativeDeleteAccumulativeDiscount extends Controller {

    private $error = array();

    public function index() {
        
        //permission
        if (isset($this->request->get['accumulative_discount_id']) && !$this->validateForm()) {
            $this->session->data['error'] = $this->error;
            $this->response->redirect($this->url->link('total/hyper_discount/error', 'token=' . $this->session->data['token']. '&tab=tab-discount-accumulative', 'SSL'));
        }
        //permission
        else if (isset($this->request->get['accumulative_discount_id']) && $this->validateForm()) {
            $this->load->model('total/hyper_discount/accumulative_discount');
            $this->model_total_hyper_discount_accumulative_discount->deleteAccumulativeDiscount($this->request->get['accumulative_discount_id']);
        }

        $this->response->redirect($this->url->link('total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-discount-accumulative', 'SSL'));
    }

    protected function validateForm() {
        $this->language->load('total/hyper_discount');

        if (!$this->user->hasPermission('modify', 'total/hyper_discount'))
            $this->error['warning'] = $this->language->get('error_permission');

        return !$this->error;
    }

}
