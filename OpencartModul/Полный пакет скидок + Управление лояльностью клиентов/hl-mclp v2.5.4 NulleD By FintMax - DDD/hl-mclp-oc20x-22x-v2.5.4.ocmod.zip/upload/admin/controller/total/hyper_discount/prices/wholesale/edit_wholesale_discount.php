<?php

class ControllerTotalHyperDiscountPricesWholesaleEditWholesaleDiscount extends Controller {

    private $error = array();
    private $_text_string = array(
        'hyper_wholesale_name',
        'hyper_wholesale_title',
        'wholesale_discount_text',
        'settings_text',
        'heading_action_text',
        'wholesale_editor_text',
        'column_delete',
        'column_delete_titles',
        // Buttons
        'button_save',
        'button_cancel',
        'button_apply',
        'button_remove',
        'button_add',
        'button_edit_shops_list',
        'button_edit_geo_list',
        'button_users_groups_list',
        'button_product_group_list',
        'button_clone_title',
        'button_clone_titles',
        // For select
        'entry_title',
        'entry_title_titles',
        'entry_description',
        'entry_description_titles',
        'entry_shops',
        'entry_shops_titles',
        'entry_geo',
        'entry_geo_titles',
        'entry_users_groups',
        'entry_users_groups_titles',
        'entry_products_variants',
        'entry_products_variants_titles',
        'entry_cost_title',
        'entry_round_name',
        'entry_round_title',
        'entry_qty_title',
        'entry_qty_titles',
        'entry_priority_titles',
        'entry_date_available',
        'entry_product_groups',
        'entry_product_groups_titles',
        'entry_product_group',
        'entry_product_group_titles',
        'entry_discount_formula',
        'entry_discount_formula_titles',
        'wholesale_start',
        'wholesale_start_title',
        'wholesale_stop_title',
        'entry_date',
        'entry_date_titles',
        'entry_date_start',
        'entry_date_end',
        // Help
        'help_name',
        'help_name_title',
        'help_name_titles',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help wholesale
        'help_name_wholesale',
        'help_first_wholesale',
        'help_second_wholesale',
        // Help wholesale One
        'help_name_wholesale_one',
        'helper_name_wholesale_one',
        'helpers_name_wholesale_one',
        'help_first_wholesale_one',
        'help_second_wholesale_one',
        'help_third_wholesale_one',
        'help_fourth_wholesale_one',
        'help_fifth_wholesale_one',
        'help_sixth_wholesale_one',

        // Help wholesale Two
        'help_name_wholesale_two',
        'help_first_wholesale_two',
        'help_second_wholesale_two',
        'help_third_wholesale_two',
        'help_fourth_wholesale_two',
        'help_fifth_wholesale_two',
        'help_sixth_wholesale_two',
        'help_seventh_wholesale_two',
        'help_eighth_wholesale_two',
        'help_ninth_wholesale_two',
        'help_tenth_wholesale_two',
        'help_eleventh_wholesale_two',
        'help_twelfth_wholesale_two',
        'help_thirteenth_wholesale_two',
        'help_fourteenth_wholesale_two',
        'help_fifteenth_wholesale_two',
        'help_sixteenth_wholesale_two',
        'help_seventeenth_wholesale_two',
        'help_twentysecond_wholesale_two',
        'help_twentythird_wholesale_two',
        'description_author',
        'description_author_start',
        'description_author_copyright',
        'thank_you',
        'heading_action_text',
        'description_copyright',
        //protected
        'protect_current',
        'protect_price',
        'protect_cost',
        'round_no',
        'round_tenth',
        'round_hundredths',
        'round_whole_number',
        'round_five',
        'round_nine',
        'round_ten',
        'round_ninety_nine',
    );
    protected $_cost = array('protect_cost', 'protect_price', 'protect_current');
    protected $_round = array('round_no', 'round_tenth', 'round_hundredths', 'round_whole_number', 'round_five', 'round_nine', 'round_ten', 'round_ninety_nine');
    protected $_discount_types = array("", "-%", "+%", "-", "+", "*", "/", "√");

    public function clonez() {
        $this->load->model('total/hyper_discount/wholesale_discount');
        $this->model_total_hyper_discount_wholesale_discount->cloneWholesaleEditor($this->request->get['wholesale_discount_id'],$this->request->get['product_product_group_id']);
        $this->response->redirect($this->url->link('total/hyper_discount/prices/wholesale/edit_wholesale_discount', 'token=' . $this->session->data['token'] . '&wholesale_discount_id=' . $this->request->get['wholesale_discount_id'], 'SSL'));
    }

    public function index() {
        $this->load->language('total/hyper_discount/prices/wholesale/add_wholesale_discount');

        $this->session->data['editable_prods'] = FALSE;
        $this->session->data['editable_clients'] = FALSE;
        //
        $this->load->model('customer/customer_group');
        $data['customer_groups'] = $this->model_customer_customer_group->getCustomerGroups();

        $all_protected_arr = array(
            '_cost',
            '_round',
        );

        foreach ($all_protected_arr as $arr_name)
            foreach ($this->$arr_name as $key => $val) {
                $arr = &$this->$arr_name;
                $arr[$val] = $this->language->get($val);
                unset($arr[$key]);
            }
        //
        $this->document->addStyle('view/stylesheet/hyper_loyalty.css');
        $this->document->addStyle('view/javascript/bootstrap/css/bootstrap-switch.min.css');
        $this->document->addStyle('view/javascript/bootstrap/css/bootstrap-multiselect.css');
        $this->document->addScript('view/javascript/bootstrap/js/bootstrap-switch.min.js');
        $this->document->addScript('view/javascript/bootstrap/js/bootstrap-multiselect.js');

        $this->load->model('total/hyper_discount/wholesale_discount');

        //permission
        if ($this->request->server['REQUEST_METHOD'] == 'POST' && !$this->validateForm()) {
            $this->session->data['error'] = $this->error;
            $this->response->redirect($this->url->link('total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
        }
        //permission
        if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validateForm()) {
            $this->model_total_hyper_discount_wholesale_discount->editWholesaleDiscount($this->request->post['product_discount']);

            $this->response->redirect($this->url->link('total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-discount-wholesale', 'SSL'));
        } elseif (isset($this->request->get['wholesale_discount_id'])) {
            $discount_settings = $this->model_total_hyper_discount_wholesale_discount->getWholesaleDiscount($this->request->get['wholesale_discount_id']);
            $discount_editor = $this->model_total_hyper_discount_wholesale_discount->getWholesaleDiscountEditors($this->request->get['wholesale_discount_id']);


            foreach ($discount_editor as $discount_editor_k => $discount_editor_v) {
                $id = $discount_editor_v['id'];
                $editor_id = isset($discount_editor_v['editor_id']) ? $discount_editor_v['editor_id'] : 0;
                $save_param = $this->model_total_hyper_discount_wholesale_discount->getProductFilterUrl($this->request->get['wholesale_discount_id'], $editor_id);

                $discount_editor[$discount_editor_k]['product_group_href'] = $this->url->link('total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&wholesale_discount_id=' . $this->request->get['wholesale_discount_id'] . '&product_product_group_id=' . $editor_id, 'SSL');
                $discount_editor[$discount_editor_k]['editor_clone_href'] = $this->url->link('total/hyper_discount/prices/wholesale/edit_wholesale_discount/clonez', 'token=' . $this->session->data['token'] . '&wholesale_discount_id=' . $this->request->get['wholesale_discount_id'] . '&product_product_group_id=' . $editor_id, 'SSL');
                
                if ($save_param)
                    $discount_editor[$discount_editor_k]['product_group_href'] .= $save_param;

                $discount_editor[$discount_editor_k]['customer_groups'] = ($discount_editor[$discount_editor_k]['customer_groups']) ? json_decode($discount_editor[$discount_editor_k]['customer_groups'], true) : array();
            }


            $data['wholesale_discount'] = array(
                'discount_id' => $discount_settings['id'],
                'name' => ($discount_settings['name']) ? json_decode($discount_settings['name'], true) : null,
                'description' => ($discount_settings['description']) ? $discount_settings['description'] : null,
                'shops_all' => ($discount_settings['shops_all']) ? $discount_settings['shops_all'] : false,
                'discount_editor' => isset($discount_editor) ? $discount_editor : array(),
                'status' => isset($discount_settings['status']) ? $discount_settings['status'] : null,
            );
        }

        $this->document->setTitle($this->language->get('heading_title'));

        foreach ($this->_text_string as $text) {
            $data[$text] = $this->language->get($text);
        }

        $data['array_cost'] = $this->_cost;
        $data['array_discount_types'] = $this->_discount_types;
        $data['array_round'] = $this->_round;

        $data['action'] = $this->url->link('total/hyper_discount/prices/wholesale/edit_wholesale_discount', 'token=' . $this->session->data['token'], 'SSL');

        $data['update_stay'] = $this->url->link('total/hyper_discount/prices/wholesale/edit_wholesale_discount/update', 'token=' . $this->session->data['token'], 'SSL');

        $data['cancel'] = $this->url->link('total/hyper_discount', 'token=' . $this->session->data['token'] . '&tab=tab-discount-wholesale', 'SSL');

        $data['edit_client_group'] = $this->url->link('total/hyper_discount/discount/edit_client_group', 'token=' . $this->session->data['token'] . '&wholesale_discount_id=' . $this->request->get['wholesale_discount_id'], 'SSL');
        $data['edit_geo_list'] = $this->url->link('total/hyper_discount/discount/edit_geo_list', 'token=' . $this->session->data['token'] . '&wholesale_discount_id=' . $this->request->get['wholesale_discount_id'], 'SSL');
        $data['edit_shops_list'] = $this->url->link('total/hyper_discount/discount/edit_shops_list', 'token=' . $this->session->data['token'] . '&wholesale_discount_id=' . $this->request->get['wholesale_discount_id'], 'SSL');
        $data['edit_product_groups'] = $this->url->link('total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&wholesale_discount_id=' . $this->request->get['wholesale_discount_id'], 'SSL');
        $data['discount_editor_edit_product_groups'] = $this->url->link('total/hyper_discount/discount/edit_product_groups', 'token=' . $this->session->data['token'] . '&wholesale_discount_id=' . $this->request->get['wholesale_discount_id'], 'SSL');




        $this->load->model('localisation/language');

        $data['languages'] = $this->model_localisation_language->getLanguages();

        $data['lang'] = $this->language->get('lang');

        $data['config_language_id'] = $this->config->get('config_language_id');


        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('total/hyper_discount/prices/wholesale/wholesale_discount_form.tpl', $data));
    }

    public function update() {
        //permisson
        if ($this->request->server['REQUEST_METHOD'] == 'POST' && isset($this->request->post['product_discount']['discount_id']) && !$this->validateForm()) {
            $this->session->data['error'] = $this->error;
            $this->response->redirect($this->url->link('total/hyper_discount/error', 'token=' . $this->session->data['token'], 'SSL'));
        }
        //
        if ($this->request->server['REQUEST_METHOD'] == 'POST' && isset($this->request->post['product_discount']['discount_id']) && $this->validateForm()) {

            $this->load->model('total/hyper_discount/wholesale_discount');

            $this->model_total_hyper_discount_wholesale_discount->editWholesaleDiscount($this->request->post['product_discount']);

            $this->response->redirect($this->url->link('total/hyper_discount/prices/wholesale/edit_wholesale_discount', 'token=' . $this->session->data['token'] . '&wholesale_discount_id=' . $this->request->post['product_discount']['discount_id'], 'SSL'));
        }
    }

    protected function validateForm() {
        $this->language->load('total/hyper_discount');

        if (!$this->user->hasPermission('modify', 'total/hyper_discount'))
            $this->error['warning'] = $this->language->get('error_permission');

        return !$this->error;
    }

}
