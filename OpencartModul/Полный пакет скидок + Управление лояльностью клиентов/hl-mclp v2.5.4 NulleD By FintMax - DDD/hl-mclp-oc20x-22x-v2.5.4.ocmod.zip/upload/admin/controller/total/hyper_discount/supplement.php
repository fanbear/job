<?php
class ControllerTotalHyperDiscountSupplement extends Controller{

    public function index() {

    }

}