<?php
class ControllerTotalHyperDiscountSettings extends Controller{

    public function index() {

    }

}