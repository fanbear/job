<?php
class ControllerTotalHyperDiscountDiscountTabDiscountUsers extends Controller {

    private $_text_string = array(

        'tab_name_discount_users',
        // Column
        'column_name',
        'column_name_titles',
        'column_description',
        'column_description_titles',
        'column_edit',
        'column_edit_titles',
        'column_sort_order',
        'column_sort_order_titles',
        'column_status',
        'column_status_titles',
        'column_delete',
        'column_delete_titles',
        // Buttons
        'button_add',
        'button_edit',
        'button_delete',
        // Help
        'help_name',
        'help_name_title',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help Users
        'help_name_users',
        'help_discount_text',
        'help_first_users',
        'help_second_users',
        'help_third_users',
        'help_fourth_users',
        'help_fifth_users',
        'help_sixth_users',
        'help_seventh_users',
        'help_ninth_users',
        'help_eighth_users',
        'help_tenth_users',
        'help_eleventh_users',
        'help_twelfth_users',
        'help_thirteenth_users',
        'help_fourteenth_users',
        'help_fifteenth_users',
        'help_sixteenth_users',

    );

    public function index() {

        $this->load->language('total/hyper_discount/discount/tab_discount_users');

        foreach ($this->_text_string as $text) {
            $data[$text] = $this->language->get($text);
        }

        $this->load->model('total/hyper_discount/users_discount');

        $discounts_list = $this->model_total_hyper_discount_users_discount->getUsersDiscountsList();

        $data['users_discounts'] = array();

        foreach($discounts_list as $discount){
            $data['users_discounts'][] = array(
                'discount_id' => $discount['id'],
                'name' => ($discount['name']) ? json_decode($discount['name'], true)[$this->config->get('config_language_id')] : null,
                'description' => ($discount['description']) ? ($discount['description']) : null,
                'sort' => isset($discount['sort']) ? $discount['sort'] : null,
                'status' => isset($discount['status']) ? $discount['status'] : null,
                'delete'        => $this->url->link('total/hyper_discount/discount/users/delete_users_discount', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $discount['id'], 'SSL'),
                'edit'        => $this->url->link('total/hyper_discount/discount/users/edit_users_discount', 'token=' . $this->session->data['token'] . '&user_discount_id=' . $discount['id'], 'SSL'),

            );
        }

        $data['add_discount_users'] = $this->url->link('total/hyper_discount/discount/users/add_users_discount', 'token=' . $this->session->data['token'], 'SSL');

        return $this->load->view('total/hyper_discount/discount/tab_discount_users.tpl', $data);
    }


}