<?php

class ControllerTotalHyperDiscountSettingsTabSettingsInorders extends Controller
{

    private $_text_string = array(
        // Title
        'tab_name_settings_inorders',
        'button_edit',
        'button_delete',
        'button_add',
        // Column
        'column_name',
        'column_name_titles',
        'column_description',
        'column_description_titles',
        'column_edit',
        'column_edit_titles',
        'column_status',
        'column_status_titles',
        'column_delete',
        'column_delete_titles',
        // Help
        'help_text_inorders',
        'help_name',
        'help_name_inorders',
        'help_name_title',
        //'help_name_titles',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',

        'text_edit',
        'text_enabled',
        'text_disabled',
        'entry_estimator',
        'entry_status',
        'entry_sort_order',
        // Help Settings
        'help_name_settings_inorders',
        'help_first_settings_inorders',
        'help_second_settings_inorders',
        'help_third_settings_inorders',
        'help_fourth_settings_inorders',
        // Help Common
        'help_name_inorders',
        'help_description_inorders',
        'help_first_inorders',
        'help_second_inorders',
        'help_third_inorders',
        'help_fourth_inorders',
        'help_fifth_inorders',
        'help_sixth_inorders',
        'help_seventh_inorders',
        'help_eighth_inorders',
        'help_thirteenth_inorders',
        'help_fourteenth_inorders',
        'help_fifteenth_inorders',
        'help_sixteenth_inorders',
        'help_seventeenth_inorders',
        'help_eighteenth_inorders',
        'help_nineteenth_inorders',
        'help_twentieth_inorders',
    );

    public function index()
    {

        $this->load->language('total/hyper_discount/settings/tab_settings_inorders');
 $data['hyper_discount_status'] = $this->config->get('hyper_discount_status');
            $data['hyper_discount_sort_order'] = $this->config->get('hyper_discount_sort_order');
        
        foreach ($this->_text_string as $text)
        {
            $data[$text] = $this->language->get($text);
        }
        $data['tmp'] = 'tmp';


        return $this->load->view('total/hyper_discount/settings/tab_settings_inorders.tpl', $data);
    }

}
