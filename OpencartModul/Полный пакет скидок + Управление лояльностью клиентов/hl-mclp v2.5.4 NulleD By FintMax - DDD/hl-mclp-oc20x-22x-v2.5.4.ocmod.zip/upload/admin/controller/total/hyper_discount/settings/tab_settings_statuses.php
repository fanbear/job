<?php

class ControllerTotalHyperDiscountSettingsTabSettingsStatuses extends Controller
{

    private $_text_string = array(
        // Title
        'tab_name_settings_statuses',
        'button_edit',
        'button_delete',
        'button_add',
        // Column
        'column_name',
        'column_name_titles',
        'column_description',
        'column_description_titles',
        'column_edit',
        'column_edit_titles',
        'column_status',
        'column_status_titles',
        'column_delete',
        'column_delete_titles',
        // Help
        'help_name',
        'help_name_title',
        //'help_name_titles',
        'help_list',
        'help_text',
        'help_warning',
        'help_ok',
        'help_end',
        // Help Common
        'help_name_statuses',
        'help_description_statuses',
        'help_first_statuses',
        'help_second_statuses',
        'help_third_statuses',
        'help_fourth_statuses',
        'help_fifth_statuses',
        'help_sixth_statuses',
        'help_seventh_statuses',
        'help_eighth_statuses',
        'help_thirteenth_statuses',
        'help_fourteenth_statuses',
        'help_fifteenth_statuses',
        'help_sixteenth_statuses',
        'help_seventeenth_statuses',
        'help_eighteenth_statuses',
        'help_nineteenth_statuses',
        'help_twentieth_statuses',
    );

    public function index()
    {

        $this->load->language('total/hyper_discount/settings/tab_settings_statuses');

        foreach ($this->_text_string as $text)
        {
            $data[$text] = $this->language->get($text);
        }
        $data['tmp'] = 'tmp';
        $data['add_setting_statuses'] = $this->url->link('total/hyper_discount/settings/statuses/accamulation_status/add', 'token=' . $this->session->data['token'], 'SSL');
        ;
        $this->load->model('total/hyper_discount/accamulation_status');

        $accamulation_statuses_list = $this->model_total_hyper_discount_accamulation_status->getAccamulationStatussList();

        $data['settings_statuses'] = array();

        foreach ($accamulation_statuses_list as $status)
        {
            $data['settings_statuses'][] = array(
                'statuses_id' => $status['id'],
                'name' => ($status['name']) ? json_decode($status['name'], true)[$this->config->get('config_language_id')] : null,
                'description' => ($status['description']) ? json_decode($status['description'], true)[$this->config->get('config_language_id')] : null,
                'sort' => isset($status['sort']) ? $status['sort'] : null,
                'status' => isset($status['status']) ? $status['status'] : null,
                'delete' => $this->url->link('total/hyper_discount/settings/statuses/accamulation_status/delete', 'token=' . $this->session->data['token'] . '&accamulation_status_id=' . $status['id'], 'SSL'),
                'edit' => $this->url->link('total/hyper_discount/settings/statuses/accamulation_status/edit', 'token=' . $this->session->data['token'] . '&accamulation_status_id=' . $status['id'], 'SSL'),
            );
        }

        return $this->load->view('total/hyper_discount/settings/tab_settings_statuses.tpl', $data);
    }

}
