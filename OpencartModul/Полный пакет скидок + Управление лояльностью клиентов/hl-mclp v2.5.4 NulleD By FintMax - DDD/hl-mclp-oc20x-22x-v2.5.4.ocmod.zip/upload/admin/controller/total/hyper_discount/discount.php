<?php
class ControllerTotalHyperDiscountDiscount extends Controller{

    public function index() {

    }

}