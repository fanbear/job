<?php

class ModelTotalHyperDiscount extends Model {

     public function getTotal(&$total_data, &$total, &$taxes) {


        if (isset($this->session->data['hyper_discount']) && is_array($this->session->data['hyper_discount'])) {

            foreach($this->session->data['hyper_discount']  as $title=>$value) 
            {
                if($value==0)
                    continue;
                
                $total_data[] = array(
                    'code' => 'hyper_discount',
                    'title' => $title,
                    'value' => $value,
                    'sort_order' => $this->config->get('hyper_discount_sort_order')
                );

                $total -= $value;
            }
        }
    }

}
