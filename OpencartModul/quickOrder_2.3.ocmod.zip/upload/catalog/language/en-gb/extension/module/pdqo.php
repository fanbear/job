<?php
// Form
$_['quick_order']  = 'Quick Order';
$_['name']  = 'Name';
$_['phone']  = 'Telephone';
$_['email']  = 'E-Mail';
$_['comment']  = 'Comment';
$_['checkout']  = 'Checkout';
$_['continue_shopping']  = 'Continue shopping';

// Product Cart Table
$_['product_title']  = 'Title';
$_['product_qty']  = 'Qty';
$_['product_price']  = 'Price';
$_['product_cost']  = 'Cost';

// Cart Action
$_['remove']  = 'Remove';
$_['from_cart']  = 'from cart';

// Success Order
$_['order_num']  = 'Order №';
$_['successful_sended']  = 'successfully sent!';
$_['thanks_for_order']  = 'Thank you for your interest in our products. Your order is processed. In the near future you will be contacted our managers to clarify the terms of the order and delivery time.';
?>