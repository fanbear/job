<?php
$_['entry_title'] = 'Bundle Discount';