<?php 
class ModelModuleProductbundles extends Model {

  	public function install() {
		// Noting here for now
  	} 
  
  	public function uninstall() {
		// Nothing here for now
  	}
	
  }
?>