<?php
/*
 * Editing this file may result in loss of license which will be permanently blocked.
 * 
 * @license Commercial
 * @author info@ocdemo.eu
*/

class MegaFilterModule
{
    private $a4otBgCefxdl4a;
    private $a5ToNvlGgkXA5a = array();
    private static $a6VBmdcxOnOs6a = false;
    private function a0wpUpwQtTyI0a($F_GlA)
    {
        goto BY0uo;
        roWzJ:
        return $K5aWM;
        goto E93Op;
        KRClA:
        foreach ($F_GlA as $PASds => $RYAn_) {
            $K5aWM[$RYAn_["\x73\x65\157\137\156\141\x6d\x65"]] = $PASds;
            HEnzJ:
        }
        goto Bh0sG;
        BY0uo:
        $K5aWM = array();
        goto KRClA;
        Bh0sG:
        lqrX0:
        goto roWzJ;
        E93Op:
    }
    private function a1GIogCcvADI1a($eIZGv, $VgShc = false)
    {
        goto DZxoO;
        jlmew:
        kdw0K:
        goto Klg2f;
        DZxoO:
        if (!self::$a6VBmdcxOnOs6a) {
            goto Dg0G2;
        }
        goto QL5qv;
        R06y6:
        echo "\x3c\x64\151\x76\x20\x73\164\x79\x6c\x65\x3d\42\160\141\144\144\x69\x6e\147\x3a\40\61\60\x70\170\73\40\x74\145\x78\164\55\141\154\151\147\156\72\40\x63\x65\156\164\145\x72\42\76";
        goto rKEIx;
        ak4yS:
        echo "\74\x61\40\150\x72\x65\x66\x3d\x22\150\164\x74\x70\163\72\x2f\x2f\147\x69\x74\150\165\142\56\143\157\155\57\166\161\x6d\157\x64\57\166\x71\155\x6f\144\57\x77\x69\x6b\x69\57\111\x6e\163\x74\x61\154\x6c\151\156\x67\x2d\x76\x51\x6d\157\144\x2d\157\x6e\x2d\x4f\160\x65\x6e\x43\141\162\164\42\40\x74\x61\x72\x67\145\164\75\x22\x5f\142\154\141\156\x6b\x22\76\x48\x6f\167\x20\x74\157\40\x69\156\163\164\141\154\154\x6c\40\x56\121\115\157\x64\74\57\141\x3e";
        goto jlmew;
        rKEIx:
        echo $eIZGv;
        goto jiwSh;
        QL5qv:
        return;
        goto TOxrV;
        d6IK6:
        echo "\x50\x6c\145\x61\x73\145\40\x3c\141\x20\x68\x72\145\146\75\x22\150\164\x74\x70\x73\72\x2f\57\x67\151\164\150\165\142\x2e\143\x6f\155\57\x76\161\x6d\157\x64\x2f\x76\x71\155\x6f\x64\x2f\162\x65\x6c\x65\x61\x73\x65\x73\57\164\x61\147\57\166\62\x2e\66\56\x31\55\x6f\x70\145\156\x63\x61\x72\x74\x22\40\x74\x61\x72\x67\x65\164\75\42\137\142\154\141\156\153\42\x3e\x64\x6f\x77\x6e\154\x6f\x61\x64\40\126\x51\115\157\144\74\57\x61\x3e\x20\x61\156\x64\x20\162\145\x61\x64\x20";
        goto ak4yS;
        pUsyB:
        self::$a6VBmdcxOnOs6a = true;
        goto MprlT;
        QRf1j:
        echo "\74\142\x72\40\x2f\x3e\x3c\142\x72\x20\57\76";
        goto d6IK6;
        Klg2f:
        echo "\x3c\57\x64\x69\166\76";
        goto pUsyB;
        jiwSh:
        if (!$VgShc) {
            goto kdw0K;
        }
        goto QRf1j;
        TOxrV:
        Dg0G2:
        goto R06y6;
        MprlT:
    }
    private function a2UxPGIXaGSm2a($iJaxv)
    {
        goto INb72;
        INb72:
        $M40jJ = isset($_SERVER["\x48\124\124\120\123"]) && $_SERVER["\x48\124\124\120\123"] == "\157\x6e" ? "\x68\x74\164\x70\x73" : "\150\164\164\x70";
        goto MOYpO;
        MOYpO:
        $egpPg = isset($_SERVER["\110\124\x54\x50\137\x48\117\x53\124"]) ? $_SERVER["\x48\124\124\120\137\x48\x4f\x53\x54"] : $_SERVER["\123\x45\122\x56\105\x52\x5f\x4e\x41\115\x45"];
        goto b_gtP;
        EY2kz:
        return $M40jJ . "\x3a\x2f\57" . $egpPg . $Q0Ytt["\160\141\164\x68"] . (empty($Q0Ytt["\x71\x75\145\162\171"]) ? '' : "\77" . str_replace("\46\141\155\160\x3b", "\x26", $Q0Ytt["\x71\x75\145\x72\171"]));
        goto NAJCq;
        b_gtP:
        $Q0Ytt = parse_url($iJaxv);
        goto EY2kz;
        NAJCq:
    }
    public static function newInstance(&$FyvEY)
    {
        return new self($FyvEY);
    }
    private function a3kuDkiMdsPg3a($iJaxv, $UiW4N = null){}
    private function __construct(&$FyvEY){
        $this->a4otBgCefxdl4a = $FyvEY;
        $this->a5ToNvlGgkXA5a["lll"] = "mf";
    }
    public function __get($JrPID)
    {
        return $this->a4otBgCefxdl4a->{$JrPID};
    }
    public function render($X5TZU)
    {
        goto zmnAU;
        cPpxi:
        if (isset($X5TZU["\137\151\144\x78"])) {
            goto cBNTd;
        }
        goto uMOFO;
        jPWpf:
        LVdzg:
        goto cPpxi;
        Lytlx:
        l1ogv:
        goto cpELc;
        WbiV7:
        xQWZB:
        goto BympP;
        SHqws:
        C__hr:
        goto CMOBh;
        te9L6:
        $LBhmk = '';
        goto FmUBS;
        YBXuk:
        TvJK1:
        goto qlj1S;
        XySLv:
        $B3oTR["\141\x6a\141\170\x47\x65\164\111\156\146\157\x55\162\154"] = $this->a2UxPGIXaGSm2a($this->url->link("\x6d\157\x64\165\x6c\x65\x2f\155\145\x67\x61\137\x66\x69\x6c\x74\145\162\x2f\147\x65\164\141\x6a\x61\x78\x69\156\146\x6f", '', "\123\123\x4c"));
        goto qMkyR;
        G4YJu:
        oOPyl:
        goto vQHTM;
        hlB5v:
        VgqUd:
        goto vkinP;
        ZIiv4:
        $wOZ68 = false;
        goto rVVHj;
        nAkVf:
        if (!in_array($pTOoj, $wNqOi["\x68\151\144\145\x5f\x63\x61\164\x65\x67\157\x72\x79\137\151\x64"])) {
            goto adK8M;
        }
        goto cEpl1;
        l7yuX:
        $NPIXN = array();
        goto IkFHX;
        fOKV8:
        foreach ($giJfE as $IFyEk) {
            MijoShop::getClass("\x62\x61\163\145")->addHeader(JPATH_MIJOSHOP_OC . "\57\143\x61\164\141\x6c\157\x67\x2f\x76\x69\145\x77\57\152\141\x76\141\x73\143\x72\151\160\x74\57\155\x66\57" . str_replace("\56\x6a\x73\x3f\x76" . $B3oTR["\x5f\x76"], "\56\152\x73", $IFyEk), false);
            XfG1y:
        }
        goto pXzI2;
        s2Yvr:
        $B3oTR["\151\x73\137\x6d\x6f\142\151\154\x65"] = $To7pI;
        goto GrTQc;
        Luhox:
        if (!(version_compare(VERSION, "\x32\x2e\x32\56\60\x2e\60", "\x3e\x3d") && version_compare(VQMod::$_vqversion, "\62\x2e\66\x2e\61", "\74") && empty(VQMOD::$_virtualMFP))) {
            goto LVdzg;
        }
        goto mZTMv;
        VK7NV:
        array_unshift($giJfE, "\144\x69\162\145\143\164\x69\x6f\156\x5f" . $this->config->get("\143\157\156\x66\x69\147\x5f\x6c\x61\x6e\x67\x75\141\x67\x65\x5f\151\144") . "\x2e\x6a\163\77\x76" . $B3oTR["\137\166"]);
        goto AFJFK;
        tGR0Y:
        $B3oTR["\x72\145\161\x75\x65\163\x74\107\x65\x74"]["\155\x66\x70\x5f\x6f\x72\147\137\x70\141\164\x68\x5f\141\154\x69\141\163\145\x73"] = implode("\x5f", MegaFilterCore::pathToAliases($this, $B3oTR["\x72\x65\161\x75\x65\x73\x74\x47\145\164"]["\155\x66\160\x5f\x6f\x72\147\x5f\x70\x61\x74\150"]));
        goto KCXH4;
        OI6JG:
        if (!(in_array($XwBAr["\x6c\141\171\x6f\x75\x74\x5f\143"], $wNqOi["\154\141\x79\x6f\165\x74\137\151\144"]) && isset($this->request->get["\x70\x61\164\150"]))) {
            goto GBTK4;
        }
        goto leTMd;
        BympP:
        if (empty($wNqOi["\x63\165\163\164\x6f\x6d\145\162\x5f\x67\162\157\165\x70\x73"])) {
            goto TvJK1;
        }
        goto gOtIK;
        k7iGL:
        $B3oTR["\x66\x69\154\164\145\162\x73"] = $F_GlA;
        goto tV2PE;
        zWnYO:
        $LgD9U = defined("\112\x4f\117\x43\101\x52\x54\x5f\123\x49\124\105\x5f\125\x52\114") ? array("\x73\x69\164\145\x5f\x75\x72\154" => $this->a2UxPGIXaGSm2a(JOOCART_SITE_URL), "\155\x61\151\156\x5f\165\162\154" => $this->a2UxPGIXaGSm2a($this->url->link('', '', "\123\x53\114"))) : false;
        goto NNKA0;
        aCOia:
        return;
        goto OzFlF;
        uMOFO:
        $this->a1GIogCcvADI1a("\124\150\145\162\145\40\x69\x73\40\141\40\x63\x6f\x6e\x66\154\151\143\x74\x20\115\x65\147\141\40\x46\x69\x6c\164\x65\x72\x20\120\122\117\40\x77\151\164\x68\x20\x79\x6f\165\162\x20\x74\x65\155\x70\x6c\x61\164\145\x20\157\162\40\x6f\x74\150\x65\162\x20\x65\170\x74\x65\x6e\x73\x69\x6f\x6e\x20\55\40\74\x61\x20\150\162\x65\x66\x3d\x22\150\x74\164\160\x3a\57\x2f\x66\157\x72\x75\155\x2e\x6f\143\x64\x65\x6d\157\x2e\145\x75\57\42\x20\x74\x61\x72\x67\145\164\x3d\42\x5f\142\x6c\141\156\153\x22\x20\x73\x74\x79\x6c\x65\75\x22\164\145\170\x74\55\144\145\x63\x6f\162\141\164\x69\157\156\72\165\156\x64\x65\162\154\151\156\145\x22\x3e\160\154\x65\141\163\145\40\x66\x69\x6e\x64\40\x61\x20\x73\157\x6c\x75\x74\151\x6f\x6e\40\157\x6e\x20\x6f\x75\x72\40\146\157\162\165\x6d\x3c\57\141\x3e\x2e");
        goto yeoTS;
        C6YZx:
        return;
        goto iy2nB;
        QMeYs:
        if (!(in_array($ZlMfi, array("\160\x72\157\144\x75\x63\x74\x2f\163\x65\x61\x72\x63\150")) && empty($this->request->get["\163\x65\141\162\x63\x68"]) && empty($this->request->get["\x74\x61\147"]))) {
            goto qksv_;
        }
        goto dUpzb;
        SWprM:
        WGkPe:
        goto NNEw5;
        Cc2bz:
        $To7pI = Mobile_Detect_MFP::create()->isMobile();
        goto BkZFx;
        cAyoH:
        $c5QZ_ = $this->config->get("\155\146\x69\x6c\x74\x65\x72\x5f\154\x65\x76\x65\x6c\137\166\x65\x72\x73\x69\157\x6e") && $this->config->get("\155\146\x69\x6c\164\145\162\137\154\x65\166\x65\x6c\137\154\151\x63\145\156\163\145");
        goto b1lwU;
        cEpl1:
        return;
        goto mf35E;
        qjbmf:
        $B3oTR["\150\x69\144\145\137\143\157\156\164\141\151\156\145\162"] = true;
        goto RgySF;
        fYYVd:
        if (!empty($wNqOi["\150\151\x64\145\x5f\143\x61\164\x65\147\157\x72\171\x5f\x69\144\137\167\151\x74\150\x5f\x63\150\x69\154\x64\x73"])) {
            goto RXCeC;
        }
        goto rdUfs;
        BkZFx:
        if (!($wNqOi["\x73\x74\x61\x74\165\163"] == "\x70\x63" && $To7pI)) {
            goto HYeDA;
        }
        goto ku1Wx;
        Fh1MO:
        Pu01I:
        goto PYi0a;
        xZLX2:
        CxWLD:
        goto y98Ar;
        P3Svz:
        if (file_exists(DIR_TEMPLATE . $this->config->get("\143\157\156\146\151\x67\137\x74\x65\x6d\160\154\141\x74\145") . "\x2f\163\x74\x79\x6c\145\163\x68\x65\145\164\57\155\x66\57\163\164\171\154\145\56\x63\163\163")) {
            goto PG0PK;
        }
        goto B6d3E;
        kWTNH:
        $this->load->model("\x6d\x6f\x64\165\154\145\x2f\155\x65\x67\141\x5f\146\151\x6c\x74\145\162");
        goto sWK58;
        arRjU:
        return;
        goto SHqws;
        X4eST:
        $this->document->addScript($this->a2UxPGIXaGSm2a($this->url->link("\155\x6f\x64\x75\x6c\145\57\155\145\147\x61\137\146\151\154\164\145\162\x2f\152\x73\x5f\144\151\162\145\x63\x74\151\x6f\156", '', "\123\x53\114")));
        goto xcVc0;
        tV2PE:
        $B3oTR["\163\x65\x74\164\x69\x6e\147\x73"] = $XwBAr;
        goto Xmc_N;
        zX9PL:
        if (in_array($H0o2h, $wNqOi["\143\x75\163\x74\x6f\155\145\x72\x5f\147\x72\157\x75\160\163"])) {
            goto otHm8;
        }
        goto C7CZF;
        auqr0:
        cNHks:
        goto LshYQ;
        awyqA:
        $VCuQF = false;
        goto hs9VX;
        H2UtL:
        $this->a1GIogCcvADI1a("\115\x65\147\x61\x20\106\151\154\164\145\x72\40\x50\122\117\40\x74\x6f\40\x77\157\162\153\40\160\162\x6f\x70\145\162\154\171\x20\x72\x65\x71\x75\151\x72\145\163\x20\141\156\x20\x69\x6e\163\x74\x61\154\154\145\x64\x20\x56\x51\x4d\x6f\144\56", true);
        goto VB5vm;
        pdF9T:
        require_once VQMod::modCheck(modification(DIR_SYSTEM . "\x6c\x69\x62\162\x61\x72\x79\57\155\146\151\154\164\145\162\137\155\x6f\142\151\x6c\145\56\x70\x68\x70"));
        goto TdGLM;
        OYSWC:
        if (!(in_array($ZlMfi, array("\x70\x72\157\x64\165\143\x74\x2f\x6d\141\156\165\146\141\143\164\x75\x72\145\x72", "\160\162\x6f\x64\x75\x63\164\x2f\x6d\141\x6e\165\x66\x61\x63\x74\x75\162\145\x72\57\151\x6e\146\x6f")) && isset($K5aWM["\155\141\156\x75\x66\x61\x63\x74\x75\x72\145\162\163"]))) {
            goto KV0Tu;
        }
        goto b2B4C;
        VOVau:
        $WXoCX = array("\x63\x61\164\x61\x6c\x6f\147\x2f\166\x69\145\x77\57\164\150\145\x6d\x65\x2f\x64\145\x66\x61\165\154\x74\57\x73\164\x79\x6c\x65\163\150\x65\x65\164\x2f\155\146\57\152\161\165\x65\162\x79\55\x75\x69\x2e\155\151\x6e\56\143\163\x73\x3f\x76" . $B3oTR["\x5f\166"], file_exists(DIR_TEMPLATE . $this->config->get("\143\x6f\156\x66\x69\x67\x5f\164\145\155\x70\154\141\164\x65") . "\57\163\x74\171\x6c\145\x73\x68\x65\x65\x74\x2f\x6d\146\57\x73\164\171\x6c\x65\56\143\x73\x73") ? "\x63\x61\164\x61\x6c\x6f\147\x2f\166\151\x65\167\57\164\150\145\155\x65\x2f" . $this->config->get("\143\x6f\x6e\x66\151\147\x5f\x74\145\x6d\160\154\x61\x74\145") . "\57\163\164\171\x6c\145\163\x68\145\145\164\57\x6d\146\57\163\164\x79\154\145\x2e\x63\163\163\x3f\x76" . $B3oTR["\x5f\166"] : "\x63\x61\164\x61\x6c\x6f\x67\x2f\166\151\x65\x77\57\x74\x68\x65\155\145\x2f\x64\x65\146\141\x75\x6c\164\57\x73\x74\x79\154\x65\163\x68\x65\145\164\57\155\x66\x2f\x73\164\171\x6c\145\56\x63\163\163\77\166" . $B3oTR["\137\x76"], "\x63\x61\164\x61\x6c\157\x67\x2f\x76\x69\x65\167\57\164\150\x65\x6d\x65\x2f\144\x65\146\x61\165\154\x74\57\x73\x74\171\154\145\x73\150\x65\x65\164\x2f\x6d\x66\x2f\x73\164\171\x6c\x65\x2d\x32\56\x63\163\x73\x3f\x76" . $B3oTR["\x5f\166"]);
        goto w5_tB;
        LiEtI:
        $rMokp = DIR_SYSTEM . "\x2e\x2e\57\x63\141\x74\141\154\157\x67\x2f\166\x69\x65\x77\x2f\152\x61\x76\141\x73\143\x72\x69\160\164\x2f\x6d\x66\57\144\151\162\x65\143\x74\x69\157\x6e\x5f" . $this->config->get("\x63\157\156\146\151\147\137\x6c\x61\156\x67\x75\x61\x67\x65\137\151\144") . "\x2e\152\163";
        goto QAJT1;
        hs9VX:
        foreach ($fSY28 as $pTOoj) {
            goto s4gmm;
            BaTpj:
            goto nMGzK;
            goto zjk2Y;
            Sb9Gr:
            $VCuQF = true;
            goto BaTpj;
            s4gmm:
            if (!in_array($pTOoj, $wNqOi["\x63\x61\164\145\x67\x6f\162\x79\x5f\x69\144"])) {
                goto M4tTS;
            }
            goto Sb9Gr;
            yNPeR:
            AUGdw:
            goto zySBE;
            zjk2Y:
            M4tTS:
            goto yNPeR;
            zySBE:
        }
        goto u_1wx;
        Grdk2:
        $B3oTR["\x5f\x72\x6f\x75\164\x65"] = base64_encode($jLZAU->route());
        goto aOC4X;
        cojjQ:
        $jLZAU->_setCache($Pumds, $F_GlA);
        goto Fh1MO;
        aacwp:
        $B3oTR["\x5f\150\x6f\162\151\x7a\x6f\x6e\164\x61\154\111\x6e\x6c\x69\x6e\x65"] = $X5TZU["\x70\157\x73\x69\x74\151\x6f\156"] == "\x63\157\x6e\x74\x65\x6e\164\137\x74\157\x70" && !empty($wNqOi["\151\x6e\x6c\151\156\x65\137\x68\x6f\x72\x69\172\x6f\x6e\x74\141\154"]) ? true : false;
        goto gxGH7;
        v1bpW:
        return;
        goto Pl7_G;
        yeoTS:
        return;
        goto daL8r;
        YFcco:
        $B3oTR["\162\145\x71\165\x65\163\164\107\145\x74"]["\x70\x61\164\150\137\x61\x6c\x69\141\163\x65\x73"] = implode("\x5f", MegaFilterCore::pathToAliases($this, $B3oTR["\x72\145\x71\x75\x65\163\x74\x47\145\164"]["\160\x61\x74\x68"]));
        goto UOVT6;
        lWlwX:
        if (file_exists(DIR_SYSTEM . "\56\56\57\143\141\x74\141\154\x6f\147\57\166\x69\x65\167\x2f\x74\x68\145\x6d\145\x2f\x64\x65\146\x61\x75\154\164\57\x73\164\171\x6c\x65\163\150\x65\x65\x74\x2f\x6d\146\57\x63\x6f\x6d\x62\151\x6e\145\x64\56\143\x73\163")) {
            goto oXHrZ;
        }
        goto kaIOO;
        Ww3y8:
        iKGhE:
        goto SEnhs;
        hENka:
        if (!empty($X5TZU["\x62\141\163\x65\137\141\164\x74\162\x69\x62\163"])) {
            goto U_BFH;
        }
        goto w5_WS;
        ZJ_sc:
        MijoShop::get()->addHeader(JPATH_MIJOSHOP_OC . "\x2f\x63\141\164\x61\154\x6f\x67\57\x76\x69\x65\167\x2f\164\x68\145\x6d\x65\x2f" . $this->config->get("\x63\157\156\146\151\147\x5f\164\x65\x6d\x70\x6c\x61\x74\x65") . "\57\x73\x74\x79\x6c\145\163\150\145\145\164\57\155\146\57\x73\x74\x79\x6c\x65\56\x63\163\163");
        goto Hyg5w;
        xCPV7:
        xqQkp:
        goto OwC1A;
        dv0sY:
        return;
        goto CKceZ;
        maXtC:
        if (!empty($X5TZU["\x61\164\164\162\x69\142\x73"])) {
            goto gJgau;
        }
        goto KPKDt;
        r2Q8j:
        epYTB:
        goto YO4f5;
        KtU03:
        return;
        goto sxKr_;
        Tegcf:
        if (in_array($this->config->get("\x63\x6f\x6e\x66\x69\x67\x5f\163\164\157\x72\x65\137\151\x64"), $wNqOi["\163\164\x6f\x72\145\x5f\151\x64"])) {
            goto gfmus;
        }
        goto v1bpW;
        OzFlF:
        p2aCh:
        goto JgzqS;
        leTMd:
        if (empty($wNqOi["\143\x61\x74\145\147\157\162\x79\137\x69\144"])) {
            goto Y41xO;
        }
        goto WkZ3S;
        yW3sR:
        $this->a1GIogCcvADI1a("\x4d\145\147\141\x20\106\151\x6c\x74\x65\162\40\120\122\x4f\x20\164\x6f\40\x77\x6f\x72\153\x20\x70\162\157\160\x65\x72\x6c\x79\40\162\x65\161\x75\151\162\145\163\x20\126\121\x4d\x6f\144\x20\x69\156\40\166\x65\162\163\x69\157\x6e\40\x32\x2e\65\x2e\x31\40\157\x72\x20\x6c\141\164\145\x72\56\74\x62\162\x20\x2f\x3e\131\157\x75\162\40\x76\x65\162\x73\x69\x6f\156\x20\x6f\146\x20\126\121\115\157\144\x20\151\163\40\164\x6f\157\x20\157\x6c\x64\56\40\120\x6c\145\141\163\145\40\165\x70\x67\x72\x61\144\x65\x20\x69\x74\40\x74\157\x20\164\x68\x65\40\154\x61\164\x65\163\164\40\x76\x65\x72\163\x69\x6f\156\56", true);
        goto vuO12;
        NNEw5:
        foreach ($WXoCX as $IFyEk) {
            goto fHcbE;
            XrotA:
            $this->document->addStyle($IFyEk);
            goto d38y8;
            d38y8:
            FWJ98:
            goto zuMSK;
            R8V7p:
            y1jLR:
            goto XrotA;
            ogvKB:
            $IFyEk = str_replace("\56\143\163\x73\77\x76" . $B3oTR["\137\166"], "\56\143\163\163", $IFyEk);
            goto R8V7p;
            fHcbE:
            if (empty($XwBAr["\155\x69\156\x69\146\x79\137\163\x75\160\x70\157\162\164"])) {
                goto y1jLR;
            }
            goto ogvKB;
            zuMSK:
        }
        goto xLZOb;
        r2jbp:
        if (in_array($pTOoj, $wNqOi["\143\141\164\x65\x67\x6f\x72\171\137\x69\x64"])) {
            goto bsDe7;
        }
        goto c8lTz;
        rVVHj:
        foreach ($F_GlA as $YOZKe => $x3s43) {
            goto fNFLS;
            fNFLS:
            if (!($x3s43["\142\141\x73\145\x5f\x74\171\160\x65"] == "\x70\x72\151\x63\145")) {
                goto OhEKs;
            }
            goto j0NhQ;
            nX6Pl:
            zOcoM:
            goto FdcqT;
            NeogN:
            OhEKs:
            goto nX6Pl;
            j0NhQ:
            $wOZ68 = true;
            goto OHccb;
            OHccb:
            goto Aqps7;
            goto NeogN;
            FdcqT:
        }
        goto lJQkv;
        msnKB:
        if (!isset($B3oTR["\x72\145\161\165\145\x73\164\x47\x65\164"]["\155\x66\x70\137\x6f\x72\x67\x5f\x70\141\164\x68"])) {
            goto n9its;
        }
        goto tGR0Y;
        Wgrlp:
        if (file_exists(DIR_TEMPLATE . $this->config->get("\x63\157\156\x66\x69\x67\x5f\x74\x65\x6d\x70\x6c\141\164\145") . "\57\164\x65\155\160\x6c\x61\164\145\x2f\155\157\144\165\154\x65\57\155\x65\x67\x61\x5f\x66\x69\154\x74\145\x72\x2e\164\x70\154")) {
            goto l1ogv;
        }
        goto kOhRt;
        KcoMB:
        if (!(isset($wNqOi["\x73\x74\x6f\x72\145\x5f\151\144"]) && is_array($wNqOi["\x73\x74\157\162\x65\x5f\151\144"]) && !in_array($this->config->get("\x63\x6f\x6e\146\x69\x67\x5f\x73\x74\157\162\145\137\151\x64"), $wNqOi["\163\164\157\162\x65\137\x69\x64"]))) {
            goto xQWZB;
        }
        goto wXvSJ;
        LFWNL:
        $B3oTR["\x5f\166"] = $this->config->get("\x6d\146\x69\x6c\x74\x65\162\x5f\x76\145\162\x73\x69\157\156") ? $this->config->get("\x6d\146\151\x6c\x74\x65\x72\137\x76\x65\x72\163\151\157\156") : "\61";
        goto QwQ9d;
        MQLzy:
        if (!empty($wNqOi["\143\x61\x74\x65\147\157\162\x79\x5f\x69\144\x5f\x77\x69\x74\150\x5f\143\150\151\154\144\x73"])) {
            goto Mra12;
        }
        goto qvoqW;
        u_1wx:
        nMGzK:
        goto O_3LE;
        yqsJy:
        if (empty($B3oTR["\144\151\163\x70\x6c\x61\x79\x41\x6c\x77\141\x79\x73\x41\163\127\x69\x64\147\145\164"])) {
            goto VgqUd;
        }
        goto KrLzU;
        OwC1A:
        if (class_exists("\126\121\115\157\144")) {
            goto NYlf5;
        }
        goto H2UtL;
        cvZKk:
        goto oOPyl;
        goto gVB9M;
        biYwA:
        oXHrZ:
        goto zVGhy;
        rKsrH:
        $B3oTR["\x73\x65\x6f\x5f\141\x6c\151\x61\x73"] = empty($this->request->get["\155\146\x70\x5f\163\x65\x6f\137\x61\154\151\141\x73"]) ? '' : $this->request->get["\x6d\146\160\x5f\x73\x65\x6f\137\141\154\151\141\x73"];
        goto LFWNL;
        keiLD:
        foreach ($zA6Aa as $YOZKe => $x3s43) {
            goto IOp1R;
            IOp1R:
            if (!isset($this->request->get[$YOZKe])) {
                goto y0UnD;
            }
            goto UP3UQ;
            SdU6G:
            $this->request->get[$YOZKe . "\x5f\164\x65\x6d\x70"] = $zA6Aa[$YOZKe];
            goto fxGQF;
            fxGQF:
            unset($this->request->get[$YOZKe]);
            goto fm3z3;
            fm3z3:
            y0UnD:
            goto yTb9_;
            UP3UQ:
            $zA6Aa[$YOZKe] = $this->request->get[$YOZKe];
            goto SdU6G;
            yTb9_:
            xaGot:
            goto Ivr4I;
            Ivr4I:
        }
        goto r2Q8j;
        zVGhy:
        $WXoCX = array("\x63\141\164\x61\154\157\x67\57\166\151\x65\167\x2f\164\x68\x65\155\x65\57\144\145\146\141\165\x6c\164\x2f\x73\x74\171\x6c\x65\163\x68\x65\145\164\57\155\146\57\143\157\x6d\x62\x69\x6e\x65\144\x2e\143\x73\163\77\166" . $B3oTR["\137\166"]);
        goto n40Or;
        N6iNA:
        $Pumds = null;
        goto nbkQ_;
        bmW6e:
        $B3oTR["\x5f\160\x6f\x73\151\x74\151\x6f\x6e"] = $X5TZU["\160\157\163\x69\x74\x69\157\x6e"];
        goto QQBVV;
        tlUXC:
        if (!empty($X5TZU["\x63\x61\x74\x65\x67\x6f\162\x69\x65\x73"])) {
            goto bJfnB;
        }
        goto WCzlj;
        Sa19X:
        file_put_contents(DIR_SYSTEM . "\56\x2e\57\143\141\x74\x61\x6c\157\x67\57\166\151\x65\x77\57\152\141\x76\141\163\143\x72\x69\160\x74\57\x6d\146\x2f\143\157\155\142\x69\156\145\x64\x2e\x6a\x73", $LBhmk);
        goto auqr0;
        wWPgs:
        qksv_:
        goto ZIiv4;
        w5_WS:
        $X5TZU["\142\x61\x73\145\x5f\141\x74\x74\162\151\x62\x73"] = empty($wNqOi["\x62\141\x73\145\x5f\141\164\164\x72\x69\142\163"]) ? array() : $wNqOi["\x62\x61\x73\145\x5f\141\164\164\162\151\142\x73"];
        goto Rtcm_;
        c8lTz:
        return false;
        goto oZWKV;
        pcJ6V:
        P4JZC:
        goto msnKB;
        NNKA0:
        if (!($X5TZU["\160\157\x73\x69\x74\151\157\156"] == "\x63\157\x6e\164\145\x6e\164\137\164\x6f\160" && !empty($XwBAr["\143\150\x61\156\147\x65\137\164\x6f\160\137\x74\x6f\137\143\157\154\165\x6d\156\137\157\156\x5f\x6d\157\142\151\154\145"]) && $To7pI)) {
            goto DCS_S;
        }
        goto p_zdW;
        cQENk:
        $sWVql = $this->config->get("\155\146\151\154\164\x65\x72\x5f\166\x65\150\x69\x63\154\x65\x5f\166\x65\x72\163\x69\157\x6e") && $this->config->get("\x6d\146\151\x6c\164\x65\162\137\x76\x65\x68\151\143\154\145\137\154\x69\143\145\156\x73\x65");
        goto JVnwP;
        ZPTTG:
        if (empty($XwBAr["\143\141\143\150\145\137\x65\156\141\142\154\x65\x64"])) {
            goto Pu01I;
        }
        goto cojjQ;
        WAgi3:
        $B3oTR["\167\151\x64\147\x65\x74\127\151\164\x68\x53\167\151\x70\x65"] = !isset($wNqOi["\x77\151\x64\x67\x65\164\137\x77\151\x74\150\x5f\163\167\x69\x70\x65"]) || !empty($wNqOi["\x77\x69\x64\147\x65\164\137\167\151\x74\150\x5f\x73\167\x69\x70\145"]) ? true : false;
        goto tm2wS;
        THiLG:
        meGhT:
        goto Sa19X;
        B1BGr:
        Z5KJ0:
        goto Wgrlp;
        xLZOb:
        SJPlX:
        goto EWB7u;
        Bwckv:
        if (!($wNqOi["\163\164\x61\164\165\x73"] == "\155\x6f\x62\151\x6c\x65" && !$To7pI)) {
            goto JuUSK;
        }
        goto KtU03;
        MmoKO:
        $X5TZU["\x66\151\x6c\164\145\162\x73"] = empty($wNqOi["\146\x69\154\164\145\x72\163"]) ? array() : $wNqOi["\146\x69\x6c\164\x65\162\163"];
        goto Ywt4b;
        BrMg2:
        goto GJJhE;
        goto Lytlx;
        GrTQc:
        $B3oTR["\x6d\151\152\157\x5f\x73\x68\x6f\x70"] = $E7bwD;
        goto fkYbh;
        LTdEE:
        HYeDA:
        goto Bwckv;
        wkorl:
        Mra12:
        goto awyqA;
        ku1Wx:
        return;
        goto LTdEE;
        qlj1S:
        $B3oTR = $this->language->load("\x6d\x6f\144\x75\x6c\x65\57\155\145\147\141\137\x66\151\154\x74\145\162");
        goto Q29JH;
        Zv32z:
        $B3oTR["\x68\x65\141\144\x69\x6e\x67\x5f\x74\x69\x74\154\x65"] = $wNqOi["\x74\x69\x74\154\145"][$this->config->get("\x63\x6f\156\146\x69\x67\x5f\154\141\156\147\x75\x61\x67\145\x5f\x69\144")];
        goto DwMtv;
        b1lwU:
        if (!($c5QZ_ && empty($X5TZU["\x6c\x65\x76\x65\x6c\x73"]))) {
            goto CfZlI;
        }
        goto qHlfC;
        qMkyR:
        $B3oTR["\141\x6a\x61\170\x52\145\163\165\x6c\164\x73\125\x72\154"] = $this->a2UxPGIXaGSm2a($this->url->link("\x6d\157\x64\165\154\x65\57\x6d\x65\147\x61\137\x66\151\x6c\164\x65\162\x2f\x72\x65\x73\x75\x6c\x74\163", '', "\123\123\x4c"));
        goto xBfoX;
        lypee:
        if (!version_compare(VQMod::$_vqversion, "\x32\x2e\x35\56\x31", "\74")) {
            goto PHgJ6;
        }
        goto yW3sR;
        FtX6A:
        $B3oTR["\137\x64\141\x74\141"] = $jLZAU->getData();
        goto YotDv;
        rdUfs:
        $pTOoj = array_pop($fSY28);
        goto nAkVf;
        mAbcS:
        if (empty($wNqOi["\x63\157\x6e\146\151\147\165\x72\141\164\x69\x6f\156"])) {
            goto UGyxf;
        }
        goto h4oxE;
        cc_PT:
        G1Tof:
        goto Ww3y8;
        CKceZ:
        a8UCt:
        goto aTjiq;
        FFOev:
        goto RgpH2;
        goto FUqrL;
        gqjZN:
        MijoShop::get()->addHeader(JPATH_MIJOSHOP_OC . "\57\x63\141\x74\141\x6c\157\147\x2f\166\x69\145\x77\57\164\150\145\155\145\x2f\144\x65\146\x61\x75\x6c\164\x2f\x73\164\x79\154\x65\163\x68\x65\145\164\57\155\x66\x2f\x73\x74\x79\x6c\145\55\62\x2e\x63\163\x73");
        goto B1BGr;
        QwQ9d:
        $B3oTR["\144\x69\163\160\x6c\x61\x79\x41\154\167\141\x79\163\101\163\127\151\144\x67\x65\164"] = empty($wNqOi["\x64\x69\x73\160\154\x61\171\x5f\141\154\167\141\171\163\x5f\x61\x73\137\x77\151\144\x67\x65\x74"]) ? false : true;
        goto ox3MX;
        Ywt4b:
        w43ZZ:
        goto tlUXC;
        SEnhs:
        if ($F_GlA) {
            goto C__hr;
        }
        goto arRjU;
        CMOBh:
        foreach ($zA6Aa as $YOZKe => $x3s43) {
            goto Fd7AA;
            mIr0x:
            YuWjw:
            goto IJalt;
            A6tzs:
            if (!isset($this->request->get[$YOZKe . "\137\164\x65\155\x70"])) {
                goto YuWjw;
            }
            goto D_f3n;
            IJalt:
            fR_nw:
            goto kUGQ5;
            D_f3n:
            unset($this->request->get[$YOZKe . "\x5f\x74\x65\155\x70"]);
            goto mIr0x;
            JL8gL:
            B8Quk:
            goto A6tzs;
            eaLSV:
            $this->request->get[$YOZKe] = $x3s43;
            goto JL8gL;
            Fd7AA:
            if (!($x3s43 !== null)) {
                goto B8Quk;
            }
            goto eaLSV;
            kUGQ5:
        }
        goto oswof;
        d6mAG:
        if (!(!$Pumds || NULL == ($F_GlA = $jLZAU->_getCache($Pumds)))) {
            goto BmoSq;
        }
        goto O7tcg;
        hcTjM:
        if (is_writable(DIR_SYSTEM . "\56\x2e\x2f\143\141\164\141\x6c\x6f\x67\x2f\166\x69\x65\x77\x2f\152\x61\x76\141\163\143\162\x69\160\164\x2f\155\146")) {
            goto Dv7po;
        }
        goto X4eST;
        vuO12:
        return;
        goto vhUX6;
        llKe4:
        $E7bwD = class_exists("\115\151\152\x6f\123\150\157\160") ? true : false;
        goto zWnYO;
        VKxVb:
        $ZlMfi = isset($this->request->get["\x72\x6f\x75\164\145"]) ? $this->request->get["\162\x6f\165\164\x65"] : NULL;
        goto OYSWC;
        iy2nB:
        goto U0g4E;
        goto xZLX2;
        QAJT1:
        if (file_exists($rMokp)) {
            goto aaTIf;
        }
        goto hcTjM;
        Hk6TO:
        GBTK4:
        goto qB55P;
        TFKqU:
        PG0PK:
        goto ZJ_sc;
        dsaos:
        $jLZAU->parseParams();
        goto llKe4;
        xBfoX:
        $B3oTR["\x61\152\x61\x78\107\145\164\x43\141\164\x65\x67\x6f\162\171\x55\162\x6c"] = $this->a2UxPGIXaGSm2a($this->url->link("\155\157\x64\x75\154\145\57\155\x65\x67\141\137\146\x69\154\164\145\x72\x2f\x67\145\x74\x63\141\x74\145\x67\x6f\x72\151\145\163", '', "\x53\123\114"));
        goto s2Yvr;
        vhUX6:
        PHgJ6:
        goto Luhox;
        p_zdW:
        $X5TZU["\x70\x6f\163\151\x74\151\x6f\x6e"] = "\143\x6f\154\x75\x6d\x6e\x5f\154\145\146\x74";
        goto qjbmf;
        MRgmt:
        Udaoq:
        goto rjtbs;
        mf35E:
        adK8M:
        goto cvZKk;
        SkcdY:
        GJJhE:
        goto EQZix;
        RZha0:
        DHTiD:
        goto zH9Tc;
        E0u5_:
        goto iKGhE;
        goto eVEZS;
        PYi0a:
        BmoSq:
        goto HMCv3;
        Ob2xC:
        x0VEH:
        goto nqDXm;
        IkFHX:
        foreach ($F_GlA as $YOZKe => $x3s43) {
            goto xAvhs;
            xAvhs:
            if (!($x3s43["\142\141\163\145\x5f\x74\171\x70\145"] != "\x70\x72\x69\x63\x65")) {
                goto AS9sS;
            }
            goto AVzxV;
            vCq38:
            AS9sS:
            goto bstbp;
            bstbp:
            dNbco:
            goto lmujT;
            AVzxV:
            $NPIXN[] = $x3s43;
            goto vCq38;
            lmujT:
        }
        goto rafSn;
        xcVc0:
        goto xpUH1;
        goto KaUEI;
        Pl7_G:
        gfmus:
        goto hENka;
        cpELc:
        return $this->load->view((version_compare(VERSION, "\62\56\x32\x2e\x30\56\60", "\76\x3d") ? '' : $this->config->get("\143\x6f\x6e\x66\x69\x67\x5f\x74\145\x6d\160\x6c\x61\x74\145") . "\57\x74\x65\155\160\154\x61\164\145\57") . "\x6d\x6f\144\165\154\x65\57\x6d\145\147\141\x5f\x66\x69\x6c\164\145\162\x2e\164\x70\154", $B3oTR);
        goto SkcdY;
        nWJS0:
        file_put_contents(DIR_SYSTEM . "\x2e\56\57\x63\x61\164\x61\x6c\157\x67\x2f\x76\x69\145\x77\57\164\x68\145\155\x65\x2f\x64\x65\146\141\x75\x6c\x74\x2f\x73\164\x79\x6c\145\163\150\145\x65\x74\x2f\155\146\x2f\143\x6f\x6d\142\151\x6e\145\144\56\x63\163\163", $PZDYD);
        goto biYwA;
        w5_tB:
        if ($E7bwD) {
            goto usAEd;
        }
        goto LiEtI;
        kOhRt:
        return $this->load->view((version_compare(VERSION, "\x32\x2e\x32\x2e\60\56\x30", "\76\x3d") ? '' : "\x64\145\x66\141\165\154\x74\x2f\x74\x65\155\x70\154\141\164\145\x2f") . "\x6d\x6f\x64\165\x6c\x65\57\x6d\145\147\141\137\146\151\154\164\145\162\x2e\x74\160\154", $B3oTR);
        goto BrMg2;
        k0H37:
        array_unshift($giJfE, "\x64\x69\x72\145\x63\164\151\157\156\137" . $this->config->get("\x63\x6f\156\x66\151\x67\137\x6c\x61\156\147\x75\141\x67\x65\x5f\151\x64") . "\56\152\x73\77\x76" . $B3oTR["\x5f\166"]);
        goto iTVlR;
        TdGLM:
        RgpH2:
        goto Cc2bz;
        O7tcg:
        $F_GlA = $this->model_module_mega_filter->getAttributes($jLZAU, $X5TZU["\x5f\x69\x64\170"], $X5TZU["\142\141\x73\145\137\x61\x74\164\x72\151\x62\x73"], $X5TZU["\141\x74\x74\162\151\x62\163"], $X5TZU["\157\160\x74\151\x6f\156\163"], $X5TZU["\x66\x69\x6c\x74\x65\x72\x73"], empty($X5TZU["\x63\141\164\x65\147\x6f\x72\x69\x65\163"]) ? array() : $X5TZU["\x63\x61\x74\x65\x67\x6f\x72\x69\145\x73"], empty($X5TZU["\166\x65\x68\x69\x63\x6c\145\163"]) ? array() : $X5TZU["\166\x65\x68\x69\x63\x6c\145\163"], empty($X5TZU["\x6c\145\x76\x65\x6c\x73"]) ? array() : $X5TZU["\x6c\x65\166\145\x6c\163"]);
        goto ZPTTG;
        VmDMz:
        U0g4E:
        goto v38sL;
        qHlfC:
        $X5TZU["\154\145\166\145\154\163"] = empty($wNqOi["\154\145\x76\145\x6c\x73"]) ? array() : $wNqOi["\x6c\x65\166\145\x6c\x73"];
        goto EKadb;
        WkZ3S:
        $fSY28 = explode("\x5f", $this->request->get["\x70\141\x74\x68"]);
        goto MQLzy;
        HMCv3:
        $K5aWM = $this->a0wpUpwQtTyI0a($F_GlA);
        goto VKxVb;
        O_3LE:
        if ($VCuQF) {
            goto F7Hl9;
        }
        goto DYhk0;
        v38sL:
        if (!empty($wNqOi["\x73\164\x61\x74\165\x73"])) {
            goto p2aCh;
        }
        goto aCOia;
        myBfv:
        $B3oTR["\144\x69\x72\x65\143\164\x69\157\x6e"] = $this->language->get("\144\x69\x72\145\x63\x74\151\x6f\156");
        goto XySLv;
        LshYQ:
        $giJfE = array("\143\157\155\x62\151\x6e\x65\x64\56\x6a\163\77\x76" . $B3oTR["\x5f\x76"]);
        goto lWlwX;
        WGpHD:
        goto hsqjG;
        goto TFKqU;
        rgVC3:
        KV0Tu:
        goto QMeYs;
        VB5vm:
        return;
        goto x0Hid;
        YotDv:
        $B3oTR["\137\151\x64\x78"] = $X5TZU["\x5f\x69\x64\170"];
        goto Grdk2;
        Rtcm_:
        U_BFH:
        goto maXtC;
        Hyg5w:
        hsqjG:
        goto gqjZN;
        bOfPQ:
        $B3oTR["\x5f\162\x6f\x75\x74\x65\111\156\146\157\162\155\141\164\x69\x6f\x6e"] = base64_encode("\151\x6e\x66\157\162\x6d\x61\164\x69\x6f\156\x2f\x69\x6e\146\x6f\162\155\141\164\x69\x6f\x6e");
        goto bmW6e;
        zwBrx:
        goto gvP2h;
        goto v30JZ;
        fkYbh:
        $B3oTR["\152\157\x6f\x5f\143\141\162\164"] = $LgD9U;
        goto k7iGL;
        y98Ar:
        $wNqOi = json_decode($wNqOi["\x73\x65\x74\164\x69\x6e\147\163"], true);
        goto VmDMz;
        RQD1o:
        $fSY28 = explode("\x5f", $this->request->get["\x70\141\x74\x68"]);
        goto fYYVd;
        tm2wS:
        if (!isset($B3oTR["\x72\145\161\x75\x65\x73\164\107\x65\164"]["\155\146\x70\137\x70\x61\x74\150"])) {
            goto P4JZC;
        }
        goto N01vV;
        mZTMv:
        $this->a1GIogCcvADI1a("\x59\157\x75\162\x20\117\x70\x65\x6e\103\x61\x72\164\x20\x72\x65\x71\x75\x69\162\x65\163\x20\x56\121\x4d\157\144\40\x69\156\x20\x76\x65\x72\x73\151\157\156\40\x32\x2e\66\56\x31\40\157\x72\40\x6c\141\x74\145\x72\56\x3c\x62\x72\40\x2f\76\x59\157\x75\x72\x20\166\x65\x72\x73\x69\x6f\x6e\40\157\146\40\126\121\115\x6f\144\x20\x69\163\x20\x74\157\157\x20\x6f\x6c\144\56\40\x50\x6c\145\141\x73\145\40\165\160\147\162\x61\144\x65\40\x69\164\40\164\157\40\164\150\145\40\x6c\x61\164\145\163\164\40\x76\x65\162\x73\151\x6f\156\56", true);
        goto XM6th;
        mMpCZ:
        if (NULL != ($wNqOi = $this->db->query("\x53\x45\x4c\105\103\124\40\x2a\40\106\x52\x4f\115\x20\140" . DB_PREFIX . "\x6d\146\x69\154\x74\145\x72\x5f\x73\x65\164\164\x69\156\x67\x73\140\40\127\x48\105\122\105\40\140\x69\144\170\x60\x20\75\x20" . (int) $X5TZU["\137\x69\144\x78"])->row)) {
            goto CxWLD;
        }
        goto C6YZx;
        KrLzU:
        $B3oTR["\150\x69\144\x65\x5f\143\157\156\164\x61\x69\156\145\x72"] = true;
        goto hlB5v;
        kaIOO:
        $PZDYD = '';
        goto WoLqg;
        rjtbs:
        if (method_exists($this->a4otBgCefxdl4a, "\147\145\x74\141\152\141\x78\x6d\157\x64\165\x6c\145")) {
            goto a8UCt;
        }
        goto dv0sY;
        JdsPb:
        $XwBAr = $this->config->get("\x6d\145\147\x61\137\x66\x69\x6c\164\145\162\x5f\x73\145\x74\x74\x69\x6e\147\163");
        goto mAbcS;
        BvrxI:
        Y41xO:
        goto w6NPM;
        dUpzb:
        $F_GlA = array();
        goto wWPgs;
        p9h9t:
        otHm8:
        goto YBXuk;
        b2B4C:
        unset($F_GlA[$K5aWM["\x6d\x61\x6e\165\146\x61\x63\164\165\x72\145\162\163"]]);
        goto rgVC3;
        urPGy:
        $B3oTR["\x5f\x72\157\x75\164\145\103\141\x74\x65\x67\157\162\x79"] = base64_encode("\160\162\x6f\x64\165\143\x74\x2f\143\x61\164\x65\147\x6f\x72\x79");
        goto f4BQ_;
        FmUBS:
        foreach ($giJfE as $IFyEk) {
            goto oSnoF;
            UNSK6:
            $LBhmk .= $LBhmk ? "\12\12" : '';
            goto beZmm;
            oSnoF:
            $IFyEk = str_replace("\56\152\163\77\166" . $B3oTR["\x5f\166"], "\56\152\x73", $IFyEk);
            goto UNSK6;
            XiGPK:
            L1uDR:
            goto yz4Eh;
            beZmm:
            $LBhmk .= file_get_contents(DIR_SYSTEM . "\56\56\x2f\143\x61\164\141\154\x6f\147\x2f\x76\x69\x65\x77\57\152\x61\x76\141\x73\x63\162\151\160\164\57\155\146\x2f" . $IFyEk);
            goto XiGPK;
            yz4Eh:
        }
        goto THiLG;
        Laxxv:
        $F_GlA = $NPIXN;
        goto cc_PT;
        zzGRt:
        $X5TZU["\x76\x65\x68\151\143\154\x65\x73"] = empty($wNqOi["\x76\145\150\x69\x63\154\x65\163"]) ? array() : $wNqOi["\166\x65\x68\151\x63\x6c\145\163"];
        goto qd3Kh;
        nbkQ_:
        if (empty($XwBAr["\143\141\143\x68\x65\137\x65\x6e\141\142\154\145\x64"])) {
            goto u76Z4;
        }
        goto JAI1u;
        ox3MX:
        $B3oTR["\x64\151\163\x70\154\141\171\123\x65\154\x65\x63\164\x65\x64\106\151\154\x74\x65\162\x73"] = empty($wNqOi["\x64\x69\x73\160\x6c\141\171\137\163\x65\154\x65\143\x74\x65\144\x5f\146\x69\154\164\145\x72\x73"]) ? false : $wNqOi["\144\151\163\x70\154\x61\171\137\163\x65\x6c\145\x63\164\x65\x64\x5f\x66\151\154\164\x65\x72\x73"];
        goto WAgi3;
        FUqrL:
        iU6ex:
        goto pdF9T;
        lxXwx:
        $X5TZU["\157\160\x74\151\157\x6e\x73"] = empty($wNqOi["\157\160\164\151\157\x6e\x73"]) ? array() : $wNqOi["\x6f\x70\x74\151\x6f\x6e\x73"];
        goto Ob2xC;
        Xmc_N:
        $B3oTR["\x70\x61\x72\x61\155\163"] = $jLZAU->getParseParams();
        goto FtX6A;
        RlfX7:
        if (!empty($X5TZU["\157\160\x74\x69\x6f\x6e\163"])) {
            goto x0VEH;
        }
        goto lxXwx;
        qB55P:
        iMjaI:
        goto KcoMB;
        EPkoy:
        gJgau:
        goto RlfX7;
        QQBVV:
        $B3oTR["\147\x65\x74\123\171\155\142\x6f\154\114\x65\146\164"] = $this->currency->getSymbolLeft(isset($this->session->data["\143\165\162\162\145\156\143\171"]) ? $this->session->data["\143\165\162\x72\145\x6e\x63\171"] : '');
        goto UUBS_;
        JgzqS:
        if (!(empty($this->a5ToNvlGgkXA5a["\x6c\154\x6c"]) || $this->a5ToNvlGgkXA5a["\154\154\154"] != "\x6d\x66")) {
            goto Udaoq;
        }
        goto Md4Cv;
        qd3Kh:
        r0aXq:
        goto cAyoH;
        Belu_:
        foreach ($giJfE as $IFyEk) {
            goto xgzbW;
            xMdsi:
            L2JFC:
            goto v2Yub;
            s0GQu:
            FdYK9:
            goto e3tQb;
            e3tQb:
            $this->document->addScript("\x63\x61\x74\141\154\x6f\147\x2f\166\x69\x65\x77\57\152\x61\x76\141\x73\x63\x72\151\160\x74\x2f\x6d\x66\x2f" . $IFyEk);
            goto xMdsi;
            wePNx:
            $IFyEk = str_replace("\56\152\x73\77\166" . $B3oTR["\137\x76"], "\56\x6a\x73", $IFyEk);
            goto s0GQu;
            xgzbW:
            if (empty($XwBAr["\155\x69\156\151\146\171\137\x73\x75\x70\160\x6f\162\x74"])) {
                goto FdYK9;
            }
            goto wePNx;
            v2Yub:
        }
        goto SWprM;
        C7CZF:
        return;
        goto p9h9t;
        UOVT6:
        PsIqq:
        goto yqsJy;
        XM6th:
        return;
        goto jPWpf;
        DYhk0:
        return;
        goto UsRPA;
        x0Hid:
        NYlf5:
        goto lypee;
        vQHTM:
        q3XGL:
        goto Hk6TO;
        f4BQ_:
        $B3oTR["\x5f\162\157\165\x74\x65\110\157\x6d\145"] = base64_encode("\143\x6f\155\x6d\157\x6e\x2f\150\157\x6d\x65");
        goto bOfPQ;
        UnoqY:
        $B3oTR["\162\145\x71\165\x65\x73\164\x47\145\164"] = $this->request->get;
        goto aacwp;
        Dt9I2:
        bGpoB:
        goto nWJS0;
        h4oxE:
        foreach ($wNqOi["\143\157\156\146\151\x67\165\162\141\164\x69\x6f\x6e"] as $YOZKe => $x3s43) {
            $XwBAr[$YOZKe] = $x3s43;
            X6lVN:
        }
        goto RZha0;
        cD2La:
        if (!($B3oTR["\160\162\151\143\x65"]["\155\151\156"] == 0 && $B3oTR["\x70\x72\151\x63\145"]["\x6d\x61\170"] == 0 && !empty($B3oTR["\160\162\151\143\145"]["\145\155\160\164\x79"]))) {
            goto G1Tof;
        }
        goto l7yuX;
        NJFTd:
        $B3oTR["\160\x72\x69\143\x65"] = $jLZAU->getMinMaxPrice();
        goto cD2La;
        UsRPA:
        F7Hl9:
        goto KH0MY;
        oZWKV:
        bsDe7:
        goto DbxM8;
        UUBS_:
        $B3oTR["\147\x65\x74\123\171\155\x62\157\154\x52\151\x67\150\x74"] = $this->currency->getSymbolRight(isset($this->session->data["\143\x75\x72\162\x65\x6e\x63\171"]) ? $this->session->data["\x63\x75\x72\162\145\156\143\x79"] : '');
        goto UnoqY;
        XFP9U:
        return;
        goto xCPV7;
        gOtIK:
        $H0o2h = $this->customer->isLogged() ? $this->customer->getGroupId() : $this->config->get("\143\157\156\146\151\x67\137\143\165\163\x74\157\x6d\145\x72\x5f\x67\162\157\x75\x70\137\x69\144");
        goto zX9PL;
        WCzlj:
        $X5TZU["\x63\141\164\145\x67\x6f\x72\151\x65\x73"] = empty($wNqOi["\x63\x61\164\x65\147\157\162\x69\x65\x73"]) ? array() : $wNqOi["\x63\141\164\145\x67\157\x72\151\x65\x73"];
        goto EmQ7O;
        wccG3:
        require_once modification(DIR_SYSTEM . "\x6c\x69\142\x72\x61\x72\171\x2f\155\146\151\x6c\x74\145\x72\137\x6d\157\x62\x69\x6c\x65\56\x70\x68\x70");
        goto FFOev;
        DbxM8:
        goto YZnO8;
        goto wkorl;
        JAI1u:
        $Pumds = "\151\x64\x78\x2e" . $X5TZU["\x5f\151\x64\x78"] . "\x2e" . $jLZAU->cacheName();
        goto avR5o;
        gxGH7:
        $B3oTR["\163\155\160"] = array("\x69\x73\x49\156\163\x74\141\x6c\154\x65\144" => $this->config->get("\x73\155\160\137\x69\x73\x5f\x69\156\163\164\x61\x6c\154"), "\144\x69\x73\141\142\154\x65\x43\157\x6e\166\145\x72\164\125\x72\x6c\x73" => $this->config->get("\163\x6d\x70\137\x64\x69\x73\141\142\x6c\145\x5f\143\157\156\x76\x65\x72\164\x5f\x75\x72\154\x73"));
        goto yyS4l;
        rafSn:
        WdC_u:
        goto Laxxv;
        Ez1wo:
        MijoShop::getClass("\x62\x61\x73\x65")->addHeader($this->a2UxPGIXaGSm2a($this->url->link("\155\x6f\144\165\x6c\145\x2f\x6d\145\147\141\x5f\x66\x69\154\x74\145\162\x2f\152\163\x5f\x70\x61\x72\x61\155\163", '', "\123\123\x4c")), false);
        goto fOKV8;
        JVnwP:
        if (!($sWVql && empty($X5TZU["\x76\145\150\x69\143\154\145\163"]))) {
            goto r0aXq;
        }
        goto zzGRt;
        w6NPM:
        if (empty($wNqOi["\x68\x69\144\x65\x5f\143\x61\x74\145\147\x6f\x72\171\x5f\151\x64"])) {
            goto q3XGL;
        }
        goto RQD1o;
        EWB7u:
        goto Z5KJ0;
        goto orNLC;
        gVB9M:
        RXCeC:
        goto W2P5v;
        iTVlR:
        gvP2h:
        goto OC3O6;
        bHPWZ:
        if (!(isset($wNqOi["\x6c\141\171\157\165\x74\137\x69\x64"]) && is_array($wNqOi["\x6c\x61\x79\x6f\165\x74\x5f\151\144"]))) {
            goto iMjaI;
        }
        goto OI6JG;
        W2P5v:
        foreach ($fSY28 as $pTOoj) {
            goto RqNb4;
            t4695:
            zVIEI:
            goto NIodW;
            lUbIc:
            return;
            goto KnHBR;
            KnHBR:
            YntSS:
            goto t4695;
            RqNb4:
            if (!in_array($pTOoj, $wNqOi["\x68\151\144\x65\137\143\141\x74\x65\x67\x6f\x72\x79\x5f\151\x64"])) {
                goto YntSS;
            }
            goto lUbIc;
            NIodW:
        }
        goto iZX6q;
        Md4Cv:
        return;
        goto MRgmt;
        KaUEI:
        Dv7po:
        goto eBEr0;
        Q29JH:
        if (!isset($wNqOi["\164\151\164\x6c\x65"][$this->config->get("\x63\x6f\156\x66\x69\x67\x5f\154\141\156\x67\165\x61\147\145\137\x69\144")])) {
            goto Bla0Y;
        }
        goto Zv32z;
        DwMtv:
        Bla0Y:
        goto kWTNH;
        daL8r:
        cBNTd:
        goto mMpCZ;
        hd66a:
        $zA6Aa = array("\x6d\146\x70" => null);
        goto keiLD;
        avR5o:
        u76Z4:
        goto d6mAG;
        sxKr_:
        JuUSK:
        goto Tegcf;
        nqDXm:
        if (!empty($X5TZU["\146\x69\154\x74\x65\x72\163"])) {
            goto w43ZZ;
        }
        goto MmoKO;
        vkinP:
        $giJfE = array("\x6a\161\x75\x65\162\x79\x2d\165\151\x2e\155\151\x6e\56\152\x73\x3f\x76" . $B3oTR["\137\x76"], "\152\x71\165\145\162\x79\55\160\154\x75\x67\151\x6e\163\x2e\x6a\x73\77\166" . $B3oTR["\x5f\x76"], "\150\141\155\x6d\145\162\56\152\163\77\x76" . $B3oTR["\137\166"], "\151\x73\143\162\157\154\154\x2e\x6a\x73\x3f\x76" . $B3oTR["\x5f\166"], "\x6c\x69\166\145\146\x69\154\x74\145\162\x2e\152\163\77\166" . $B3oTR["\x5f\166"], "\163\x65\x6c\x65\143\x74\x70\x69\x63\153\x65\162\56\152\x73\77\x76" . $B3oTR["\137\166"], "\155\x65\x67\141\x5f\x66\x69\154\x74\x65\x72\x2e\x6a\163\77\166" . $B3oTR["\x5f\x76"]);
        goto VOVau;
        qvoqW:
        $pTOoj = end($fSY28);
        goto r2jbp;
        yyS4l:
        $B3oTR["\x73\145\157"] = $this->config->get("\x6d\145\147\x61\x5f\x66\x69\x6c\x74\x65\162\137\x73\145\x6f");
        goto rKsrH;
        pXzI2:
        UODrd:
        goto P3Svz;
        KCXH4:
        n9its:
        goto Syyml;
        n9izB:
        $B3oTR["\x70\x72\151\x63\x65"] = array("\x6d\x69\x6e" => 0, "\155\141\x78" => 0, "\145\155\160\x74\x79" => true);
        goto E0u5_;
        N01vV:
        $B3oTR["\162\145\x71\x75\x65\x73\x74\x47\x65\164"]["\155\146\x70\137\x70\x61\x74\150\137\x61\x6c\x69\141\163\x65\163"] = implode("\x5f", MegaFilterCore::pathToAliases($this, $B3oTR["\x72\x65\161\165\x65\x73\164\107\145\x74"]["\x6d\146\x70\x5f\160\x61\x74\150"]));
        goto pcJ6V;
        aTjiq:
        if (class_exists("\x56\121\x4d\157\x64")) {
            goto iU6ex;
        }
        goto wccG3;
        n40Or:
        uSwu8:
        goto Belu_;
        EmQ7O:
        bJfnB:
        goto cQENk;
        oswof:
        wV3LR:
        goto dsaos;
        v30JZ:
        aaTIf:
        goto k0H37;
        lJQkv:
        Aqps7:
        goto x5EIl;
        EKadb:
        CfZlI:
        goto JdsPb;
        aOC4X:
        $B3oTR["\x5f\x72\x6f\165\x74\145\x50\162\x6f\x64\165\x63\x74"] = base64_encode("\x70\x72\x6f\144\165\x63\164\x2f\x70\162\157\x64\165\143\164");
        goto urPGy;
        Syyml:
        if (!isset($B3oTR["\162\x65\x71\x75\x65\163\x74\107\145\164"]["\160\141\x74\x68"])) {
            goto PsIqq;
        }
        goto YFcco;
        eBEr0:
        file_put_contents($rMokp, "\x76\x61\x72\x20\x4d\x46\120\137\x52\124\x4c\40\x3d\x20" . ($this->language->get("\x64\x69\x72\x65\143\164\x69\157\x6e") == "\x72\164\154" ? "\164\162\165\145" : "\x66\x61\x6c\x73\145") . "\x3b");
        goto VK7NV;
        x5EIl:
        if ($wOZ68) {
            goto J5ENu;
        }
        goto n9izB;
        zmnAU:
        if ($this->config->get("\155\x66\151\x6c\164\145\162\x5f\154\x69\x63\145\x6e\x73\x65")) {
            goto xqQkp;
        }
        goto XFP9U;
        iZX6q:
        VX2tm:
        goto G4YJu;
        KH0MY:
        YZnO8:
        goto BvrxI;
        WoLqg:
        foreach ($WXoCX as $IFyEk) {
            goto Y01zN;
            DbFu5:
            $PZDYD .= file_get_contents(DIR_SYSTEM . "\x2e\x2e\x2f" . $IFyEk);
            goto qJuRz;
            qJuRz:
            fKR8J:
            goto KgNT_;
            Y01zN:
            $IFyEk = str_replace("\x2e\x63\163\x73\x3f\166" . $B3oTR["\x5f\166"], "\56\x63\x73\x73", $IFyEk);
            goto G9kQ0;
            G9kQ0:
            $PZDYD .= $PZDYD ? "\12\12" : '';
            goto DbFu5;
            KgNT_:
        }
        goto Dt9I2;
        eVEZS:
        J5ENu:
        goto NJFTd;
        D0v1q:
        if (file_exists(DIR_SYSTEM . "\56\56\x2f\x63\141\164\141\154\x6f\x67\x2f\x76\x69\145\x77\57\x6a\141\x76\141\163\x63\162\x69\x70\x74\x2f\155\x66\57\143\x6f\x6d\x62\x69\x6e\145\x64\56\x6a\163")) {
            goto cNHks;
        }
        goto te9L6;
        B6d3E:
        MijoShop::get()->addHeader(JPATH_MIJOSHOP_OC . "\57\143\x61\x74\141\154\157\147\x2f\x76\151\x65\x77\57\x74\150\x65\x6d\x65\57\x64\145\146\141\165\x6c\164\x2f\163\x74\171\154\145\163\150\x65\145\164\x2f\155\146\57\163\x74\x79\154\145\56\143\x73\163");
        goto WGpHD;
        orNLC:
        usAEd:
        goto Ez1wo;
        OC3O6:
        if (empty($XwBAr["\143\157\155\142\x69\156\x65\x5f\152\x73\x5f\x63\163\163\x5f\146\x69\x6c\x65\x73"])) {
            goto uSwu8;
        }
        goto D0v1q;
        zH9Tc:
        UGyxf:
        goto bHPWZ;
        RgySF:
        DCS_S:
        goto myBfv;
        AFJFK:
        xpUH1:
        goto zwBrx;
        wXvSJ:
        return;
        goto WbiV7;
        sWK58:
        $this->model_module_mega_filter->setSettings($XwBAr);
        goto hd66a;
        YO4f5:
        $jLZAU = MegaFilterCore::newInstance($this, NULL, array(), $XwBAr);
        goto N6iNA;
        KPKDt:
        $X5TZU["\x61\x74\x74\162\151\142\163"] = empty($wNqOi["\141\164\164\162\151\142\x73"]) ? array() : $wNqOi["\x61\164\164\x72\x69\x62\x73"];
        goto EPkoy;
        EQZix:
    }
}