<?php
$file = DIR_SYSTEM.'.htaccess';
if(file_exists($file))
	unlink($file);
?>