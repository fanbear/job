==============================================================================
Using This Version on OpenCart 2.0.1 through 2.2

Author: Clear Thinking, LLC
E-mail: johnathan@getclearthinking.com
Website: http://www.getclearthinking.com
==============================================================================

This version of the extension is usable on OpenCart 2.0.1 through 2.2, if you
perform the following steps:


1. Upload the contents of the "upload for 2.0-2.2" folder to your OpenCart
store root, using an FTP application. If you prefer to use the extension
installer, you can also zip that folder into a bundle and then change its
file extension to end in .ocmod.zip. You can then upload it using the 
extension installer.


2. If using OpenCart 2.1 or 2.2, you can ignore the rest of this file.


3. If using OpenCart 2.0.1, 2.0.2, or 2.0.3, rename the
/system/engine/action.php file to action.php-OLD, then rename the
/system/engine/action-NEW.php file to action.php


The new action.php file is the standard file from OpenCart 2.1, which works
fine on 2.0.1, 2.0.2, and 2.0.3, and is required to use this version on older
OpenCart installations.