<?php
// URL Params delimeters
$_['module_ocfilter_part_separator'] = ';';
$_['module_ocfilter_option_separator'] = ':';
$_['module_ocfilter_option_value_separator'] = ',';

// URL GET index
$_['module_ocfilter_url_index'] = 'filter_ocfilter';