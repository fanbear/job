<?php

include_once(DIR_LANGUAGE . 'ru-ru/extension/module/ocfilter.php');